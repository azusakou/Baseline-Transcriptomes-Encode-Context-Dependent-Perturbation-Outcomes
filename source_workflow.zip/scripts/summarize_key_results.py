#!/usr/bin/env python3
"""Create a manuscript-facing summary of validation estimates and uncertainty."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def summarize(
    path: Path,
    source: str,
    evidence: str,
    default_validation: str | None = None,
) -> pd.DataFrame:
    data = pd.read_csv(path, sep="\t")
    if "validation" not in data:
        data["validation"] = default_validation
    keys = ["validation", "target", "model", "metric"]
    rows = []
    for name, group in data.groupby(keys, observed=True, dropna=False):
        values = pd.to_numeric(group.value, errors="coerce").dropna().to_numpy(float)
        if not len(values):
            continue
        mean = float(values.mean())
        if len(values) > 1:
            half = float(t.ppf(0.975, len(values) - 1) * values.std(ddof=1) / np.sqrt(len(values)))
        else:
            half = np.nan
        rows.append(
            {
                "source": source,
                "evidence_tier": evidence,
                "validation": name[0],
                "target": name[1],
                "model": name[2],
                "metric": name[3],
                "estimate": mean,
                "ci_low": mean - half if np.isfinite(half) else np.nan,
                "ci_high": mean + half if np.isfinite(half) else np.nan,
                "n_outer_units": len(values),
            }
        )
    result = pd.DataFrame(rows)
    baseline = result.loc[result.model.eq("training_mean"), ["validation", "target", "metric", "estimate"]].rename(
        columns={"estimate": "training_mean_estimate"}
    )
    result = result.merge(baseline, on=["validation", "target", "metric"], how="left")
    # Positive delta consistently means improvement, including error metrics.
    error = result.metric.isin(["mse", "mae", "brier"])
    result["improvement_over_training_mean"] = np.where(
        error,
        result.training_mean_estimate - result.estimate,
        result.estimate - result.training_mean_estimate,
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--external-root", type=Path, default=Path("/Volumes/wang/paper6yhn"))
    parser.add_argument("--output", type=Path, default=Path("reports/key_results.tsv"))
    args = parser.parse_args()
    project_root = args.project_root.resolve()
    external_results = args.external_root.resolve() / "results"
    output = args.output if args.output.is_absolute() else project_root / args.output
    specs = [
        (external_results / "mixseq_future_fate_benchmark_all/leave_cell_line_metrics.tsv", "MIX-seq", "derived", None),
        (external_results / "mixseq_future_fate_benchmark_all/leave_perturbation_metrics.tsv", "MIX-seq", "derived", None),
        (external_results / "larry_in_vitro_benchmark_clone_aggregated/scalar_fate_metrics.tsv", "LARRY in vitro", "gold", "leave_clone"),
        (external_results / "larry_in_vitro_benchmark_clone_aggregated/clone_heldout_metrics.tsv", "LARRY in vitro", "gold", "leave_clone"),
        (external_results / "larry_cytokine_benchmark_clone_aggregated/scalar_fate_metrics.tsv", "LARRY cytokine", "gold", "leave_clone"),
        (external_results / "larry_cytokine_benchmark_clone_aggregated/clone_heldout_metrics.tsv", "LARRY cytokine", "gold", "leave_clone"),
        (external_results / "larry_leave_dataset_clone_aggregated/leave_dataset_metrics.tsv", "LARRY", "gold", None),
        (external_results / "wot_baseline_benchmark/replicate_heldout_metrics.tsv", "Waddington-OT", "silver", "leave_replicate"),
        (external_results / "cross_task_dataset_generalization/generalization_metrics.tsv", "LARRY/WOT", "stress_test", None),
        (external_results / "patient_fate_embedding/ispy2/cross_validation_metrics.tsv", "I-SPY2", "clinical_projection", "leave_patient"),
        (external_results / "patient_fate_embedding/beataml/cross_validation_metrics.tsv", "BeatAML", "clinical_projection", "leave_patient"),
    ]
    frames = []
    replogle = external_results / "replogle_k562_future_fate/metrics.tsv"
    if not replogle.exists():
        replogle = project_root / "results/replogle_k562_future_fate/metrics.tsv"
    if replogle.exists():
        specs.append((replogle, "Replogle K562", "genetic_derived", None))
    rpe1 = project_root / "results/replogle_rpe1_generalization/metrics.tsv"
    if rpe1.exists():
        specs.append((rpe1, "Replogle RPE1", "genetic_derived", None))
    spatial = project_root / "results/xenium_future_niches/joint_model_metrics.tsv"
    if spatial.exists():
        specs.append((spatial, "GSE291246 Xenium", "spatial_exploratory", "leave_patient"))
    for path, source, evidence, validation in specs:
        data = pd.read_csv(path, sep="\t")
        if "target" not in data:
            if "branch" in data:
                data["target"] = "branch_" + data["branch"].astype(str)
            elif source == "GSE291246 Xenium":
                data["target"] = "tumour_shrinkage"
            else:
                data["target"] = "clinical_response"
        if "model" not in data:
            data["model"] = "patient_fate_embedding"
        temporary = output.parent / f".{source.replace(' ', '_').replace('/', '_')}.summary_input.tsv"
        temporary.parent.mkdir(parents=True, exist_ok=True)
        data.to_csv(temporary, sep="\t", index=False)
        frames.append(summarize(temporary, source, evidence, validation))
        temporary.unlink()
    result = pd.concat(frames, ignore_index=True)
    result.to_csv(output, sep="\t", index=False)
    print(f"wrote {output}: {len(result)} summary rows")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
