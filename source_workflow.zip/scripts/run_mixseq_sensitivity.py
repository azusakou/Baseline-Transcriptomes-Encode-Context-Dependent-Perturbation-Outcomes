#!/usr/bin/env python3
"""Rebuild MIX-seq targets and prediction benchmarks across target definitions."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from benchmark_mixseq_future_fate import aggregate_baseline, evaluate
from construct_mixseq_fate_targets import AXES, CONTROLS, robust_threshold


GROUP_KEYS = ["dataset_id", "experiment", "time_hours", "task", "cell_line"]


def construct(scores: pd.DataFrame, min_cells: int, mad_multiplier: float) -> pd.DataFrame:
    scores = scores.copy()
    scores["control_rank"] = scores.perturbation.astype(str).str.lower().map(CONTROLS)
    controls = scores.loc[scores.control_rank.notna()]
    treated = scores.loc[scores.control_rank.isna()]
    rows: list[dict[str, object]] = []
    for keys, treatment_group in treated.groupby(GROUP_KEYS + ["perturbation"], observed=True, dropna=False):
        context = dict(zip(GROUP_KEYS + ["perturbation"], keys, strict=True))
        mask = np.ones(len(controls), dtype=bool)
        for key in GROUP_KEYS:
            left = controls[key]
            value = context[key]
            mask &= left.isna().to_numpy() if pd.isna(value) else left.astype(str).to_numpy() == str(value)
        candidates = controls.loc[mask]
        if candidates.empty:
            continue
        baseline = candidates.loc[candidates.control_rank.eq(candidates.control_rank.min())]
        if len(baseline) < min_cells or len(treatment_group) < min_cells:
            continue
        row: dict[str, object] = {
            **context,
            "baseline": baseline.perturbation.iloc[0],
            "baseline_cells": len(baseline),
            "treated_cells": len(treatment_group),
            "target_min_cells": min_cells,
            "target_mad_multiplier": mad_multiplier,
        }
        for axis in AXES:
            threshold = robust_threshold(baseline[f"score_{axis}"], mad_multiplier)
            successes = int(treatment_group[f"score_{axis}"].gt(threshold).sum())
            trials = int(treatment_group[f"score_{axis}"].notna().sum())
            probability = (successes + 1) / (trials + 2)
            row[f"{axis}_threshold"] = threshold
            row[f"p_{axis}"] = probability
            row[f"p_{axis}_se"] = np.sqrt(probability * (1 - probability) / (trials + 3))
        row["pair_id"] = "|".join(str(row[key]) for key in GROUP_KEYS) + f"|{row['baseline']}->{context['perturbation']}"
        rows.append(row)
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--primary-targets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--min-cells", nargs="+", type=int, default=[10, 20, 30, 50])
    parser.add_argument("--mad-multipliers", nargs="+", type=float, default=[0.5, 1.0, 1.5])
    args = parser.parse_args()
    scores = pd.read_parquet(args.scores)
    state = aggregate_baseline(args.baseline)
    primary = pd.read_csv(args.primary_targets, sep="\t").set_index("pair_id")
    summary: list[dict[str, object]] = []
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for min_cells in args.min_cells:
        for multiplier in args.mad_multipliers:
            label = f"min{min_cells}_mad{multiplier:g}".replace(".", "p")
            variant_dir = args.output_dir / label
            targets = construct(scores, min_cells, multiplier)
            targets.to_csv(variant_dir.with_suffix(".targets.tsv"), sep="\t", index=False)
            rows = targets.merge(state, on=["cell_line", "experiment", "time_hours"], validate="many_to_one")
            variant_dir.mkdir(parents=True, exist_ok=True)
            rows.to_parquet(variant_dir / "modeling_table.parquet", index=False)
            for mode in ["leave_cell_line", "leave_perturbation"]:
                evaluate(rows, mode, variant_dir)
                metrics = pd.read_csv(variant_dir / f"{mode}_metrics.tsv", sep="\t")
                for keys, frame in metrics.groupby(["target", "model", "metric"], observed=True):
                    summary.append({
                        "variant": label,
                        "min_cells": min_cells,
                        "mad_multiplier": multiplier,
                        "pairs_total": len(targets),
                        "pairs_modeled": len(rows),
                        "validation": mode,
                        "target": keys[0],
                        "model": keys[1],
                        "metric": keys[2],
                        "mean_value": frame.value.mean(),
                        "folds": frame.fold.nunique(),
                    })
            common = targets.set_index("pair_id").index.intersection(primary.index)
            for axis in AXES:
                target = f"p_{axis}"
                rho = spearmanr(targets.set_index("pair_id").loc[common, target], primary.loc[common, target]).statistic
                summary.append({
                    "variant": label,
                    "min_cells": min_cells,
                    "mad_multiplier": multiplier,
                    "pairs_total": len(targets),
                    "pairs_modeled": len(rows),
                    "validation": "target_concordance",
                    "target": target,
                    "model": "alternative_vs_primary",
                    "metric": "spearman",
                    "mean_value": rho,
                    "folds": np.nan,
                })
    result = pd.DataFrame(summary)
    result.to_csv(args.output_dir / "sensitivity_summary.tsv", sep="\t", index=False)
    print(result.groupby(["validation", "target", "model", "metric"]).mean_value.agg(["min", "max"]).to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
