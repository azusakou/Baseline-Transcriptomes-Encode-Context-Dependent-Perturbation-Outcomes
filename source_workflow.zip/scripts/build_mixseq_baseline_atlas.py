#!/usr/bin/env python3
"""Build a counts-preserving MIX-seq DMSO baseline atlas for descriptive scVI."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import pandas as pd
import scanpy as sc


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--n-hvg", type=int, default=4000)
    args = parser.parse_args()
    datasets = []
    for path in sorted(p for p in args.input_dir.glob("*.qc.h5ad") if not p.name.startswith("._")):
        data = ad.read_h5ad(path)
        is_dmso = data.obs["perturbation"].astype(str).str.lower().eq("dmso")
        keep = is_dmso & data.obs["passes_qc_final"].fillna(False).astype(bool)
        if keep.any():
            selected = data[keep].copy()
            selected.obs_names = pd.Index([f"{path.stem}:{value}" for value in selected.obs_names], name="cell_id")
            datasets.append(selected)
    if not datasets:
        raise FileNotFoundError("no QC-passing DMSO cells")
    atlas = ad.concat(datasets, join="inner", merge="same")
    atlas.obs_names_make_unique()
    atlas.obs["technical_batch"] = (
        atlas.obs["experiment"].astype(str) + "_" +
        atlas.obs["time_hours"].astype(str) + "h_" + atlas.obs["batch"].astype(str)
    )
    normalized = atlas.copy()
    sc.pp.normalize_total(normalized, target_sum=1e4)
    sc.pp.log1p(normalized)
    sc.pp.highly_variable_genes(
        normalized, n_top_genes=min(args.n_hvg, normalized.n_vars),
        flavor="cell_ranger", batch_key="technical_batch",
    )
    genes = normalized.var_names[normalized.var.highly_variable]
    atlas = atlas[:, genes].copy()
    atlas.layers["counts"] = atlas.X.copy()
    atlas.uns["baseline_definition"] = "QC-passing DMSO cells; no treated expression used"
    atlas.uns["hvg_policy"] = "cell_ranger dispersion on logCP10K, batch-aware; descriptive atlas only"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    atlas.write_h5ad(args.output, compression="gzip")
    print(f"wrote {args.output}; shape={atlas.shape}; cell_lines={atlas.obs.cell_line.nunique()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
