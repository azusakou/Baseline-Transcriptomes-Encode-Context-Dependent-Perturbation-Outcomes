#!/usr/bin/env python3
"""Convert completed MIX-Seq archives into per-experiment AnnData checkpoints."""

from __future__ import annotations

import argparse
import csv
import io
import re
import zipfile
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
from scipy.io import mmread


def member(zf: zipfile.ZipFile, suffix: str) -> str:
    names = [n for n in zf.namelist() if n.endswith(suffix) and not n.startswith("__MACOSX/")]
    if len(names) != 1:
        raise ValueError(f"expected one {suffix}, found {names}")
    return names[0]


def parse_name(stem: str) -> dict[str, object]:
    expt = re.search(r"expt(\d+)", stem, flags=re.I)
    hour = re.search(r"(\d+)hr", stem, flags=re.I)
    perturbation = re.sub(r"_(?:\d+hr_)?expt\d+$", "", stem, flags=re.I)
    control = perturbation.lower() in {"dmso", "untreated", "sgor2j2", "sglacz"}
    task = "genetic" if perturbation.lower().startswith("sg") else "chemical"
    return {
        "experiment": int(expt.group(1)) if expt else -1,
        "time_hours": int(hour.group(1)) if hour else np.nan,
        "perturbation": perturbation,
        "is_control": control,
        "task": task,
    }


def convert(path: Path, output: Path) -> dict[str, object]:
    info = parse_name(path.stem)
    with zipfile.ZipFile(path) as zf:
        genes = pd.read_csv(zf.open(member(zf, "genes.tsv")), sep="\t", header=None, names=["gene_id", "gene_symbol"])
        barcodes = pd.read_csv(zf.open(member(zf, "barcodes.tsv")), sep="\t", header=None, names=["barcode"])["barcode"].astype(str)
        classifications = pd.read_csv(zf.open(member(zf, "classifications.csv")))
        matrix_bytes = io.BytesIO(zf.read(member(zf, "matrix.mtx")))
        matrix = mmread(matrix_bytes).tocsr().transpose().tocsr()

    if matrix.shape != (len(barcodes), len(genes)):
        raise ValueError(f"shape mismatch {matrix.shape}, cells={len(barcodes)}, genes={len(genes)}")
    if "barcode" not in classifications:
        raise ValueError("classifications.csv lacks barcode")
    classifications["barcode"] = classifications["barcode"].astype(str)
    obs = pd.DataFrame(index=pd.Index(barcodes, name="cell_id")).join(classifications.set_index("barcode"), how="left")
    for key, value in info.items():
        obs[key] = value
    obs["dataset_id"] = "mixseq"
    obs["batch"] = path.stem
    if "singlet_ID" in obs:
        obs["cell_line"] = obs["singlet_ID"].astype("string")
    if "cell_quality" in obs:
        obs["source_passes_qc"] = obs["cell_quality"].eq("normal")

    var = genes.copy()
    symbols = var["gene_symbol"].fillna(var["gene_id"]).astype(str)
    var.index = pd.Index(symbols, name="gene")
    if not var.index.is_unique:
        var.index = ad.utils.make_index_unique(var.index)
    adata = ad.AnnData(X=matrix, obs=obs, var=var)
    adata.var["mt"] = adata.var_names.str.upper().str.startswith("MT-")
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], inplace=True, percent_top=None, log1p=False)
    adata.uns["source_archive"] = path.name
    adata.uns["counts_status"] = "raw_umi_counts"
    output.parent.mkdir(parents=True, exist_ok=True)
    adata.write_h5ad(output, compression="gzip")
    return {
        "archive": path.name,
        "output": str(output),
        "cells": adata.n_obs,
        "genes": adata.n_vars,
        "normal_cells": int(obs.get("source_passes_qc", pd.Series(False, index=obs.index)).sum()),
        **info,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    summaries = []
    for path in sorted(p for p in args.input_dir.glob("*.zip") if not p.name.startswith("._")):
        output = args.output_dir / f"{path.stem}.h5ad"
        if output.exists() and not args.force:
            existing = ad.read_h5ad(output, backed="r")
            source_pass = existing.obs.get("source_passes_qc", pd.Series(False, index=existing.obs_names))
            summaries.append({
                "archive": path.name,
                "output": str(output),
                "cells": existing.n_obs,
                "genes": existing.n_vars,
                "normal_cells": int(source_pass.fillna(False).astype(bool).sum()),
                **parse_name(path.stem),
                "status": "existing",
            })
            existing.file.close()
            continue
        print(f"staging {path.name}", flush=True)
        summary = convert(path, output)
        summary["status"] = "written"
        summaries.append(summary)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(summaries).to_csv(args.output_dir / "experiment_manifest.tsv", sep="\t", index=False)
    print(f"staged {len(summaries)} completed archives")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
