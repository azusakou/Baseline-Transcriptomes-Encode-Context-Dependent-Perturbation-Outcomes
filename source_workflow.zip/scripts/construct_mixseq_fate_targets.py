#!/usr/bin/env python3
"""Construct matched-control probabilistic fate targets for MIX-seq pairs."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


AXES = ["apoptosis", "proliferation", "stress"]
CONTROLS = {
    "dmso": 0, "untreated": 1, "vehicle": 2, "control": 3,
    "sglacz": 0, "sgor2j2": 1,
}


def robust_threshold(values: pd.Series, mad_multiplier: float = 1.0) -> float:
    array = values.dropna().to_numpy(float)
    median = np.median(array)
    mad = 1.4826 * np.median(np.abs(array - median))
    return float(median + mad_multiplier * mad)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--min-cells", type=int, default=10)
    parser.add_argument("--mad-multiplier", type=float, default=1.0)
    args = parser.parse_args()
    scores = pd.read_parquet(args.scores) if args.scores.suffix == ".parquet" else pd.read_csv(args.scores, sep="\t")
    scores["control_rank"] = scores.perturbation.astype(str).str.lower().map(CONTROLS)
    group_keys = ["dataset_id", "experiment", "time_hours", "task", "cell_line"]
    controls = scores.loc[scores.control_rank.notna()].copy()
    treated = scores.loc[scores.control_rank.isna()].copy()
    rows = []
    for keys, treatment_group in treated.groupby(group_keys + ["perturbation"], observed=True, dropna=False):
        context = dict(zip(group_keys + ["perturbation"], keys))
        mask = np.ones(len(controls), dtype=bool)
        for key in group_keys:
            mask &= controls[key].astype(str).to_numpy() == str(context[key])
        candidates = controls.loc[mask]
        if candidates.empty:
            continue
        best_rank = candidates.control_rank.min()
        baseline = candidates.loc[candidates.control_rank.eq(best_rank)]
        if len(baseline) < args.min_cells or len(treatment_group) < args.min_cells:
            continue
        row = {
            **context,
            "baseline": baseline.perturbation.iloc[0],
            "baseline_cells": len(baseline),
            "treated_cells": len(treatment_group),
        }
        for axis in AXES:
            threshold = robust_threshold(baseline[f"score_{axis}"], args.mad_multiplier)
            successes = int((treatment_group[f"score_{axis}"] > threshold).sum())
            trials = int(treatment_group[f"score_{axis}"].notna().sum())
            row[f"{axis}_threshold"] = threshold
            row[f"p_{axis}"] = (successes + 1) / (trials + 2)
            row[f"p_{axis}_se"] = np.sqrt(row[f"p_{axis}"] * (1 - row[f"p_{axis}"]) / (trials + 3))
        row["pair_id"] = "|".join(str(row[key]) for key in group_keys) + f"|{row['baseline']}->{context['perturbation']}"
        rows.append(row)
    result = pd.DataFrame(rows)
    result["target_min_cells"] = args.min_cells
    result["target_mad_multiplier"] = args.mad_multiplier
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, sep="\t", index=False)
    print(f"wrote {len(result)} unique primary-control pairs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
