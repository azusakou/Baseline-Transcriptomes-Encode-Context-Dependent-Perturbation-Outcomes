#!/usr/bin/env python3
"""Train a descriptive baseline-only scVI atlas and export latent state."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import scvi


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--latent-dim", type=int, default=30)
    parser.add_argument("--max-epochs", type=int, default=200)
    args = parser.parse_args()
    scvi.settings.seed = 20260713
    data = ad.read_h5ad(args.input)
    scvi.model.SCVI.setup_anndata(data, layer="counts", batch_key="technical_batch")
    model = scvi.model.SCVI(data, n_latent=args.latent_dim, n_layers=2, gene_likelihood="nb")
    model.train(
        max_epochs=args.max_epochs, early_stopping=True,
        early_stopping_patience=20, check_val_every_n_epoch=5,
        batch_size=256,
    )
    data.obsm["X_baseline_scvi"] = model.get_latent_representation()
    data.uns["baseline_scvi"] = {
        "latent_dim": args.latent_dim,
        "seed": 20260713,
        "scope": "descriptive baseline-only atlas; OOD benchmarks retrain within outer folds",
        "scvi_version": scvi.__version__,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.model_dir.parent.mkdir(parents=True, exist_ok=True)
    data.write_h5ad(args.output, compression="gzip")
    model.save(args.model_dir, overwrite=True, save_anndata=False)
    print(f"wrote {args.output} and {args.model_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
