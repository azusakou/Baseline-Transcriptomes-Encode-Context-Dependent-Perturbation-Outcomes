#!/usr/bin/env python3
"""Audit whether public single-cell matrices support defensible RNA velocity."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(); rows = []
    for path in args.input:
        source = ad.read_h5ad(path, backed="r")
        layers = list(source.layers.keys())
        eligible = {"spliced", "unspliced"}.issubset(layers)
        rows.append({
            "file": path.name, "cells": source.n_obs, "genes": source.n_vars,
            "layers": ",".join(layers) or "none", "rna_velocity_eligible": eligible,
            "decision": "run_scVelo_CellRank" if eligible else "do_not_infer_velocity_from_expression_only",
            "reason": "spliced and unspliced layers present" if eligible else "spliced/unspliced molecule counts absent",
        })
        source.file.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output, sep="\t", index=False)
    print(pd.DataFrame(rows).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
