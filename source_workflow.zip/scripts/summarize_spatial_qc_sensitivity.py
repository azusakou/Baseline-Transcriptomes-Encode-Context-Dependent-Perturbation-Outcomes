#!/usr/bin/env python3
"""Compare spatial fate results across minimum-transcript QC thresholds."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from scipy.stats import spearmanr


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", action="append", nargs=2, metavar=("LABEL", "DIR"), required=True)
    parser.add_argument("--primary-label", default="min5")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summaries = []; moran_tables = {}; patient_tables = {}
    for label, directory in args.result:
        root = Path(directory)
        qc = pd.read_csv(root / "sample_qc.tsv", sep="\t")
        moran = pd.read_csv(root / "spatial_autocorrelation.tsv", sep="\t").set_index(["sample", "feature"])
        cells = pd.read_parquet(root / "xenium_cell_states_and_niches.parquet")
        absolute = [column for column in cells if column.startswith("absolute_")]
        patient = cells.groupby("patient", observed=True)[absolute].mean()
        moran_tables[label] = moran; patient_tables[label] = patient
        summaries.extend([
            {"label": label, "comparison": "retained_cells", "feature": "all", "value": int(qc.cells_qc.sum()), "n_units": len(qc)},
            {"label": label, "comparison": "retained_fraction", "feature": "all", "value": qc.cells_qc.sum() / qc.cells_input.sum(), "n_units": len(qc)},
        ])
    primary_moran = moran_tables[args.primary_label]
    primary_patient = patient_tables[args.primary_label]
    for label in moran_tables:
        if label == args.primary_label:
            continue
        common = primary_moran.index.intersection(moran_tables[label].index)
        summaries.append({
            "label": label, "comparison": "moran_concordance_vs_primary", "feature": "all",
            "value": spearmanr(primary_moran.loc[common, "moran_i"], moran_tables[label].loc[common, "moran_i"]).statistic,
            "n_units": len(common),
        })
        common_patient = primary_patient.index.intersection(patient_tables[label].index)
        left = primary_patient.loc[common_patient].stack(); right = patient_tables[label].loc[common_patient].stack()
        summaries.append({
            "label": label, "comparison": "patient_absolute_axis_concordance_vs_primary", "feature": "all",
            "value": spearmanr(left, right).statistic, "n_units": len(left),
        })
    result = pd.DataFrame(summaries)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, sep="\t", index=False)
    print(result.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
