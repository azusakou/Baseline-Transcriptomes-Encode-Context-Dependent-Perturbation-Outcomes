#!/usr/bin/env python3
"""Create a backed sparse day-0 WOT checkpoint with parsed capture metadata."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = ad.read_h5ad(args.input, backed="r")
    keep = source.obs_names.str.startswith("D0_")
    data = source[keep].to_memory(); source.file.close()
    parsed = data.obs_names.to_series().str.extract(r"^(D(?P<day>[0-9.]+))_(?P<condition>[^_]+)_(?P<capture>C\d+)_")
    data.obs["day"] = pd.to_numeric(parsed.day.to_numpy())
    data.obs["condition"] = parsed.condition.to_numpy()
    data.obs["capture"] = parsed.capture.to_numpy()
    data.obs["dataset_id"] = "wot_reprogramming"
    data.uns["counts_status"] = "source_normalized_logTPM_variable_genes"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    data.write_h5ad(args.output, compression="gzip")
    print(f"wrote {args.output}: {data.shape}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
