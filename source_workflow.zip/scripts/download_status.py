#!/usr/bin/env python3
"""Summarize manifest download state, including partial files."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    rows = list(csv.DictReader(args.manifest.open(), delimiter="\t"))
    total_declared = complete_declared = downloaded = 0
    for row in rows:
        target = args.root / "raw" / row["dataset_id"] / row["filename"]
        partial = Path(str(target) + ".part")
        expected = int(row["bytes"]) if row["bytes"].isdigit() else 0
        total_declared += expected
        if target.exists():
            state, size = "complete", target.stat().st_size
            complete_declared += expected
        elif partial.exists():
            state, size = "partial", partial.stat().st_size
        else:
            state, size = "missing", 0
        downloaded += size
        if state != "missing":
            fraction = f"{size / expected:.1%}" if expected else "n/a"
            print(f"{row['dataset_id']}\t{row['filename']}\t{state}\t{size}\t{fraction}")
    print(f"SUMMARY\tfiles={len(rows)}\tdownloaded_bytes={downloaded}\tdeclared_complete={complete_declared}/{total_declared}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

