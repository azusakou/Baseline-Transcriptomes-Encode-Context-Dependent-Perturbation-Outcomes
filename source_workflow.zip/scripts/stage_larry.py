#!/usr/bin/env python3
"""Stage LARRY expression, metadata, and clone matrices as auditable AnnData."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmread


def find(directory: Path, suffix: str) -> Path:
    hits = [path for path in directory.glob(f"*_{suffix}") if not path.name.startswith("._")]
    if len(hits) != 1:
        raise ValueError(f"expected one *_{suffix} in {directory}, found {hits}")
    return hits[0]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--dataset-id", required=True)
    args = parser.parse_args()

    expression = mmread(find(args.input_dir, "normed_counts.mtx.gz")).tocsr()
    clones = mmread(find(args.input_dir, "clone_matrix.mtx.gz")).tocsr()
    genes = pd.read_csv(find(args.input_dir, "gene_names.txt.gz"), header=None, names=["gene_symbol"])
    metadata_path = find(args.input_dir, "metadata.txt.gz")
    metadata = pd.read_csv(metadata_path, sep="\t")
    if len(metadata.columns) == 1:
        metadata = pd.read_csv(metadata_path, sep=r"\s+", engine="python")
    if expression.shape != (len(metadata), len(genes)):
        raise ValueError(f"expression shape {expression.shape}, metadata={len(metadata)}, genes={len(genes)}")
    if clones.shape[1] == expression.shape[0] and clones.shape[0] != expression.shape[0]:
        clones = clones.transpose().tocsr()
    if clones.shape[0] != expression.shape[0]:
        raise ValueError(f"clone rows {clones.shape[0]} != expression rows {expression.shape[0]}")

    obs = metadata.copy()
    obs.columns = [str(c).strip().lower().replace(" ", "_") for c in obs.columns]
    obs.index = pd.Index([f"{args.dataset_id}:{i}" for i in range(len(obs))], name="cell_id")
    obs["dataset_id"] = args.dataset_id
    obs["task"] = "cytokine" if "cytokine" in args.dataset_id else "differentiation"
    obs["supervision"] = "gold_lineage"
    obs["clone_memberships"] = np.asarray(clones.sum(axis=1)).ravel().astype(int)
    single = obs["clone_memberships"].eq(1).to_numpy()
    clone_id = np.full(len(obs), -1, dtype=np.int64)
    rows, cols = clones.nonzero()
    clone_id[rows[single[rows]]] = cols[single[rows]]
    obs["clone_id"] = clone_id

    var = pd.DataFrame(index=pd.Index(genes["gene_symbol"].astype(str), name="gene"))
    if not var.index.is_unique:
        var.index = ad.utils.make_index_unique(var.index)
    adata = ad.AnnData(X=expression, obs=obs, var=var)
    adata.obsm["clone_membership"] = clones
    adata.uns["counts_status"] = "source_L1_normalized_counts_not_raw"
    adata.uns["supervision_tier"] = "gold"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    adata.write_h5ad(args.output, compression="gzip")
    sparse.save_npz(args.output.with_suffix(".clone_matrix.npz"), clones)
    print(f"wrote {args.output}: {adata.n_obs} cells, {adata.n_vars} genes, {clones.shape[1]} clones")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
