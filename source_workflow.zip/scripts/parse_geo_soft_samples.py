#!/usr/bin/env python3
"""Extract sample-level metadata and characteristics from a GEO family SOFT."""

from __future__ import annotations

import argparse
import gzip
import re
from pathlib import Path

import pandas as pd


def normalize_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.strip().lower()).strip("_")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    opener = gzip.open if args.input.suffix == ".gz" else open
    rows: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    with opener(args.input, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\n")
            if line.startswith("^SAMPLE = "):
                if current is not None:
                    rows.append(current)
                current = {"geo_accession": line.split("=", 1)[1].strip()}
            elif current is None:
                continue
            elif line.startswith("!Sample_characteristics_ch1 = "):
                value = line.split("=", 1)[1].strip()
                if ":" in value:
                    key, item = value.split(":", 1)
                    current[normalize_key(key)] = item.strip()
            elif line.startswith("!Sample_title = "):
                current["sample_title"] = line.split("=", 1)[1].strip()
            elif line.startswith("!Sample_platform_id = "):
                current["platform_id"] = line.split("=", 1)[1].strip()
        if current is not None:
            rows.append(current)
    table = pd.DataFrame(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.output, sep="\t", index=False)
    print(f"wrote {len(table)} samples; columns={list(table.columns)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
