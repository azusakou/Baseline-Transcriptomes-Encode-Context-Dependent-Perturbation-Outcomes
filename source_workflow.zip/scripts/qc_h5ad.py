#!/usr/bin/env python3
"""Add distribution-derived QC flags and threshold-justification plots."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


def mad(values: np.ndarray) -> float:
    center = np.nanmedian(values)
    return float(np.nanmedian(np.abs(values - center)) * 1.4826)


def thresholds(frame: pd.DataFrame) -> dict[str, float]:
    log_genes = np.log1p(frame["n_genes_by_counts"].to_numpy(float))
    log_counts = np.log1p(frame["total_counts"].to_numpy(float))
    pct = frame["pct_counts_mt"].to_numpy(float)
    result = {
        "min_genes": float(max(1, np.expm1(np.nanmedian(log_genes) - 3 * mad(log_genes)))),
        "max_genes": float(np.expm1(np.nanmedian(log_genes) + 5 * mad(log_genes))),
        "min_counts": float(max(1, np.expm1(np.nanmedian(log_counts) - 3 * mad(log_counts)))),
        "max_counts": float(np.expm1(np.nanmedian(log_counts) + 5 * mad(log_counts))),
        "max_pct_mt": float(min(np.nanquantile(pct, 0.995), np.nanmedian(pct) + 5 * mad(pct))),
    }
    if not np.isfinite(result["max_pct_mt"]) or result["max_pct_mt"] <= np.nanmedian(pct):
        result["max_pct_mt"] = float(np.nanquantile(pct, 0.995))
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report-dir", type=Path, required=True)
    parser.add_argument("--batch-column", default="batch")
    args = parser.parse_args()
    adata = ad.read_h5ad(args.input)
    required = {"n_genes_by_counts", "total_counts", "pct_counts_mt"}
    missing = required - set(adata.obs)
    if missing:
        raise ValueError(f"missing QC columns: {sorted(missing)}")
    args.report_dir.mkdir(parents=True, exist_ok=True)
    groups = adata.obs.groupby(args.batch_column, observed=True).indices
    manifest = {}
    passes = pd.Series(True, index=adata.obs_names)
    reasons = pd.Series("", index=adata.obs_names, dtype="string")
    for batch, indices in groups.items():
        names = adata.obs_names[np.asarray(indices)]
        frame = adata.obs.loc[names]
        cut = thresholds(frame)
        manifest[str(batch)] = cut
        tests = {
            "low_genes": frame["n_genes_by_counts"] < cut["min_genes"],
            "high_genes": frame["n_genes_by_counts"] > cut["max_genes"],
            "low_counts": frame["total_counts"] < cut["min_counts"],
            "high_counts": frame["total_counts"] > cut["max_counts"],
            "high_mt": frame["pct_counts_mt"] > cut["max_pct_mt"],
        }
        for reason, flag in tests.items():
            passes.loc[names] &= ~flag
            flagged = names[flag.to_numpy()]
            reasons.loc[flagged] = reasons.loc[flagged].map(lambda x: f"{x};{reason}".strip(";"))
    if "scDblFinder_class" in adata.obs:
        doublet = adata.obs["scDblFinder_class"].astype(str).eq("doublet")
        passes &= ~doublet
        reasons.loc[doublet] = reasons.loc[doublet].map(lambda x: f"{x};doublet".strip(";"))
    adata.obs["passes_qc_auto"] = passes.to_numpy()
    adata.obs["qc_failure_reasons"] = reasons.to_numpy()
    if "source_passes_qc" in adata.obs:
        source_pass = adata.obs["source_passes_qc"].fillna(False).astype(bool)
        adata.obs["passes_qc_final"] = (passes & source_pass).to_numpy()
        adata.uns["qc_final_policy"] = "intersection of harmonized auto QC and source-author normal-singlet QC"
    else:
        adata.obs["passes_qc_final"] = passes.to_numpy()
        adata.uns["qc_final_policy"] = "harmonized auto QC; no source-author QC field available"
    adata.uns["qc_thresholds"] = manifest
    adata.uns["qc_policy"] = "per-batch robust candidate thresholds: 3 MAD lower, 5 MAD upper; mt capped at 99.5th percentile; scDblFinder doublets excluded"

    fig, axes = plt.subplots(1, 3, figsize=(12, 3.6))
    sns.histplot(adata.obs, x="n_genes_by_counts", hue="passes_qc_auto", bins=80, ax=axes[0], element="step")
    sns.histplot(adata.obs, x="total_counts", hue="passes_qc_auto", bins=80, ax=axes[1], element="step")
    sns.histplot(adata.obs, x="pct_counts_mt", hue="passes_qc_auto", bins=80, ax=axes[2], element="step")
    fig.tight_layout()
    fig.savefig(args.report_dir / "qc_threshold_justification.png", dpi=180)
    plt.close(fig)
    (args.report_dir / "qc_thresholds.json").write_text(json.dumps(manifest, indent=2))
    final_passes = adata.obs["passes_qc_final"].astype(bool)
    pd.DataFrame({"metric": ["input_cells", "passes_qc_auto", "passes_qc_final", "fails_qc_final"], "cells": [adata.n_obs, int(passes.sum()), int(final_passes.sum()), int((~final_passes).sum())]}).to_csv(args.report_dir / "qc_summary.tsv", sep="\t", index=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    adata.write_h5ad(args.output, compression="gzip")
    print(f"wrote {args.output}; passes={passes.sum()}/{adata.n_obs}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
