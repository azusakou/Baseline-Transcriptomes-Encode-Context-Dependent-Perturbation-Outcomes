#!/usr/bin/env python3
"""Assemble release-ready Future Cell Fate Resource tables and manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--external-root", type=Path, default=Path("/Volumes/wang/paper6yhn"))
    args = parser.parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    project_root = args.project_root.resolve()
    external_root = args.external_root.resolve()
    local = lambda path: project_root / path
    external = lambda path: external_root / path
    sources = {
        "mixseq_future_fate_pairs.tsv": local("tables/mixseq_fate_targets_all_with_resistance.tsv"),
        "larry_in_vitro_clone_fates.tsv": local("tables/larry_in_vitro_clone_targets.tsv"),
        "larry_cytokine_clone_fates.tsv": local("tables/larry_cytokine_clone_targets.tsv"),
        "wot_transport_fates.parquet": local("tables/wot_future_fate_targets.parquet"),
        "intrinsic_fate_axis_weights.tsv": external("models/intrinsic_fate_axis_mapper_all/intrinsic_fate_axis_weights.tsv"),
        "mixseq_leave_cell_line_metrics.tsv": external("results/mixseq_future_fate_benchmark_all/leave_cell_line_metrics.tsv"),
        "mixseq_leave_perturbation_metrics.tsv": external("results/mixseq_future_fate_benchmark_all/leave_perturbation_metrics.tsv"),
        "larry_in_vitro_clone_heldout_metrics.tsv": external("results/larry_in_vitro_benchmark_clone_aggregated/clone_heldout_metrics.tsv"),
        "larry_cytokine_clone_heldout_metrics.tsv": external("results/larry_cytokine_benchmark_clone_aggregated/clone_heldout_metrics.tsv"),
        "larry_leave_dataset_metrics.tsv": external("results/larry_leave_dataset_clone_aggregated/leave_dataset_metrics.tsv"),
        "cross_task_dataset_generalization_metrics.tsv": external("results/cross_task_dataset_generalization/generalization_metrics.tsv"),
        "wot_replicate_heldout_metrics.tsv": external("results/wot_baseline_benchmark/replicate_heldout_metrics.tsv"),
        "ispy2_patient_fate_embedding.parquet": external("results/patient_fate_embedding/ispy2/patient_fate_embedding.parquet"),
        "beataml_patient_fate_embedding.parquet": external("results/patient_fate_embedding/beataml/patient_fate_embedding.parquet"),
        "ispy2_clinical_validation.tsv": external("results/patient_fate_embedding/ispy2/clinical_validation.tsv"),
        "beataml_clinical_validation.tsv": external("results/patient_fate_embedding/beataml/clinical_validation.tsv"),
        "key_results_with_fold_ci.tsv": local("reports/key_results.tsv"),
        "literature_evidence.tsv": local("reports/literature_evidence.tsv"),
        "dataset_inventory.tsv": local("reports/dataset_inventory.tsv"),
        "velocity_eligibility.tsv": local("reports/velocity_eligibility.tsv"),
    }
    optional_sources = {
        "mixseq_target_sensitivity.tsv": external("results/mixseq_sensitivity/sensitivity_summary.tsv"),
        "replogle_k562_future_fate_targets.tsv": Path("tables/replogle_k562_fate_targets.tsv"),
        "replogle_k562_generalization_metrics.tsv": Path("results/replogle_k562_future_fate/metrics.tsv"),
        "replogle_k562_baseline_increment.tsv": Path("reports/replogle_k562_ablation.tsv"),
        "replogle_rpe1_future_fate_targets.tsv": Path("tables/replogle_rpe1_fate_targets.tsv"),
        "replogle_rpe1_generalization_metrics.tsv": Path("results/replogle_rpe1_generalization/metrics.tsv"),
        "replogle_rpe1_baseline_increment.tsv": Path("reports/replogle_rpe1_ablation.tsv"),
        "replogle_rpe1_qc_summary.tsv": Path("tables/replogle_rpe1_fate_targets.summary.tsv"),
        "replogle_rpe1_download_verification.tsv": Path("reports/replogle_rpe1_download_verification.tsv"),
        "intrinsic_fate_axis_fold_weights.tsv": Path("results/intrinsic_fate_axis_mapper_stability/intrinsic_fate_axis_fold_weights.tsv"),
        "intrinsic_fate_axis_stability.tsv": Path("results/intrinsic_fate_axis_mapper_stability/intrinsic_fate_axis_stability.tsv"),
        "xenium_cell_states_and_niches.parquet": Path("results/xenium_future_niches/xenium_cell_states_and_niches.parquet"),
        "xenium_pseudospot_deconvolution.parquet": Path("results/xenium_future_niches/xenium_pseudospot_deconvolution.parquet"),
        "xenium_spatial_autocorrelation.tsv": Path("results/xenium_future_niches/spatial_autocorrelation.tsv"),
        "xenium_joint_model_metrics.tsv": Path("results/xenium_future_niches/joint_model_metrics.tsv"),
        "xenium_paired_future_targets.tsv": Path("results/xenium_future_targets/patient_future_targets.tsv"),
        "xenium_baseline_spots_with_future_targets.parquet": Path("results/xenium_future_targets/baseline_spots_with_future_targets.parquet"),
        "xenium_common_spatial_niches.tsv": Path("results/xenium_future_niches/common_spatial_niches.tsv"),
        "xenium_sample_absolute_programs.tsv": Path("results/xenium_future_niches/sample_absolute_programs.tsv"),
        "xenium_sample_qc.tsv": Path("results/xenium_future_niches/sample_qc.tsv"),
        "xenium_panel_module_coverage.tsv": Path("results/xenium_future_niches/targeted_panel_module_coverage.tsv"),
        "xenium_ligand_receptor_provenance.tsv": Path("results/xenium_future_niches/ligand_receptor_provenance.tsv"),
        "xenium_spatial_qc_sensitivity.tsv": Path("reports/spatial_qc_sensitivity.tsv"),
    }
    optional_sources = {name: path if path.is_absolute() else local(path) for name, path in optional_sources.items()}
    sources.update({name: path for name, path in optional_sources.items() if path.exists()})
    manifest = []
    for name, source in sources.items():
        target = args.output_dir / name
        shutil.copy2(source, target)
        if target.suffix == ".parquet": rows = pq.ParquetFile(target).metadata.num_rows
        else: rows = sum(1 for _ in target.open()) - 1
        manifest.append({"file": name, "rows": rows, "bytes": target.stat().st_size, "sha256": sha256(target)})
    pd.DataFrame(manifest).to_csv(args.output_dir / "manifest.tsv", sep="\t", index=False)
    dictionary = {
        "evidence_tiers": {
            "gold": "LARRY clone-linked descendant fate probabilities",
            "silver": "WOT optimal-transport transition probabilities",
            "derived": "MIX-seq matched-control continuous fate-program probabilities",
            "genetic_derived": "Replogle matched-control genetic perturbation program probabilities",
            "spatial_exploratory": "patient-blocked Xenium baseline niche features and paired tissue-state summaries",
            "clinical_projection": "cross-validated patient fate embeddings; not cell-level lineage observations",
        },
        "probability_policy": "Branch/program probabilities are bounded [0,1]. external_resistance_quantile is an empirical PRISM/GDSC AUC quantile, not a calibrated event probability.",
        "leakage_policy": "Baseline-only expression defines predictors; clone, cell line, perturbation, task and dataset grouping are respected in the corresponding outer validation. Replogle held-GEM PCA is fit on training-GEM controls only. Spatial response is never modeled at cell level.",
        "spatial_score_policy": "intrinsic_* scores are within-sample standardized and used for spatial patterning; absolute_* scores are fixed-panel log-normalized module means used for paired pre/post changes. Neither is a calibrated event probability.",
    }
    (args.output_dir / "data_dictionary.json").write_text(json.dumps(dictionary, indent=2) + "\n")
    print(pd.DataFrame(manifest).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
