#!/usr/bin/env python3
"""Snapshot PROGENy, CollecTRI and Hallmark networks used for fate-axis attribution."""

from __future__ import annotations

import argparse
from pathlib import Path

import decoupler as dc


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for organism in ["human", "mouse"]:
        networks = {
            "progeny": dc.op.progeny(organism=organism, top=500),
            "collectri": dc.op.collectri(organism=organism),
            "hallmark": dc.op.hallmark(organism=organism),
        }
        for name, network in networks.items():
            path = args.output_dir / f"{name}_{organism}.tsv.gz"
            network.to_csv(path, sep="\t", index=False, compression="gzip")
            print(f"wrote {path}: {network.shape}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
