#!/usr/bin/env python3
"""Recompute manuscript-facing claims from frozen figure source data.

This is a release gate, not an analysis script: it fails when a reported value,
resource checksum or required submission artifact diverges from its source.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=Path("reports/manuscript_consistency_audit.tsv"))
    args = parser.parse_args()
    root = args.root.resolve()
    source = root / "figures/source_data"
    rows: list[dict[str, object]] = []

    def check(name: str, observed: object, expected: object, origin: str, tolerance: float = 0.0) -> None:
        if isinstance(expected, (int, float)) and isinstance(observed, (int, float, np.number)):
            passed = bool(np.isfinite(float(observed)) and abs(float(observed) - float(expected)) <= tolerance)
        else:
            passed = observed == expected
        rows.append({"check": name, "observed": observed, "expected": expected,
                     "tolerance": tolerance, "pass": passed, "source": origin})

    inventory = pd.read_csv(root / "reports/dataset_inventory.tsv", sep="\t")
    counts = dict(zip(inventory.dataset, inventory.qc_cells_or_targets))
    for dataset, expected in {
        "MIX-seq": "146228 cells; 1115 pairs",
        "LARRY in vitro": "3321 clone targets",
        "LARRY cytokine": "2599 clone-condition targets",
        "Waddington-OT": "162093 transport targets",
        "Replogle K562 essential": "276108 cells; 2151 pairs",
        "Replogle RPE1": "225098 cells; 1472 pairs",
        "GSE291246 pretreatment": "121239 cells; 439 pseudo-spots",
        "I-SPY2": "987 patients",
        "BeatAML 2.0": "398 patients",
    }.items():
        check(f"inventory: {dataset}", counts.get(dataset), expected, "reports/dataset_inventory.tsv")

    key = pd.read_csv(root / "reports/key_results.tsv", sep="\t")
    def key_value(source_name: str, validation: str, target: str, model: str, metric: str) -> float:
        hit = key[(key.source == source_name) & (key.validation == validation) &
                  (key.target == target) & (key.model == model) & (key.metric == metric)]
        if len(hit) != 1:
            return np.nan
        return float(hit.estimate.iloc[0])

    numeric_claims = [
        ("LARRY in vitro branch Brier", "LARRY in vitro", "leave_clone", "branch_macro", "baseline_latent_ridge", "brier", 0.02815787, 5e-8),
        ("LARRY cytokine branch Brier", "LARRY cytokine", "leave_clone", "branch_macro", "baseline_latent_ridge", "brier", 0.03466356, 5e-8),
        ("LARRY in vitro top-branch accuracy", "LARRY in vitro", "leave_clone", "branch_macro", "baseline_latent_ridge", "top_branch_accuracy", 0.68774391, 5e-8),
        ("LARRY cytokine top-branch accuracy", "LARRY cytokine", "leave_clone", "branch_macro", "baseline_latent_ridge", "top_branch_accuracy", 0.70796502, 5e-8),
        ("LARRY in vitro differentiation Spearman", "LARRY in vitro", "leave_clone", "p_differentiation", "baseline_latent_ridge", "spearman", 0.63050726, 5e-8),
        ("LARRY cytokine differentiation Spearman", "LARRY cytokine", "leave_clone", "p_differentiation", "baseline_latent_ridge", "spearman", 0.42749743, 5e-8),
        ("MIX leave-cell-line apoptosis Brier", "MIX-seq", "leave_cell_line", "p_apoptosis", "baseline_scvi_ridge", "brier", 0.020470, 5e-7),
        ("MIX leave-cell-line stress Spearman", "MIX-seq", "leave_cell_line", "p_stress", "baseline_scvi_ridge", "spearman", 0.473101, 5e-7),
        ("LARRY leave-dataset differentiation Spearman", "LARRY", "leave_dataset", "p_differentiation", "baseline_expression_svd_ridge", "spearman", 0.44254405, 5e-8),
    ]
    for name, src, validation, target, model, metric, expected, tol in numeric_claims:
        check(name, key_value(src, validation, target, model, metric), expected,
              "reports/key_results.tsv", tol)

    sensitivity = pd.read_csv(source / "figure3/mixseq_target_sensitivity.tsv", sep="\t")
    brier = sensitivity[sensitivity.metric.eq("brier")]
    wide = brier.pivot_table(index=["variant", "validation", "target"], columns="model", values="mean_value").reset_index()
    wide["improved"] = wide.baseline_scvi_ridge < wide.training_mean
    for target, expected in {"p_apoptosis": 12, "p_proliferation": 8, "p_stress": 12}.items():
        observed = int(wide[(wide.validation == "leave_cell_line") & (wide.target == target)].improved.sum())
        check(f"12-setting leave-cell-line improvement: {target}", observed, expected,
              "figure3/mixseq_target_sensitivity.tsv")
    observed = int(wide[(wide.validation == "leave_perturbation") & (wide.target == "p_stress")].improved.sum())
    check("12-setting leave-perturbation stress improvement", observed, 0,
          "figure3/mixseq_target_sensitivity.tsv")
    concordance = sensitivity[sensitivity.validation.eq("target_concordance")].groupby("target").mean_value.median()
    check("sensitivity concordance lower median", float(concordance.min()), 0.8905864,
          "figure3/mixseq_target_sensitivity.tsv", 5e-7)
    check("sensitivity concordance upper median", float(concordance.max()), 0.9378833,
          "figure3/mixseq_target_sensitivity.tsv", 5e-7)

    for label, target, expected, low, high in [
        ("K562 apoptosis increment", "k562", 0.04368913, 0.01563439, 0.07174386),
        ("RPE1 stress increment", "rpe1", 0.11573302, 0.02685792, 0.20460810),
    ]:
        data = pd.read_csv(source / f"figure3/replogle_{target}_ablation.tsv", sep="\t")
        fate = "p_apoptosis" if target == "k562" else "p_stress"
        hit = data[(data.validation == "leave_perturbation") & (data.target == fate) & (data.metric == "spearman")].iloc[0]
        check(label, float(hit.baseline_state_increment), expected, f"figure3/replogle_{target}_ablation.tsv", 5e-8)
        check(label + " CI low", float(hit.ci_low), low, f"figure3/replogle_{target}_ablation.tsv", 5e-8)
        check(label + " CI high", float(hit.ci_high), high, f"figure3/replogle_{target}_ablation.tsv", 5e-8)

    wot = pd.read_csv(source / "figure4/wot_replicate_metrics.tsv", sep="\t")
    macro = wot[(wot.branch == "macro") & (wot.metric == "brier")].groupby("model").value.mean()
    branch = wot[(wot.branch != "macro") & (wot.metric == "spearman")].groupby("model").value.mean()
    for name, observed, expected, tol in [
        ("WOT latent Brier", macro["baseline_latent_ridge"], 6.965736e-6, 5e-12),
        ("WOT mean Brier", macro["training_mean"], 5.810127e-5, 5e-11),
        ("WOT latent branch correlation", branch["baseline_latent_ridge"], 0.9382070, 5e-7),
        ("WOT biological-axis branch correlation", branch["biological_program_ridge"], 0.8000396, 5e-7),
    ]:
        check(name, float(observed), expected, "figure4/wot_replicate_metrics.tsv", tol)

    axes = pd.read_csv(source / "figure4/axis_stability_counts.tsv", sep="\t").set_index("target")
    for target, expected in {"p_apoptosis": 301, "p_proliferation": 300, "p_stress": 290,
                             "external_resistance_quantile": 320}.items():
        check(f"sign-stable axes: {target}", int(axes.loc[target, "stable_axes"]), expected,
              "figure4/axis_stability_counts.tsv")

    spatial = pd.read_csv(source / "figure5/spatial_autocorrelation.tsv", sep="\t")
    spatial_means = spatial.groupby("feature").moran_i.mean()
    for feature, expected in {
        "intrinsic_resistance_ecosystem": 0.3118692,
        "intrinsic_stress": 0.1794678,
        "intrinsic_proliferation": 0.1746776,
        "intrinsic_differentiation_proxy": 0.0711270,
        "intrinsic_apoptosis_pressure": 0.0493501,
    }.items():
        check(f"spatial Moran mean: {feature}", float(spatial_means[feature]), expected,
              "figure5/spatial_autocorrelation.tsv", 5e-7)
    check("Moran permutation P=0.005 count", int((spatial.permutation_pvalue == 0.005).sum()), 39,
          "figure5/spatial_autocorrelation.tsv")
    check("Moran permutation P=0.015 count", int((spatial.permutation_pvalue == 0.015).sum()), 1,
          "figure5/spatial_autocorrelation.tsv")

    joint = pd.read_csv(source / "figure5/joint_model_metrics.tsv", sep="\t")
    mae = joint[joint.metric.eq("mae")].set_index("model").value
    for model, expected in {"training_patient_mean": 40.33333, "intrinsic": 42.18524,
                            "spatial_niche": 40.81281, "joint": 42.46160}.items():
        check(f"spatial LOPO MAE: {model}", float(mae[model]), expected,
              "figure5/joint_model_metrics.tsv", 5e-5)

    cv = pd.read_csv(source / "figure6/clinical_cross_validation.tsv", sep="\t")
    cv_mean = cv.groupby(["cohort", "metric"]).value.mean()
    for cohort, metric, expected in [
        ("ISPY2", "auroc", 0.6545313), ("ISPY2", "average_precision", 0.4553608),
        ("ISPY2", "balanced_accuracy", 0.5956951), ("BEATAML", "auroc", 0.6304506),
        ("BEATAML", "average_precision", 0.7436198), ("BEATAML", "balanced_accuracy", 0.5873103),
    ]:
        check(f"clinical CV: {cohort} {metric}", float(cv_mean.loc[(cohort, metric)]), expected,
              "figure6/clinical_cross_validation.tsv", 5e-7)

    clinical = pd.read_csv(source / "figure6/clinical_validation.tsv", sep="\t")
    cox = clinical[(clinical.cohort == "BEATAML") &
                   (clinical.analysis == "overall_survival_cox") &
                   (clinical.term == "cross_fitted_response_probability")].iloc[0]
    for label, observed, expected in [("BeatAML Cox HR", cox.estimate, 0.7538047),
                                      ("BeatAML Cox CI low", cox.ci_low, 0.6608956),
                                      ("BeatAML Cox CI high", cox.ci_high, 0.8597749),
                                      ("BeatAML Cox P", cox.pvalue, 2.539414e-5)]:
        check(label, float(observed), expected, "figure6/clinical_validation.tsv", 5e-7)

    resource = root / "resource/Future_Cell_Fate_Resource_v0.2"
    manifest = pd.read_csv(resource / "manifest.tsv", sep="\t")
    check("resource file count", len(manifest), 43, "resource/Future_Cell_Fate_Resource_v0.2/manifest.tsv")
    mismatches = 0
    missing = 0
    for row in manifest.itertuples(index=False):
        path = resource / row.file
        if not path.exists():
            missing += 1
        elif digest(path) != row.sha256:
            mismatches += 1
    check("resource missing files", missing, 0, "resource manifest + files")
    check("resource checksum mismatches", mismatches, 0, "resource manifest + files")

    for figure in range(1, 8):
        matches = list((root / "figures/main").glob(f"Figure{figure}_*.pdf"))
        check(f"main Figure {figure} PDF count", len(matches), 1, "figures/main")
    check("main manuscript PDF exists", (root / "manuscript/build/main.pdf").exists(), True, "manuscript/build/main.pdf")
    check("supplementary PDF exists", (root / "manuscript/build/supplementary.pdf").exists(), True,
          "manuscript/build/supplementary.pdf")

    result = pd.DataFrame(rows)
    output = args.output if args.output.is_absolute() else root / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, sep="\t", index=False)
    failed = result.loc[~result["pass"]]
    print(f"{len(result) - len(failed)}/{len(result)} checks passed; wrote {output}")
    if len(failed):
        print(failed[["check", "observed", "expected", "source"]].to_string(index=False))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
