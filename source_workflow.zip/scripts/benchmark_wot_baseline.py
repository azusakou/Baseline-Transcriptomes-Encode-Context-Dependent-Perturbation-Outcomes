#!/usr/bin/env python3
"""Benchmark day-0 baseline expression against WOT-derived future probabilities."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import joblib
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import Ridge


def normalize_probabilities(values: np.ndarray) -> np.ndarray:
    result = np.clip(values, 0, 1)
    total = result.sum(axis=1, keepdims=True)
    return np.divide(result, total, out=np.full_like(result, 1 / result.shape[1]), where=total > 0)


def metrics(observed: np.ndarray, predicted: np.ndarray, branches: list[str]) -> list[dict[str, object]]:
    rows = [{"branch": "macro", "metric": "brier", "value": float(np.mean((observed - predicted) ** 2))}]
    for index, branch in enumerate(branches):
        correlation = spearmanr(observed[:, index], predicted[:, index]).statistic
        rows.extend([
            {"branch": branch, "metric": "brier", "value": float(np.mean((observed[:, index] - predicted[:, index]) ** 2))},
            {"branch": branch, "metric": "spearman", "value": float(correlation)},
        ])
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expression", type=Path, required=True)
    parser.add_argument("--cell-days", type=Path, required=True)
    parser.add_argument("--batches", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--gene-set-scores", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--latent-dim", type=int, default=50)
    args = parser.parse_args()
    days = pd.read_csv(args.cell_days, sep="\t", index_col=0)
    batches = pd.read_csv(args.batches, sep="\t", index_col=0)
    targets = pd.read_parquet(args.targets).set_index("cell_id")
    target_columns = [column for column in targets if column.startswith("p_branch_")]
    branches = [column.removeprefix("p_branch_") for column in target_columns]
    baseline_ids = targets.index[targets.day.eq(0)]

    data = ad.read_h5ad(args.expression, backed="r")
    positions = data.obs_names.get_indexer(baseline_ids)
    if (positions < 0).any():
        raise ValueError(f"{(positions < 0).sum()} day-0 target cells absent from expression")
    baseline = data[positions].to_memory()
    data.file.close()
    y = targets.loc[baseline_ids, target_columns].to_numpy(float)
    groups = batches.loc[baseline_ids, "covariate"].astype(str).to_numpy()
    unique_groups = np.unique(groups)
    if len(unique_groups) < 2:
        raise ValueError("replicate-held-out benchmark requires at least two batches")

    gene_sets = pd.read_csv(args.gene_set_scores, index_col=0).loc[baseline_ids]
    score_features = gene_sets.to_numpy(float)
    rows = []
    prediction_rows = []
    for held_out in unique_groups:
        train = groups != held_out
        test = ~train
        mean_prediction = np.repeat(y[train].mean(axis=0, keepdims=True), test.sum(), axis=0)
        for row in metrics(y[test], mean_prediction, branches):
            rows.append({"model": "training_mean", "held_out_batch": held_out, **row})

        score_model = Ridge(alpha=10.0).fit(score_features[train], y[train])
        score_prediction = normalize_probabilities(score_model.predict(score_features[test]))
        for row in metrics(y[test], score_prediction, branches):
            rows.append({"model": "biological_program_ridge", "held_out_batch": held_out, **row})

        svd = TruncatedSVD(n_components=args.latent_dim, random_state=20260713)
        train_latent = svd.fit_transform(baseline.X[train])
        test_latent = svd.transform(baseline.X[test])
        latent_model = Ridge(alpha=10.0).fit(train_latent, y[train])
        latent_prediction = normalize_probabilities(latent_model.predict(test_latent))
        for row in metrics(y[test], latent_prediction, branches):
            rows.append({"model": "baseline_latent_ridge", "held_out_batch": held_out, **row})
        frame = pd.DataFrame(latent_prediction, index=baseline_ids[test], columns=[f"pred_{branch}" for branch in branches])
        frame["held_out_batch"] = held_out
        prediction_rows.append(frame.reset_index())

    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output_dir / "replicate_heldout_metrics.tsv", sep="\t", index=False)
    pd.concat(prediction_rows, ignore_index=True).to_csv(args.output_dir / "replicate_heldout_predictions.tsv", sep="\t", index=False)

    final_svd = TruncatedSVD(n_components=args.latent_dim, random_state=20260713)
    latent = final_svd.fit_transform(baseline.X)
    latent_frame = pd.DataFrame(latent, index=baseline_ids, columns=[f"latent_{i + 1}" for i in range(latent.shape[1])])
    latent_frame.to_parquet(args.output_dir / "day0_baseline_latent.parquet")
    joblib.dump(final_svd, args.output_dir / "day0_svd.joblib")
    summary = pd.DataFrame(rows).query("branch == 'macro' and metric == 'brier'").groupby("model").value.mean()
    print(summary.to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
