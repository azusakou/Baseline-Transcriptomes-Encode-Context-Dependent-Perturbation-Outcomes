#!/usr/bin/env python3
"""Attach source-author PRISM/GDSC resistance ranks to MIX-seq fate pairs."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    targets = pd.read_csv(args.targets, sep="\t")
    features = pd.read_csv(args.features, sep="\t", low_memory=False)
    experiment_number = targets.experiment.astype(str).str.extract(r"(\d+)$", expand=False)
    timed = targets.time_hours.notna()
    comparison = targets.perturbation.astype(str) + "_expt" + experiment_number
    comparison.loc[timed] = (
        targets.loc[timed, "perturbation"].astype(str)
        + "_" + targets.loc[timed, "time_hours"].astype(int).astype(str)
        + "hr_expt" + experiment_number.loc[timed]
    )
    targets["source_comparison"] = comparison
    external = features.loc[
        features.AUC_avg.notna(), ["source_comparison", "CCLE_ID", "AUC_avg", "PRISM_AUC", "GDSC_AUC"]
    ].copy()
    # AUC is the source study's cross-platform resistance measure. Its within-
    # comparison empirical CDF is bounded and interpretable, but not claimed to
    # be a calibrated event probability.
    external["external_resistance_quantile"] = external.groupby("source_comparison").AUC_avg.rank(
        method="average", pct=True
    )
    external = external.drop_duplicates(["source_comparison", "CCLE_ID"])
    result = targets.merge(
        external,
        left_on=["source_comparison", "cell_line"],
        right_on=["source_comparison", "CCLE_ID"],
        how="left",
        validate="many_to_one",
    ).drop(columns="CCLE_ID")
    result["resistance_target_type"] = np.where(
        result.external_resistance_quantile.notna(), "external_PRISM_GDSC_empirical_quantile", "unavailable"
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, sep="\t", index=False)
    print(
        f"wrote {len(result)} pairs; external resistance available for "
        f"{result.external_resistance_quantile.notna().sum()} ({result.external_resistance_quantile.notna().mean():.1%})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
