#!/usr/bin/env python3
"""Stage the normalized I-SPY2 expression matrix with GEO clinical metadata."""

from __future__ import annotations

import argparse
import gzip
from collections import Counter, defaultdict
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd


def occurrence_keys(values: list[str]) -> list[str]:
    seen: defaultdict[str, int] = defaultdict(int)
    result = []
    for value in values:
        seen[value] += 1
        result.append(f"{value}#{seen[value]}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expression", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    opener = gzip.open if args.expression.suffix == ".gz" else open
    with opener(args.expression, "rt") as handle:
        patient_ids = handle.readline().rstrip("\n").split("\t")
    expression = pd.read_csv(
        args.expression, sep="\t", header=None, skiprows=1, index_col=0,
        dtype={index: np.float32 for index in range(1, len(patient_ids) + 1)},
        na_values=["NA", ""], low_memory=False,
    )
    if expression.shape[1] != len(patient_ids):
        raise ValueError(f"matrix columns {expression.shape[1]} != header IDs {len(patient_ids)}")
    metadata = pd.read_csv(args.metadata, sep="\t", dtype=str)
    metadata_ids = metadata["sample_title"].astype(str).str.removeprefix("ISPY2_").tolist()
    if Counter(patient_ids) != Counter(metadata_ids):
        raise ValueError("sample identifiers differ between expression header and SOFT metadata")
    metadata.index = pd.Index(occurrence_keys(metadata_ids), name="source_sample_key")
    metadata = metadata.loc[occurrence_keys(patient_ids)].copy()
    metadata.index.name = "sample_id"
    expression.columns = metadata.index
    var = pd.DataFrame(index=pd.Index(expression.index.astype(str), name="gene"))
    var["gene_symbol"] = var.index
    if not var.index.is_unique:
        var.index = ad.utils.make_index_unique(var.index)
    data = ad.AnnData(X=expression.to_numpy(dtype=np.float32).T, obs=metadata, var=var)
    data.obs["dataset_id"] = "gse194040_ispy2"
    data.obs["timepoint"] = "pretreatment"
    for column in ["hr", "her2", "mp", "pcr"]:
        data.obs[column] = pd.to_numeric(data.obs[column], errors="coerce").astype("Int8")
    data.uns["expression_status"] = "source_normalized_log2_ComBat_platform_adjusted"
    data.uns["clinical_endpoint"] = "pathological_complete_response"
    data.uns["source_accession"] = "GSE194040"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    data.write_h5ad(args.output, compression="gzip")
    print(f"wrote {args.output}; shape={data.shape}; unique_patients={data.obs.patient_id.nunique()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
