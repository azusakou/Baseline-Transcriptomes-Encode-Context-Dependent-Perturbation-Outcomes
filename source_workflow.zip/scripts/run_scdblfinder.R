#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(SingleCellExperiment)
  library(scDblFinder)
})

# xgboost 3 emits deprecation warnings through the current scDblFinder release;
# they do not alter calls and otherwise dominate resumable batch logs.
options(warn = -1)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3) {
  stop("usage: run_scdblfinder.R counts.mtx.gz cells.tsv output.tsv")
}

counts_path <- args[[1]]
cells_path <- args[[2]]
output_path <- args[[3]]

counts <- readMM(gzfile(counts_path))
cells <- read.delim(cells_path, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
if (ncol(counts) != nrow(cells)) {
  stop(sprintf("matrix columns (%d) != cells (%d)", ncol(counts), nrow(cells)))
}

set.seed(20260713)
sce <- SingleCellExperiment(list(counts = counts))
colnames(sce) <- cells$cell_id
sce <- scDblFinder(sce, samples = cells$batch)
result <- data.frame(
  cell_id = colnames(sce),
  scDblFinder.score = colData(sce)$scDblFinder.score,
  scDblFinder.class = as.character(colData(sce)$scDblFinder.class),
  stringsAsFactors = FALSE
)
write.table(result, output_path, sep = "\t", quote = FALSE, row.names = FALSE)
