#!/usr/bin/env python3
"""Stage BeatAML 2022 expression, clinical, mutation and blood measurements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse


def clinical_table(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", comment="#", dtype=str, na_values=["NA", ""])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    expression = pd.read_csv(
        args.raw_dir / "data_mrna_seq_rpkm.txt", sep="\t", index_col=0,
        dtype={0: str}, na_values=["NA", ""], low_memory=False,
    )
    expression = expression.apply(pd.to_numeric, errors="coerce").astype(np.float32)
    sample = clinical_table(args.raw_dir / "data_clinical_sample.txt").set_index("SAMPLE_ID", drop=False)
    patient = clinical_table(args.raw_dir / "data_clinical_patient.txt").set_index("PATIENT_ID", drop=False)
    missing = set(expression.columns) - set(sample.index)
    if missing:
        raise ValueError(f"{len(missing)} RNA samples missing clinical annotation")
    obs = sample.loc[expression.columns].copy()
    patient_columns = [column for column in patient if column != "PATIENT_ID" and column not in obs]
    obs = obs.join(patient[patient_columns], on="PATIENT_ID")
    obs.index = pd.Index(expression.columns, name="sample_id")
    obs["dataset_id"] = "aml_ohsu_2022"

    var = pd.DataFrame(index=pd.Index(expression.index.astype(str), name="gene"))
    if not var.index.is_unique:
        var.index = ad.utils.make_index_unique(var.index)
    data = ad.AnnData(X=expression.to_numpy(dtype=np.float32).T, obs=obs, var=var)

    mutation_records = json.loads((args.raw_dir / "data_mutations_api.json").read_text())
    mutation = pd.DataFrame(mutation_records)
    mutation = mutation.loc[mutation.sampleId.isin(data.obs_names)].copy()
    mutation["entrezGeneId"] = mutation["entrezGeneId"].astype(str)
    gene_ids = sorted(mutation.entrezGeneId.unique())
    gene_index = {value: index for index, value in enumerate(gene_ids)}
    cell_index = {value: index for index, value in enumerate(data.obs_names)}
    pairs = mutation[["sampleId", "entrezGeneId"]].drop_duplicates()
    rows = pairs.sampleId.map(cell_index).to_numpy()
    cols = pairs.entrezGeneId.map(gene_index).to_numpy()
    data.obsm["mutation_binary"] = sparse.csr_matrix(
        (np.ones(len(pairs), dtype=np.int8), (rows, cols)),
        shape=(data.n_obs, len(gene_ids)),
    )
    data.uns["mutation_binary_columns"] = gene_ids
    data.obs["mutation_count_records"] = mutation.groupby("sampleId").size().reindex(data.obs_names, fill_value=0).astype(int)

    blood = pd.read_csv(args.raw_dir / "data_blood_cell_percentages.txt", sep="\t", index_col=0, na_values=["NA", ""])
    blood_values = blood.drop(columns=[column for column in ["NAME", "DESCRIPTION"] if column in blood]).T
    blood_values = blood_values.apply(pd.to_numeric, errors="coerce").reindex(data.obs_names)
    for column in blood_values:
        data.obs[f"blood_{column.lower()}"] = blood_values[column].astype(float)

    structural = pd.read_csv(args.raw_dir / "data_sv.txt", sep="\t", dtype=str)
    data.obs["structural_variant_count"] = structural.groupby("Sample_Id").size().reindex(data.obs_names, fill_value=0).astype(int)
    data.uns["expression_status"] = "source_log2_normalized_RNA_seq_RPKM"
    data.uns["source_study"] = "aml_ohsu_2022"
    data.uns["mutation_source"] = "cBioPortal API fetch; 7757 study records before RNA-sample restriction"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    data.write_h5ad(args.output, compression="gzip")

    summary = pd.DataFrame({
        "metric": ["rna_samples", "patients", "genes", "mutation_records_in_rna", "samples_with_mutations", "samples_with_induction_response", "samples_with_os"],
        "value": [data.n_obs, data.obs.PATIENT_ID.nunique(), data.n_vars, len(mutation), mutation.sampleId.nunique(), data.obs.RESPONSE_TO_INDUCTION_TX.notna().sum(), data.obs.OS_MONTHS.notna().sum()],
    })
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(args.summary, sep="\t", index=False)
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
