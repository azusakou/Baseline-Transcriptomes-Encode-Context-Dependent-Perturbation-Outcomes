#!/usr/bin/env python3
"""Run scDblFinder and robust QC for every staged MIX-seq capture."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(command: list[str]) -> None:
    print("RUN", " ".join(command), flush=True)
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--staged-dir", type=Path, required=True)
    parser.add_argument("--processed-dir", type=Path, required=True)
    parser.add_argument("--report-dir", type=Path, required=True)
    parser.add_argument("--r-lib", type=Path, required=True)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    args.processed_dir.mkdir(parents=True, exist_ok=True)
    for source in sorted(p for p in args.staged_dir.glob("*.h5ad") if not p.name.startswith("._")):
        scdbl = args.processed_dir / f"{source.stem}.scdbl.h5ad"
        final = args.processed_dir / f"{source.stem}.qc.h5ad"
        report = args.report_dir / source.stem
        if args.force or not scdbl.exists():
            run([
                sys.executable, str(root / "run_h5ad_scdblfinder.py"),
                "--input", str(source), "--output", str(scdbl),
                "--r-lib", str(args.r_lib),
            ])
        if args.force or not final.exists():
            run([
                sys.executable, str(root / "qc_h5ad.py"),
                "--input", str(scdbl), "--output", str(final),
                "--report-dir", str(report),
            ])
        else:
            print(f"SKIP complete {final}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
