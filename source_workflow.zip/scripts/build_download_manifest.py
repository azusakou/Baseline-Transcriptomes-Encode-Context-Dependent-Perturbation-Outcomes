#!/usr/bin/env python3
"""Build the immutable core download manifest from public APIs and fixed URLs."""

from __future__ import annotations

import argparse
import csv
import json
import urllib.request
from pathlib import Path


FIELDS = ["dataset_id", "source", "url", "filename", "bytes", "md5", "priority"]


def figshare(article_id: int) -> dict:
    url = f"https://api.figshare.com/v2/articles/{article_id}"
    request = urllib.request.Request(url, headers={"User-Agent": "future-cell-fate/0.1"})
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.load(response)


def row(dataset: str, source: str, url: str, filename: str, size: int | str = "", md5: str = "", priority: str = "core") -> dict:
    return dict(zip(FIELDS, [dataset, source, url, filename, size, md5, priority]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows: list[dict] = []

    rows.append(row("sciplex3", "GEO", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE139nnn/GSE139944/suppl/GSE139944_RAW.tar", "GSE139944_RAW.tar", priority="core"))

    replogle = figshare(20029387)
    wanted = {
        "K562_essential_raw_singlecell_01.h5ad": "replogle_k562_essential",
        "rpe1_raw_singlecell_01.h5ad": "replogle_rpe1",
        "K562_gwps_raw_singlecell_01.h5ad": "replogle_k562_gwps",
    }
    for item in replogle["files"]:
        if item["name"] in wanted:
            priority = "external" if "gwps" in item["name"].lower() else "core"
            rows.append(row(wanted[item["name"]], "figshare", item["download_url"], item["name"], item["size"], item.get("computed_md5") or "", priority))

    mixseq = figshare(10298696)
    for item in mixseq["files"]:
        rows.append(row("mixseq", "figshare", item["download_url"], item["name"], item["size"], item.get("computed_md5") or "", "core"))

    base = "https://kleintools.hms.harvard.edu/paper_websites/state_fate2020/"
    for prefix, dataset in [("stateFate_inVitro", "larry_in_vitro"), ("stateFate_cytokinePerturbation", "larry_cytokine")]:
        for suffix in ["normed_counts.mtx.gz", "gene_names.txt.gz", "metadata.txt.gz", "clone_matrix.mtx.gz"]:
            name = f"{prefix}_{suffix}"
            rows.append(row(dataset, "KleinLab", base + name, name, priority="core"))

    rows.extend([
        row(
            "wot_reprogramming",
            "GoogleDrive",
            "https://drive.usercontent.google.com/download?id=1E494DhIx5RLy0qv_6eWa9426Bfmq28po&export=download&confirm=t",
            "wot_tutorial_input_data.zip",
            priority="core",
        ),
        row(
            "wot_reprogramming",
            "GoogleDrive",
            "https://drive.usercontent.google.com/download?id=1DiUObEYx5MafOfKcDDpuavvOKMyO4fmk&export=download&confirm=t",
            "wot_tutorial_transport_maps.zip",
            priority="core",
        ),
    ])

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} entries to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
