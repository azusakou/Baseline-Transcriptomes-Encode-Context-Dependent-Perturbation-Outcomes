#!/usr/bin/env python3
"""Prepare non-visual, traceable source-data tables for R manuscript figures."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures" / "source_data"


def read_tsv(path: Path | str) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t")


def write(data: pd.DataFrame, figure: str, name: str) -> None:
    destination = OUT / figure
    destination.mkdir(parents=True, exist_ok=True)
    data.to_csv(destination / f"{name}.tsv", sep="\t", index=False)


def first_number(value: object) -> float:
    match = re.search(r"[\d,]+", str(value))
    return float(match.group(0).replace(",", "")) if match else np.nan


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--external-root", type=Path, default=Path("/Volumes/wang/paper6yhn"))
    args = parser.parse_args()
    ext = args.external_root.resolve()
    inventory = read_tsv(ROOT / "reports/dataset_inventory.tsv")
    inventory["input_numeric"] = inventory.input_cells.map(first_number)
    inventory["qc_or_target_numeric"] = inventory.qc_cells_or_targets.map(first_number)
    inventory["retained_fraction"] = inventory.qc_or_target_numeric / inventory.input_numeric
    write(inventory, "figure1", "dataset_scale_and_evidence")
    validation = pd.DataFrame(
        [
            ("leave-cell-line", "MIX-seq", "cell line", "biological context transfer"),
            ("leave-perturbation", "MIX-seq; Replogle", "drug or target", "intervention transfer"),
            ("leave-task", "LARRY cytokine", "cytokine task", "task transfer"),
            ("leave-dataset", "LARRY; cross-platform", "dataset", "platform/system transfer"),
        ], columns=["validation", "source", "held_out_unit", "question"],
    )
    write(validation, "figure1", "ood_validation_contract")

    larry_branch = []
    larry_scalar = []
    for label, folder in [("in vitro", "larry_in_vitro_benchmark_clone_aggregated"), ("cytokine", "larry_cytokine_benchmark_clone_aggregated")]:
        branch = read_tsv(ext / "results" / folder / "clone_heldout_metrics.tsv")
        branch.insert(0, "experiment", label); larry_branch.append(branch)
        scalar = read_tsv(ext / "results" / folder / "scalar_fate_metrics.tsv")
        scalar.insert(0, "experiment", label); larry_scalar.append(scalar)
    write(pd.concat(larry_branch, ignore_index=True), "figure2", "larry_branch_fold_metrics")
    write(pd.concat(larry_scalar, ignore_index=True), "figure2", "larry_scalar_fold_metrics")
    clone_counts = pd.DataFrame(
        [("in vitro", 130887, 5864, 3321), ("cytokine", 65075, 5257, 2599)],
        columns=["experiment", "cells", "clones", "eligible_targets"],
    )
    write(clone_counts, "figure2", "larry_lineage_scale")

    key = read_tsv(ROOT / "reports/key_results.tsv")
    mix = key.loc[key.source.eq("MIX-seq")].copy()
    write(mix, "figure3", "mixseq_generalization_summary")
    sensitivity = read_tsv(ext / "results/mixseq_sensitivity/sensitivity_summary.tsv")
    write(sensitivity, "figure3", "mixseq_target_sensitivity")
    for label in ["k562", "rpe1"]:
        write(read_tsv(ROOT / f"reports/replogle_{label}_ablation.tsv"), "figure3", f"replogle_{label}_ablation")
        write(read_tsv(ROOT / f"results/replogle_{label}_future_fate/metrics.tsv") if label == "k562" else read_tsv(ROOT / "results/replogle_rpe1_generalization/metrics.tsv"), "extended_data4", f"replogle_{label}_fold_metrics")

    wot = read_tsv(ext / "results/wot_baseline_benchmark/replicate_heldout_metrics.tsv")
    write(wot, "figure4", "wot_replicate_metrics")
    cross = read_tsv(ext / "results/cross_task_dataset_generalization/generalization_metrics.tsv")
    write(cross, "figure4", "cross_task_dataset_metrics")
    stability = read_tsv(ROOT / "results/intrinsic_fate_axis_mapper_stability/intrinsic_fate_axis_stability.tsv")
    stable = stability.loc[stability.sign_consistency.eq(1)].copy()
    stable["abs_mean"] = stable.mean_coefficient.abs()
    top = stable.sort_values(["target", "abs_mean"], ascending=[True, False]).groupby("target", observed=True).head(8)
    write(top, "figure4", "top_stable_biological_axes")
    write(stability.groupby("target", observed=True).agg(total_axes=("feature", "size"), stable_axes=("sign_consistency", lambda x: int((x == 1).sum()))).reset_index(), "figure4", "axis_stability_counts")
    write(read_tsv(ext / "models/intrinsic_fate_axis_mapper_all/cell_line_heldout_metrics.tsv"), "figure4", "axis_mapper_fold_metrics")
    write(read_tsv(ROOT / "reports/velocity_eligibility.tsv"), "figure4", "velocity_eligibility")

    cells = pd.read_parquet(ROOT / "results/xenium_future_niches/xenium_cell_states_and_niches.parquet")
    spatial_map = cells.loc[cells["sample"].eq("GSM8831625"), [
        "cell_id", "sample", "patient", "x", "y", "cell_type", "spatial_niche",
        "intrinsic_apoptosis_pressure", "intrinsic_proliferation",
        "intrinsic_differentiation_proxy", "intrinsic_stress", "intrinsic_resistance_ecosystem",
    ]].copy()
    write(spatial_map, "figure5", "representative_spatial_cells")
    for name, source in [
        ("spatial_autocorrelation", ROOT / "results/xenium_future_niches/spatial_autocorrelation.tsv"),
        ("common_spatial_niches", ROOT / "results/xenium_future_niches/common_spatial_niches.tsv"),
        ("joint_model_metrics", ROOT / "results/xenium_future_niches/joint_model_metrics.tsv"),
        ("joint_model_predictions", ROOT / "results/xenium_future_niches/joint_model_lopo_predictions.tsv"),
        ("paired_future_targets", ROOT / "results/xenium_future_targets/patient_future_targets.tsv"),
        ("spatial_qc_sensitivity", ROOT / "reports/spatial_qc_sensitivity.tsv"),
        ("panel_module_coverage", ROOT / "results/xenium_future_niches/targeted_panel_module_coverage.tsv"),
        ("sample_qc", ROOT / "results/xenium_future_niches/sample_qc.tsv"),
    ]:
        write(read_tsv(source), "figure5", name)

    embeddings = []
    subtype = []
    clinical_cv = []
    for cohort in ["ispy2", "beataml"]:
        embedding = pd.read_parquet(ext / f"results/patient_fate_embedding/{cohort}/patient_fate_embedding.parquet")
        embedding.insert(0, "cohort", cohort.upper()); embeddings.append(embedding)
        summary = embedding.groupby("stable_subtype", observed=True).agg(
            patients=("patient", "size"), response_fraction=("outcome", "mean"),
            mean_cross_fitted_probability=("cross_fitted_response_probability", "mean"),
        ).reset_index(); summary.insert(0, "cohort", cohort.upper()); subtype.append(summary)
        cv = read_tsv(ext / f"results/patient_fate_embedding/{cohort}/cross_validation_metrics.tsv")
        cv.insert(0, "cohort", cohort.upper()); clinical_cv.append(cv)
    write(pd.concat(embeddings, ignore_index=True), "figure6", "patient_fate_embeddings")
    write(pd.concat(subtype, ignore_index=True), "figure6", "stable_subtype_response")
    write(pd.concat(clinical_cv, ignore_index=True), "figure6", "clinical_cross_validation")
    clinical_validation = []
    for cohort in ["ispy2", "beataml"]:
        frame = read_tsv(ext / f"results/patient_fate_embedding/{cohort}/clinical_validation.tsv")
        frame.insert(0, "cohort", cohort.upper()); clinical_validation.append(frame)
    write(pd.concat(clinical_validation, ignore_index=True), "figure6", "clinical_validation")

    status = pd.DataFrame(
        [
            ("MIX-seq", "leave-cell-line", "apoptosis", "positive"),
            ("MIX-seq", "leave-cell-line", "proliferation", "positive"),
            ("MIX-seq", "leave-cell-line", "stress", "positive"),
            ("MIX-seq", "leave-perturbation", "apoptosis", "positive"),
            ("MIX-seq", "leave-perturbation", "proliferation", "positive"),
            ("MIX-seq", "leave-perturbation", "stress", "negative"),
            ("MIX-seq", "leave-perturbation", "resistance", "negative"),
            ("LARRY", "leave-dataset", "differentiation", "positive"),
            ("LARRY", "leave-dataset", "rare fate", "negative"),
            ("LARRY", "leave-dataset", "entropy", "negative"),
            ("Replogle K562", "leave-perturbation", "apoptosis", "positive"),
            ("Replogle K562", "leave-GEM", "apoptosis/stress", "negative"),
            ("Replogle RPE1", "leave-perturbation", "stress", "positive"),
            ("Replogle RPE1", "leave-GEM", "all fates", "negative"),
            ("Xenium", "leave-patient", "joint response", "negative"),
        ], columns=["source", "validation", "fate", "result"],
    )
    write(status, "figure7", "transfer_success_failure_matrix")
    write(read_tsv(ROOT / "resource/Future_Cell_Fate_Resource_v0.2/manifest.tsv"), "figure7", "resource_manifest")
    write(inventory, "figure7", "evidence_ladder")

    write(inventory, "extended_data1", "dataset_qc_audit")
    write(sensitivity, "extended_data2", "mixseq_complete_sensitivity")
    write(cross, "extended_data3", "cross_task_dataset_metrics")
    for name in ["spatial_qc_sensitivity", "panel_module_coverage", "sample_qc"]:
        source = OUT / "figure5" / f"{name}.tsv"
        write(read_tsv(source), "extended_data5", name)
    write(pd.concat(clinical_cv, ignore_index=True), "extended_data6", "clinical_cross_validation")
    write(pd.concat(clinical_validation, ignore_index=True), "extended_data6", "clinical_validation")
    write(read_tsv(ROOT / "reports/velocity_eligibility.tsv"), "extended_data7", "velocity_eligibility")
    write(read_tsv(ROOT / "resource/Future_Cell_Fate_Resource_v0.2/manifest.tsv"), "extended_data7", "resource_manifest")
    print(f"wrote source-data directories under {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
