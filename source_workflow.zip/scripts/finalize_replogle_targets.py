#!/usr/bin/env python3
"""Attach scDblFinder calls and rebuild final Replogle fate targets."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


AXES = ["apoptosis", "proliferation", "stress"]


def mad(values: np.ndarray) -> float:
    center = np.median(values)
    return float(1.4826 * np.median(np.abs(values - center)))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--scdblfinder", type=Path, required=True)
    parser.add_argument("--cell-output", type=Path, required=True)
    parser.add_argument("--target-output", type=Path, required=True)
    parser.add_argument("--cell-line", default="K562")
    parser.add_argument("--min-cells", type=int, default=10)
    args = parser.parse_args()
    cells = pd.read_parquet(args.scores)
    calls = pd.read_parquet(args.scdblfinder).set_index("cell_id")
    cells = cells.drop(columns=[column for column in ["scDblFinder.score", "scDblFinder.class"] if column in cells])
    cells = cells.join(calls[["scDblFinder.score", "scDblFinder.class"]], on="cell_id", validate="one_to_one")
    cells["passes_qc_final"] = cells.passes_qc_auto & cells["scDblFinder.class"].eq("singlet")
    args.cell_output.parent.mkdir(parents=True, exist_ok=True); cells.to_parquet(args.cell_output, index=False)
    usable = cells.loc[cells.passes_qc_final]; controls = usable.loc[usable.gene.eq("non-targeting")]
    rows = []
    for (group, perturbation), treated in usable.loc[usable.gene.ne("non-targeting")].groupby(["gem_group", "gene"], observed=True):
        baseline = controls.loc[controls.gem_group.eq(group)]
        if len(treated) < args.min_cells or len(baseline) < args.min_cells:
            continue
        row = {"dataset_id": args.scores.stem, "gem_group": group, "cell_line": args.cell_line, "task": "genetic", "baseline": "non-targeting", "perturbation": perturbation, "baseline_cells": len(baseline), "treated_cells": len(treated)}
        for axis in AXES:
            values = baseline[f"score_{axis}"].dropna().to_numpy(float); threshold = np.median(values) + mad(values)
            success = int(treated[f"score_{axis}"].gt(threshold).sum()); trials = int(treated[f"score_{axis}"].notna().sum())
            probability = (success + 1) / (trials + 2)
            row[f"{axis}_threshold"] = threshold; row[f"p_{axis}"] = probability
            row[f"p_{axis}_se"] = np.sqrt(probability * (1 - probability) / (trials + 3))
        row["pair_id"] = f"{args.cell_line}|gem{group}|non-targeting->{perturbation}"
        rows.append(row)
    targets = pd.DataFrame(rows); args.target_output.parent.mkdir(parents=True, exist_ok=True)
    targets.to_csv(args.target_output, sep="\t", index=False)
    summary = pd.DataFrame({"metric": ["input_cells", "passes_auto_qc", "scdblfinder_singlets", "passes_final_qc", "eligible_pairs"], "value": [len(cells), int(cells.passes_qc_auto.sum()), int(cells["scDblFinder.class"].eq("singlet").sum()), int(cells.passes_qc_final.sum()), len(targets)]})
    summary.to_csv(args.target_output.with_suffix(".summary.tsv"), sep="\t", index=False)
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
