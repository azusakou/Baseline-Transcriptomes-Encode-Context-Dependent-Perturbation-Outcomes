#!/usr/bin/env python3
"""Direct expression-space leave-dataset transfer between two LARRY experiments."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler


def load(expression: Path, targets_path: Path, assignments_path: Path) -> tuple[ad.AnnData, pd.DataFrame, pd.DataFrame]:
    source = ad.read_h5ad(expression, backed="r")
    assignments = pd.read_csv(assignments_path, sep="\t")
    targets = pd.read_csv(targets_path, sep="\t").set_index("target_id")
    rows = assignments.join(targets[["transition_entropy", "p_differentiation", "p_rare_fate"]], on="target_id")
    cells = pd.Index(rows.cell_id.unique())
    positions = source.obs_names.get_indexer(cells)
    data = source[positions].to_memory(); source.file.close()
    position = pd.Series(np.arange(len(cells)), index=cells)
    rows["cell_position"] = rows.cell_id.map(position)
    units = rows.drop_duplicates("target_id")[["target_id", "transition_entropy", "p_differentiation", "p_rare_fate"]].reset_index(drop=True)
    return data, rows, units


def aggregate_latent(latent: np.ndarray, rows: pd.DataFrame, units: pd.DataFrame) -> np.ndarray:
    frame = pd.DataFrame(latent[rows.cell_position.to_numpy()])
    frame["target_id"] = rows.target_id.to_numpy()
    return frame.groupby("target_id", observed=True).mean().loc[units.target_id].to_numpy()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--in-vitro-expression", type=Path, required=True)
    parser.add_argument("--cytokine-expression", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    vitro, vitro_rows, vitro_units = load(args.in_vitro_expression, Path("tables/larry_in_vitro_clone_targets.tsv"), Path("tables/larry_in_vitro_baseline_assignments.tsv"))
    cyto, cyto_rows, cyto_units = load(args.cytokine_expression, Path("tables/larry_cytokine_clone_targets.tsv"), Path("tables/larry_cytokine_baseline_assignments.tsv"))
    if not vitro.var_names.equals(cyto.var_names):
        common = vitro.var_names.intersection(cyto.var_names); vitro = vitro[:, common]; cyto = cyto[:, common]
    datasets = [("larry_in_vitro", vitro, vitro_rows, vitro_units), ("larry_cytokine", cyto, cyto_rows, cyto_units)]
    metrics, predictions = [], []
    for train_name, train_data, train_rows, train_units in datasets:
        test_name, test_data, test_rows, test_units = next(item for item in datasets if item[0] != train_name)
        svd = TruncatedSVD(100, random_state=20260713).fit(train_data.X)
        train_z = aggregate_latent(svd.transform(train_data.X), train_rows, train_units)
        test_z = aggregate_latent(svd.transform(test_data.X), test_rows, test_units)
        scaler = StandardScaler().fit(train_z); train_z = scaler.transform(train_z); test_z = scaler.transform(test_z)
        for target in ["p_differentiation", "transition_entropy", "p_rare_fate"]:
            y_train = train_units[target].to_numpy(float); y_test = test_units[target].to_numpy(float)
            model = Ridge(alpha=100.0).fit(train_z, y_train); prediction = model.predict(test_z)
            baseline = np.repeat(y_train.mean(), len(y_test))
            if target.startswith("p_"): prediction = np.clip(prediction, 0, 1)
            for model_name, value in [("baseline_expression_svd_ridge", prediction), ("training_mean", baseline)]:
                metrics.extend([
                    {"validation": "leave_dataset", "trained_on": train_name, "held_out": test_name, "target": target, "model": model_name, "metric": "spearman", "value": spearmanr(y_test, value).statistic if np.std(value) else np.nan},
                    {"validation": "leave_dataset", "trained_on": train_name, "held_out": test_name, "target": target, "model": model_name, "metric": "mse", "value": np.mean((y_test - value) ** 2)},
                ])
            frame = test_units[["target_id"]].copy(); frame["trained_on"] = train_name; frame["target"] = target; frame["observed"] = y_test; frame["predicted"] = prediction; predictions.append(frame)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(metrics).to_csv(args.output_dir / "leave_dataset_metrics.tsv", sep="\t", index=False)
    pd.concat(predictions, ignore_index=True).to_parquet(args.output_dir / "leave_dataset_predictions.parquet", index=False)
    print(pd.DataFrame(metrics).groupby(["target", "model", "metric"]).value.mean().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
