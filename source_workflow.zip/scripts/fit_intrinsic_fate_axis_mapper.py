#!/usr/bin/env python3
"""Learn interpretable intrinsic fate axes from baseline pathway/regulon activity."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler


TARGETS = ["p_apoptosis", "p_proliferation", "p_stress", "external_resistance_quantile"]
KEYS = ["cell_line", "experiment", "time_hours"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--axes", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    axes = pd.read_parquet(args.axes)
    features = [column for column in axes if "__" in column]
    # Keep captures with an unannotated time as valid baseline contexts.
    baseline = axes.groupby(KEYS, observed=True, dropna=False)[features].mean().reset_index()
    # Rank alignment makes scores portable between single-cell pseudobulk and
    # bulk cohorts while retaining direction, not absolute ULM magnitude.
    baseline[features] = baseline[features].rank(pct=True)
    targets = pd.read_csv(args.targets, sep="\t")
    rows = targets.merge(baseline, on=KEYS, validate="many_to_one")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    all_weights, fold_weights, metrics, projected = [], [], [], rows[["pair_id", *KEYS, "perturbation"]].copy()
    for target in TARGETS:
        available = rows[target].notna()
        frame = rows.loc[available].copy()
        # Remove perturbation/time marginal response; what remains is the
        # intrinsic between-cell-line propensity to that fate.
        strata = ["perturbation", "time_hours"]
        centered = frame[target] - frame.groupby(
            strata, observed=True, dropna=False
        )[target].transform("mean")
        x = frame[features].to_numpy(float)
        groups = frame.cell_line.to_numpy()
        prediction = np.full(len(frame), np.nan)
        for fold, (train, test) in enumerate(GroupKFold(5).split(x, groups=groups), 1):
            scaler = StandardScaler().fit(x[train])
            model = Ridge(alpha=100.0).fit(scaler.transform(x[train]), centered.iloc[train])
            prediction[test] = model.predict(scaler.transform(x[test]))
            fold_weights.extend(
                {"target": target, "fold": fold, "feature": feature, "coefficient": coefficient}
                for feature, coefficient in zip(features, model.coef_, strict=True)
            )
            metrics.append({"target": target, "fold": fold, "metric": "spearman", "value": spearmanr(centered.iloc[test], prediction[test]).statistic})
            metrics.append({"target": target, "fold": fold, "metric": "mse", "value": np.mean((centered.iloc[test] - prediction[test]) ** 2)})
        projected.loc[available, f"intrinsic_{target}"] = prediction
        scaler = StandardScaler().fit(x)
        model = Ridge(alpha=100.0).fit(scaler.transform(x), centered)
        for feature, mean, scale, coefficient in zip(features, scaler.mean_, scaler.scale_, model.coef_, strict=True):
            all_weights.append({"target": target, "feature": feature, "rank_reference_mean": mean, "rank_reference_scale": scale, "coefficient": coefficient, "intercept": model.intercept_})
    pd.DataFrame(all_weights).to_csv(args.output_dir / "intrinsic_fate_axis_weights.tsv", sep="\t", index=False)
    fold_weight_table = pd.DataFrame(fold_weights)
    fold_weight_table.to_csv(args.output_dir / "intrinsic_fate_axis_fold_weights.tsv", sep="\t", index=False)
    stability = fold_weight_table.groupby(["target", "feature"], observed=True).coefficient.agg(
        mean_coefficient="mean", sd_coefficient="std",
        positive_fraction=lambda values: float((values > 0).mean()),
        negative_fraction=lambda values: float((values < 0).mean()),
    ).reset_index()
    stability["sign_consistency"] = stability[["positive_fraction", "negative_fraction"]].max(axis=1)
    mean_absolute = fold_weight_table.assign(
        absolute_coefficient=fold_weight_table.coefficient.abs()
    ).groupby(["target", "feature"], observed=True).absolute_coefficient.mean().rename(
        "mean_absolute_coefficient"
    ).reset_index()
    stability = stability.merge(mean_absolute, on=["target", "feature"], validate="one_to_one")
    stability["stable_direction"] = np.where(
        stability.positive_fraction.eq(1), "positive",
        np.where(stability.negative_fraction.eq(1), "negative", "unstable"),
    )
    stability.to_csv(args.output_dir / "intrinsic_fate_axis_stability.tsv", sep="\t", index=False)
    pd.DataFrame(metrics).to_csv(args.output_dir / "cell_line_heldout_metrics.tsv", sep="\t", index=False)
    projected.to_parquet(args.output_dir / "cross_fitted_intrinsic_fate_scores.parquet", index=False)
    print(pd.DataFrame(metrics).groupby(["target", "metric"]).value.mean().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
