#!/usr/bin/env python3
"""Run required scDblFinder on one H5AD without densifying its count matrix."""

from __future__ import annotations

import argparse
import gzip
import os
import subprocess
import tempfile
from pathlib import Path

import anndata as ad
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch-column", default="batch")
    parser.add_argument("--r-script", type=Path, default=Path(__file__).with_name("run_scdblfinder.R"))
    parser.add_argument("--r-lib", type=Path, required=True)
    args = parser.parse_args()

    adata = ad.read_h5ad(args.input)
    if args.batch_column not in adata.obs:
        adata.obs[args.batch_column] = args.input.stem
    counts = sparse.csr_matrix(adata.X)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="scdblfinder_", dir=args.output.parent) as temporary:
        tmp = Path(temporary)
        plain = tmp / "counts.mtx"
        compressed = tmp / "counts.mtx.gz"
        mmwrite(plain, counts.transpose().tocoo())
        with plain.open("rb") as source, gzip.open(compressed, "wb", compresslevel=1) as destination:
            while block := source.read(16 * 1024 * 1024):
                destination.write(block)
        cells = pd.DataFrame({"cell_id": adata.obs_names.astype(str), "batch": adata.obs[args.batch_column].astype(str).to_numpy()})
        cells_path = tmp / "cells.tsv"
        result_path = tmp / "scdblfinder.tsv"
        cells.to_csv(cells_path, sep="\t", index=False)
        env = os.environ.copy()
        env["R_LIBS_USER"] = str(args.r_lib)
        subprocess.run(["Rscript", str(args.r_script), str(compressed), str(cells_path), str(result_path)], check=True, env=env)
        result = pd.read_csv(result_path, sep="\t").set_index("cell_id")

    if not result.index.equals(adata.obs_names):
        result = result.reindex(adata.obs_names)
    adata.obs["scDblFinder_score"] = result["scDblFinder.score"].to_numpy()
    adata.obs["scDblFinder_class"] = result["scDblFinder.class"].astype("category").to_numpy()
    adata.uns["scDblFinder"] = {"version": "1.20.2", "seed": 20260713, "partition": args.batch_column}
    adata.write_h5ad(args.output, compression="gzip")
    print(f"wrote {args.output}; doublets={(adata.obs['scDblFinder_class'].astype(str) == 'doublet').sum()}/{adata.n_obs}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

