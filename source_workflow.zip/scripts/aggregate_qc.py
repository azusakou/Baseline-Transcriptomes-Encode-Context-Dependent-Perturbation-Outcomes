#!/usr/bin/env python3
"""Aggregate per-capture QC reports into a publication-ready audit table."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    for path in sorted(args.report_root.glob("*/qc_summary.tsv")):
        values = pd.read_csv(path, sep="\t").set_index("metric")["cells"]
        row = {"capture": path.parent.name, **{str(k): int(v) for k, v in values.items()}}
        row["auto_retention"] = row["passes_qc_auto"] / row["input_cells"]
        row["final_retention"] = row["passes_qc_final"] / row["input_cells"]
        rows.append(row)
    table = pd.DataFrame(rows)
    if table.empty:
        raise FileNotFoundError(f"no qc_summary.tsv below {args.report_root}")
    total = {
        "capture": "TOTAL",
        **{key: int(table[key].sum()) for key in ["input_cells", "passes_qc_auto", "passes_qc_final", "fails_qc_final"]},
    }
    total["auto_retention"] = total["passes_qc_auto"] / total["input_cells"]
    total["final_retention"] = total["passes_qc_final"] / total["input_cells"]
    table = pd.concat([table, pd.DataFrame([total])], ignore_index=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.output, sep="\t", index=False)
    print(table.tail(1).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
