#!/usr/bin/env python3
"""Discover GEO supplementary files without downloading their payloads."""

from __future__ import annotations

import argparse
import csv
import html.parser
import re
import sys
import urllib.request
from pathlib import Path


class LinkParser(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "a":
            return
        href = dict(attrs).get("href")
        if href and href not in {"../", "/"}:
            self.links.append(href)


def geo_suppl_url(accession: str) -> str:
    match = re.fullmatch(r"GSE(\d+)", accession.upper())
    if not match:
        raise ValueError(f"Not a GSE accession: {accession}")
    digits = match.group(1)
    family = f"GSE{digits[:-3]}nnn" if len(digits) > 3 else "GSEnnn"
    return f"https://ftp.ncbi.nlm.nih.gov/geo/series/{family}/{accession.upper()}/suppl/"


def content_length(url: str) -> int | None:
    request = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "future-cell-fate/0.1"})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            value = response.headers.get("Content-Length")
            return int(value) if value else None
    except Exception:
        return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("accessions", nargs="+")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    rows: list[dict[str, str | int]] = []
    for accession in args.accessions:
        base = geo_suppl_url(accession)
        request = urllib.request.Request(base, headers={"User-Agent": "future-cell-fate/0.1"})
        with urllib.request.urlopen(request, timeout=60) as response:
            page = response.read().decode("utf-8", errors="replace")
        links = LinkParser()
        links.feed(page)
        for name in sorted(set(links.links)):
            if name.endswith("/") or name.startswith("?") or "://" in name:
                continue
            url = base + name
            rows.append({
                "dataset_id": accession.lower(),
                "source": "GEO",
                "url": url,
                "filename": name,
                "bytes": content_length(url) or "",
                "md5": "",
                "priority": "core",
            })

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["dataset_id", "source", "url", "filename", "bytes", "md5", "priority"], delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} files to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
