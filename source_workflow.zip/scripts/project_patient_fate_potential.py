#!/usr/bin/env python3
"""Project learned intrinsic fate axes into a patient biological-axis table."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--axes", type=Path, required=True)
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = pd.read_parquet(args.axes)
    weights = pd.read_csv(args.weights, sep="\t")
    result = data[[column for column in data if "__" not in column]].copy()
    for target, group in weights.groupby("target", observed=True):
        common = group[group.feature.isin(data.columns)].copy()
        values = data[common.feature].rank(pct=True).to_numpy(float)
        standardized = (values - common.rank_reference_mean.to_numpy()) / common.rank_reference_scale.to_numpy()
        result[f"patient_fate_potential__{target}"] = standardized @ common.coefficient.to_numpy() + common.intercept.iloc[0]
        result[f"patient_fate_features_used__{target}"] = len(common)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_parquet(args.output, index=False)
    print(f"wrote {args.output}: {result.shape}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
