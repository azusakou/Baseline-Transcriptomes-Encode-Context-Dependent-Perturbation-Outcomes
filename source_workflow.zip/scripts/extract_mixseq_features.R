#!/usr/bin/env Rscript

# Export the source-author cell-line feature list, including independent
# PRISM/GDSC sensitivity, without altering values or imputing missingness.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) {
  stop("usage: extract_mixseq_features.R all_CL_features.rds output.tsv")
}
source_path <- args[[1]]
output_path <- args[[2]]
object <- readRDS(source_path)
if (!is.list(object) || is.null(names(object))) {
  stop("expected a named list of per-comparison data frames")
}
frames <- lapply(seq_along(object), function(index) {
  frame <- as.data.frame(object[[index]], stringsAsFactors = FALSE)
  frame$source_comparison <- names(object)[[index]]
  frame$source_row <- seq_len(nrow(frame))
  frame
})
all_columns <- unique(unlist(lapply(frames, names)))
frames <- lapply(frames, function(frame) {
  missing <- setdiff(all_columns, names(frame))
  for (column in missing) frame[[column]] <- NA
  frame[all_columns]
})
result <- do.call(rbind, frames)
dir.create(dirname(output_path), recursive = TRUE, showWarnings = FALSE)
write.table(result, output_path, sep = "\t", quote = FALSE, row.names = FALSE)
message(sprintf("wrote %d rows, %d comparisons", nrow(result), length(object)))
