#!/usr/bin/env python3
"""Build and cross-validate a supervised-contrastive Patient Fate Embedding."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import torch
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import squareform
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, balanced_accuracy_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from torch import nn


class Encoder(nn.Module):
    def __init__(self, n_features: int, n_embedding: int = 8):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(n_features, 64), nn.ReLU(), nn.Dropout(0.15), nn.Linear(64, n_embedding))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return nn.functional.normalize(self.network(x), dim=1)


def supcon(z: torch.Tensor, labels: torch.Tensor, temperature: float = 0.15) -> torch.Tensor:
    similarity = z @ z.T / temperature
    similarity = similarity - similarity.max(dim=1, keepdim=True).values.detach()
    eye = torch.eye(len(z), dtype=torch.bool, device=z.device)
    positive = labels[:, None].eq(labels[None, :]) & ~eye
    denominator = torch.exp(similarity).masked_fill(eye, 0).sum(dim=1).clamp_min(1e-12)
    log_probability = similarity - denominator.log()[:, None]
    return -(log_probability * positive).sum(dim=1).div(positive.sum(dim=1).clamp_min(1)).mean()


def fit_encoder(x: np.ndarray, y: np.ndarray, seed: int, epochs: int) -> Encoder:
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    model = Encoder(x.shape[1])
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-3)
    for _ in range(epochs):
        order = rng.permutation(len(x))
        for start in range(0, len(x), 128):
            index = order[start : start + 128]
            batch = torch.tensor(x[index], dtype=torch.float32)
            labels = torch.tensor(y[index], dtype=torch.long)
            views = torch.cat([batch + 0.05 * torch.randn_like(batch), batch + 0.05 * torch.randn_like(batch)])
            both_labels = torch.cat([labels, labels])
            loss = supcon(model(views), both_labels)
            optimizer.zero_grad(); loss.backward(); optimizer.step()
    model.eval()
    return model


def embedding(model: Encoder, x: np.ndarray) -> np.ndarray:
    with torch.no_grad():
        return model(torch.tensor(x, dtype=torch.float32)).numpy()


def prepare(args: argparse.Namespace) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    axes = pd.read_parquet(args.axes).set_index("cell_id")
    fate = pd.read_parquet(args.fate_potential).set_index("cell_id")
    data = axes.join(fate[[column for column in fate if column.startswith("patient_fate_potential__")]])
    weights = pd.read_csv(args.weights, sep="\t")
    selected = weights.assign(abs_weight=lambda d: d.coefficient.abs()).sort_values("abs_weight", ascending=False).groupby("target").head(args.top_per_fate).feature.unique().tolist()
    selected = [column for column in selected if column in data]
    selected += [column for column in data if column.startswith("patient_fate_potential__")]
    source = ad.read_h5ad(args.metadata_h5ad, backed="r")
    metadata = source.obs.copy(); source.file.close()
    data = data.join(metadata, how="inner", rsuffix="_metadata")
    if args.cohort == "ispy2":
        data["outcome"] = pd.to_numeric(data["pcr"], errors="coerce")
        data["patient"] = data["patient_id"].astype(str)
    else:
        day = pd.to_numeric(data["TIME_OF_SAMPLE_COLLECTION_RELATIVE_TO_INCLUSION"], errors="coerce")
        data = data.loc[day.eq(0)].copy()
        response = data["RESPONSE_TO_INDUCTION_TX"].astype(str)
        data["outcome"] = np.where(response.str.startswith("Complete Response"), 1, np.where(response.eq("Refractory"), 0, np.nan))
        data["patient"] = data["PATIENT_ID"].astype(str)
    data = data.loc[data.outcome.notna()].copy()
    data = data.sort_index().drop_duplicates("patient", keep="first")
    x = data[selected].rank(pct=True).fillna(0.5).to_numpy(float)
    return data, x, selected


def consensus_subtypes(z: np.ndarray, seed: int, repeats: int = 100) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed); n = len(z)
    together = np.zeros((n, n)); observed = np.zeros((n, n))
    for repeat in range(repeats):
        index = rng.choice(n, size=max(20, int(0.8 * n)), replace=False)
        labels = KMeans(2, n_init=20, random_state=seed + repeat).fit_predict(z[index])
        observed[np.ix_(index, index)] += 1
        together[np.ix_(index, index)] += labels[:, None] == labels[None, :]
    consensus = np.divide(together, observed, out=np.full_like(together, 0.5), where=observed > 0)
    np.fill_diagonal(consensus, 1)
    labels = fcluster(linkage(squareform(1 - consensus, checks=False), method="average"), 2, criterion="maxclust") - 1
    return labels, consensus


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", choices=["ispy2", "beataml"], required=True)
    parser.add_argument("--axes", type=Path, required=True)
    parser.add_argument("--fate-potential", type=Path, required=True)
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--metadata-h5ad", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--top-per-fate", type=int, default=20)
    parser.add_argument("--epochs", type=int, default=80)
    args = parser.parse_args()
    data, x, features = prepare(args); y = data.outcome.astype(int).to_numpy(); groups = data.patient.to_numpy()
    prediction = np.full(len(data), np.nan); metrics = []
    splitter = StratifiedGroupKFold(5, shuffle=True, random_state=20260713)
    for fold, (train, test) in enumerate(splitter.split(x, y, groups), 1):
        scaler = StandardScaler().fit(x[train]); train_x, test_x = scaler.transform(x[train]), scaler.transform(x[test])
        model = fit_encoder(train_x, y[train], 20260713 + fold, args.epochs)
        train_z, test_z = embedding(model, train_x), embedding(model, test_x)
        classifier = LogisticRegression(C=0.2, max_iter=2000).fit(train_z, y[train])
        probability = classifier.predict_proba(test_z)[:, 1]; prediction[test] = probability
        metrics.extend([
            {"fold": fold, "metric": "auroc", "value": roc_auc_score(y[test], probability)},
            {"fold": fold, "metric": "average_precision", "value": average_precision_score(y[test], probability)},
            {"fold": fold, "metric": "balanced_accuracy", "value": balanced_accuracy_score(y[test], probability >= 0.5)},
        ])
    scaler = StandardScaler().fit(x); final_model = fit_encoder(scaler.transform(x), y, 20260813, args.epochs)
    z = embedding(final_model, scaler.transform(x))
    # Stable subtype discovery is deliberately unsupervised in the aligned
    # fate-feature space. Patient outcomes are not used to form clusters;
    # supervised PFE coordinates are retained separately for prediction.
    subtype, consensus = consensus_subtypes(scaler.transform(x), 20260713)
    output = data[["patient", "outcome"]].copy(); output.index.name = "cell_id"
    output["cross_fitted_response_probability"] = prediction; output["stable_subtype"] = subtype
    for index in range(z.shape[1]): output[f"PFE_{index + 1}"] = z[:, index]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output.reset_index().to_parquet(args.output_dir / "patient_fate_embedding.parquet", index=False)
    pd.DataFrame(metrics).to_csv(args.output_dir / "cross_validation_metrics.tsv", sep="\t", index=False)
    pd.DataFrame(consensus, index=output.patient, columns=output.patient).to_parquet(args.output_dir / "subtype_consensus.parquet")
    pd.Series(features, name="feature").to_csv(args.output_dir / "embedding_features.tsv", sep="\t", index=False)
    print(f"patients={len(data)}, positives={y.sum()}, features={len(features)}")
    print(pd.DataFrame(metrics).groupby("metric").value.mean().to_string())
    print(pd.crosstab(output.stable_subtype, output.outcome, normalize="index").to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
