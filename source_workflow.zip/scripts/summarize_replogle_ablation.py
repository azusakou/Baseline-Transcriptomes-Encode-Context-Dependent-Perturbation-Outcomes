#!/usr/bin/env python3
"""Summarize paired Replogle baseline-state increments over perturbation descriptors."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metrics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = pd.read_csv(args.metrics, sep="\t")
    wide = data.pivot_table(index=["validation", "fold", "target", "metric"], columns="model", values="value").reset_index()
    rows = []
    for keys, frame in wide.groupby(["validation", "target", "metric"], observed=True):
        if keys[2] in {"brier", "mae", "mse"}:
            delta = frame.perturbation_descriptor - frame.baseline_plus_perturbation
        else:
            delta = frame.baseline_plus_perturbation - frame.perturbation_descriptor
        n = len(delta); mean = delta.mean()
        half = t.ppf(0.975, n - 1) * delta.std(ddof=1) / np.sqrt(n) if n > 1 else np.nan
        rows.append({
            "validation": keys[0], "target": keys[1], "metric": keys[2],
            "baseline_state_increment": mean,
            "ci_low": mean - half, "ci_high": mean + half,
            "folds_joint_better": int(delta.gt(0).sum()), "folds_total": n,
            "interpretation": "positive values favor baseline_plus_perturbation",
        })
    result = pd.DataFrame(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, sep="\t", index=False)
    print(result.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
