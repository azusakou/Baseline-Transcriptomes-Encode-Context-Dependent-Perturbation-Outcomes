#!/usr/bin/env python3
"""Audit a large H5AD in backed mode and write compact metadata summaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    adata = ad.read_h5ad(args.input, backed="r")
    summary = {
        "input": str(args.input),
        "cells": adata.n_obs,
        "genes": adata.n_vars,
        "obs_columns": list(adata.obs.columns),
        "var_columns": list(adata.var.columns),
        "layers": list(adata.layers.keys()),
        "obsm": list(adata.obsm.keys()),
        "uns": list(adata.uns.keys()),
    }
    obs = adata.obs.copy()
    adata.file.close()
    (args.output_dir / "h5ad_audit.json").write_text(json.dumps(summary, indent=2))
    cardinality = pd.DataFrame({"column": obs.columns, "n_unique": [obs[c].nunique(dropna=False) for c in obs.columns]})
    cardinality.to_csv(args.output_dir / "obs_cardinality.tsv", sep="\t", index=False)
    for column in obs.columns:
        if obs[column].nunique(dropna=False) <= 500:
            obs[column].value_counts(dropna=False).rename_axis(column).reset_index(name="cells").to_csv(args.output_dir / f"counts__{column}.tsv", sep="\t", index=False)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
