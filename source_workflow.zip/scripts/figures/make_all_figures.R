#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
project <- normalizePath(getwd())
.libPaths(c(file.path(project, "r_libs"), .libPaths()))

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(tidyr)
  library(scales)
  library(ggrepel)
  library(svglite)
  library(ragg)
  library(grid)
})

src <- file.path(project, "figures", "source_data")
main_dir <- file.path(project, "figures", "main")
ext_dir <- file.path(project, "figures", "extended")
dir.create(main_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(ext_dir, recursive = TRUE, showWarnings = FALSE)

pal <- c(
  ink = "#272727", grey = "#767676", light = "#D8D8D8", pale = "#F3F4F6",
  blue = "#2F6DA4", blue2 = "#83A9CE", teal = "#319A91", teal2 = "#A8D8D1",
  red = "#C94E48", red2 = "#E9AAA6", orange = "#D98B35", violet = "#8064A2",
  green = "#4C956C", gold = "#D6A33A"
)

theme_nc <- function(base_size = 6.5) {
  theme_classic(base_size = base_size, base_family = "Helvetica") +
    theme(
      axis.line = element_line(linewidth = 0.32, colour = pal[["ink"]]),
      axis.ticks = element_line(linewidth = 0.30, colour = pal[["ink"]]),
      axis.text = element_text(colour = pal[["ink"]], size = base_size - 0.4),
      axis.title = element_text(colour = pal[["ink"]], size = base_size),
      legend.title = element_text(size = base_size - 0.2, face = "bold"),
      legend.text = element_text(size = base_size - 0.6),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = pal[["ink"]]),
      plot.title = element_text(size = base_size + 0.8, face = "bold", hjust = 0),
      plot.subtitle = element_text(size = base_size - 0.2, colour = pal[["grey"]]),
      plot.tag = element_text(size = 8, face = "bold", colour = pal[["ink"]]),
      panel.grid = element_blank(),
      legend.key.height = unit(3.5, "mm"),
      plot.margin = margin(3, 4, 3, 3)
    )
}
theme_set(theme_nc())

read_src <- function(fig, name) read.delim(file.path(src, fig, paste0(name, ".tsv")), check.names = FALSE)
clean_fate <- function(x) {
  x <- sub("^p_", "", x)
  x <- sub("^external_", "", x)
  gsub("_", " ", x)
}
clean_model <- function(x) {
  recode(x,
    baseline_latent_ridge = "baseline latent",
    baseline_scvi_ridge = "baseline latent",
    baseline_plus_perturbation = "baseline + perturbation",
    perturbation_descriptor = "perturbation descriptor",
    biological_program_ridge = "biological programs",
    biological_axis_ridge = "biological axes",
    training_patient_mean = "training mean",
    training_mean = "training mean",
    .default = gsub("_", " ", x)
  )
}
reorder_within <- function(x, by, within, fun = mean, sep = "___", ...) {
  stats::reorder(paste(x, within, sep = sep), by, FUN = fun)
}
scale_y_reordered <- function(...) {
  scale_y_discrete(labels = function(x) gsub("___.*$", "", x), ...)
}

save_pub <- function(plot, filename, width_mm = 183, height_mm = 145, dpi = 600) {
  w <- width_mm / 25.4; h <- height_mm / 25.4
  svglite::svglite(paste0(filename, ".svg"), width = w, height = h, bg = "white", system_fonts = list(sans = "Helvetica"))
  print(plot); dev.off()
  grDevices::pdf(paste0(filename, ".pdf"), width = w, height = h, family = "Helvetica", bg = "white", useDingbats = FALSE)
  print(plot); dev.off()
  ragg::agg_tiff(paste0(filename, ".tiff"), width = w, height = h, units = "in", res = dpi, compression = "lzw", background = "white", scaling = 1)
  print(plot); dev.off()
  ragg::agg_png(paste0(filename, ".png"), width = w, height = h, units = "in", res = 300, background = "white", scaling = 1)
  print(plot); dev.off()
}

mean_ci <- function(data, groups, value = "value") {
  data %>% group_by(across(all_of(groups))) %>% summarise(
    mean = mean(.data[[value]], na.rm = TRUE),
    se = sd(.data[[value]], na.rm = TRUE) / sqrt(sum(is.finite(.data[[value]]))),
    n = sum(is.finite(.data[[value]])), .groups = "drop"
  ) %>% mutate(ci = mapply(function(nn, ss) if (nn > 1) qt(0.975, nn - 1) * ss else NA_real_, n, se))
}

tile_text_plot <- function(data, x, y, fill, label = NULL, low = pal[["red2"]], mid = "white", high = pal[["blue"]]) {
  p <- ggplot(data, aes(x = .data[[x]], y = .data[[y]], fill = .data[[fill]])) +
    geom_tile(colour = "white", linewidth = 0.45) +
    scale_fill_gradient2(low = low, mid = mid, high = high, midpoint = 0, na.value = pal[["light"]])
  if (!is.null(label)) p <- p + geom_text(aes(label = .data[[label]]), size = 1.65)
  p + theme(axis.text.x = element_text(angle = 35, hjust = 1), axis.title = element_blank())
}

# Figure 1 -------------------------------------------------------------------
inv <- read_src("figure1", "dataset_scale_and_evidence")
ood <- read_src("figure1", "ood_validation_contract")

nodes <- data.frame(
  x = c(0.7, 2.35, 4.05, 5.75), y = 1,
  label = c("Baseline cells\nstate distribution", "Baseline-only\nlatent state z0", "Probability heads\nP(fate | z0,p,t)", "Future outcomes\nbranch / program / patient"),
  type = c("baseline", "model", "model", "future")
)
p1a <- ggplot(nodes, aes(x, y)) +
  geom_rect(aes(xmin = x - .62, xmax = x + .62, ymin = y - .34, ymax = y + .34, fill = type), colour = pal[["ink"]], linewidth = .35) +
  geom_text(aes(label = label), size = 2.05, lineheight = .92) +
  geom_segment(data = data.frame(x = c(1.34, 2.99, 4.69), xend = c(1.72, 3.41, 5.07), y = 1, yend = 1),
               aes(x = x, xend = xend, y = y, yend = yend), inherit.aes = FALSE,
               arrow = arrow(length = unit(1.8, "mm")), linewidth = .45, colour = pal[["grey"]]) +
  annotate("rect", xmin = 3.28, xmax = 4.80, ymin = .35, ymax = .48, fill = pal[["red2"]], colour = NA) +
  annotate("text", x = 4.04, y = .20, label = "treated expression excluded from predictors", colour = pal[["red"]], size = 1.8) +
  scale_fill_manual(values = c(baseline = pal[["teal2"]], model = pal[["blue2"]], future = pal[["red2"]])) +
  coord_cartesian(xlim = c(0, 6.5), ylim = c(0, 1.6), clip = "off") + theme_void(base_family = "Helvetica") + theme(legend.position = "none")

inv_plot <- inv %>% filter(is.finite(input_numeric), !grepl("post-treatment", dataset)) %>%
  mutate(dataset = factor(dataset, levels = rev(dataset)), evidence_tier = gsub(" probability", "", evidence_tier))
p1b <- ggplot(inv_plot, aes(input_numeric, dataset, colour = evidence_tier)) +
  geom_segment(aes(x = pmax(qc_or_target_numeric, 1), xend = input_numeric, yend = dataset), colour = pal[["light"]], linewidth = 1.2) +
  geom_point(aes(x = pmax(qc_or_target_numeric, 1)), shape = 21, fill = "white", size = 2.1, stroke = .65) +
  geom_point(size = 1.9) + scale_x_log10(labels = label_number(scale_cut = cut_si(""))) +
  scale_colour_manual(values = c("gold lineage supervision" = pal[["teal"]], "silver transport supervision" = pal[["violet"]],
                                  "derived program" = pal[["blue"]], "genetic derived program" = pal[["blue2"]],
                                  "spatial exploratory" = pal[["orange"]], "clinical projection" = pal[["red"]])) +
  labs(x = "Input and analysed units (log scale)", y = NULL, colour = "Evidence tier") + theme(legend.position = "bottom")

ood <- ood %>% mutate(validation = factor(validation, levels = c("leave-cell-line", "leave-perturbation", "leave-task", "leave-dataset")))
p1c <- ggplot(ood, aes(x = validation, y = 1, fill = validation)) +
  geom_tile(width = .88, height = .52, colour = "white", linewidth = .5) +
  geom_text(aes(label = held_out_unit), size = 1.8, lineheight = .9) +
  scale_fill_manual(values = c(pal[["blue2"]], pal[["teal2"]], "#DDD2EA", pal[["red2"]])) +
  scale_y_continuous(NULL, breaks = NULL) + labs(x = NULL) +
  theme(axis.line = element_blank(), axis.ticks = element_blank(), axis.text.x = element_text(face = "bold", angle = 22, hjust = 1, size = 5.2), legend.position = "none")

tier_counts <- inv_plot %>% count(evidence_tier)
p1d <- ggplot(tier_counts, aes(n, reorder(evidence_tier, n), fill = evidence_tier)) +
  geom_col(width = .62) + geom_text(aes(label = n), hjust = -0.4, size = 2) +
  scale_fill_manual(values = c("gold lineage supervision" = pal[["teal"]], "silver transport supervision" = pal[["violet"]],
                               "derived program" = pal[["blue"]], "genetic derived program" = pal[["blue2"]],
                               "spatial exploratory" = pal[["orange"]], "clinical projection" = pal[["red"]])) +
  scale_x_continuous(expand = expansion(mult = c(0, .18)), breaks = 0:4) + labs(x = "Data sources", y = NULL) + theme(legend.position = "none")

fig1 <- p1a + p1b + p1c + p1d + plot_layout(design = "AAAA\nBBCC\nBBDD", heights = c(1.0, .82, .82)) +
  plot_annotation(tag_levels = "a")
save_pub(fig1, file.path(main_dir, "Figure1_study_design"), 183, 148)

# Figure 2 -------------------------------------------------------------------
branch <- read_src("figure2", "larry_branch_fold_metrics") %>% mutate(model = clean_model(model))
scalar <- read_src("figure2", "larry_scalar_fold_metrics") %>% mutate(model = clean_model(model), target = clean_fate(target))
lineage_scale <- read_src("figure2", "larry_lineage_scale")

p2a <- ggplot() +
  annotate("rect", xmin = c(.2, 1.65, 3.1), xmax = c(1.15, 2.6, 4.4), ymin = .65, ymax = 1.35,
           fill = c(pal[["teal2"]], pal[["blue2"]], pal[["red2"]]), colour = pal[["ink"]], linewidth = .35) +
  annotate("text", x = c(.675, 2.125, 3.75), y = 1, label = c("Baseline clone\nexpression", "Clone-held-out\npredictor", "Descendant branch\nprobabilities"), size = 2) +
  annotate("segment", x = c(1.18, 2.63), xend = c(1.58, 3.03), y = 1, yend = 1, arrow = arrow(length = unit(1.5, "mm")), colour = pal[["grey"]]) +
  annotate("text", x = 2.3, y = .35, label = "clones, not cells, define outer folds", colour = pal[["red"]], size = 1.8) +
  coord_cartesian(xlim = c(0, 4.6), ylim = c(.15, 1.55)) + theme_void()

branch_macro <- branch %>% filter(branch == "macro", metric %in% c("brier", "top_branch_accuracy"))
branch_sum <- mean_ci(branch_macro, c("experiment", "model", "metric"))
p2b <- ggplot(branch_sum %>% filter(metric == "brier"), aes(model, mean, fill = model)) +
  geom_col(width = .62) + geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = .15, linewidth = .35) +
  geom_point(data = branch_macro %>% filter(metric == "brier"), aes(y = value), position = position_jitter(width = .08), size = .65, inherit.aes = TRUE) +
  facet_wrap(~experiment) + scale_fill_manual(values = c("baseline latent" = pal[["blue"]], "training mean" = pal[["light"]])) +
  labs(x = NULL, y = "Macro Brier score") + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(), legend.position = "bottom")
p2c <- ggplot(branch_sum %>% filter(metric == "top_branch_accuracy"), aes(model, mean, fill = model)) +
  geom_col(width = .62) + geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = .15, linewidth = .35) +
  geom_point(data = branch_macro %>% filter(metric == "top_branch_accuracy"), aes(y = value), position = position_jitter(width = .08), size = .65) +
  facet_wrap(~experiment) + scale_fill_manual(values = c("baseline latent" = pal[["blue"]], "training mean" = pal[["light"]])) +
  labs(x = NULL, y = "Top-branch accuracy") + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(), legend.position = "none")

scalar_corr <- scalar %>% filter(metric == "spearman", model == "baseline latent")
p2d <- ggplot(scalar_corr, aes(value, target, colour = experiment)) +
  geom_vline(xintercept = 0, linetype = 2, colour = pal[["grey"]], linewidth = .3) +
  geom_point(alpha = .55, size = .75, position = position_jitter(height = .09)) +
  stat_summary(fun = mean, geom = "point", size = 2.0, shape = 18, position = position_dodge(width = .25)) +
  scale_colour_manual(values = c("in vitro" = pal[["blue"]], cytokine = pal[["teal"]])) +
  labs(x = "Held-clone Spearman correlation", y = NULL, colour = NULL) + theme(legend.position = "bottom")

scalar_mae <- scalar %>% filter(metric == "mae") %>% select(experiment, fold, target, model, value) %>%
  pivot_wider(names_from = model, values_from = value) %>% mutate(improvement = `training mean` - `baseline latent`)
p2e <- ggplot(scalar_mae, aes(improvement, target, colour = experiment)) +
  geom_vline(xintercept = 0, linetype = 2, colour = pal[["grey"]], linewidth = .3) +
  geom_point(alpha = .55, size = .75, position = position_jitter(height = .09)) +
  stat_summary(fun = mean, geom = "point", size = 2.0, shape = 18, position = position_dodge(width = .25)) +
  scale_colour_manual(values = c("in vitro" = pal[["blue"]], cytokine = pal[["teal"]])) +
  labs(x = "MAE improvement over training mean", y = NULL) + guides(colour = "none") + theme(legend.position = "none")

fig2 <- (p2a | p2b) / (p2c | p2d) / p2e + plot_layout(heights = c(.82, 1, 1)) +
  plot_annotation(tag_levels = "a")
save_pub(fig2, file.path(main_dir, "Figure2_lineage_prediction"), 183, 150)

# Figure 3 -------------------------------------------------------------------
mix <- read_src("figure3", "mixseq_generalization_summary") %>% mutate(
  fate = clean_fate(target), validation = gsub("_", "-", validation), model_label = clean_model(model)
)
mix_heat <- mix %>% filter(model == "baseline_scvi_ridge", metric %in% c("brier", "spearman")) %>%
  mutate(display = ifelse(metric == "brier", improvement_over_training_mean, estimate),
         metric_label = ifelse(metric == "brier", "Brier improvement", "Spearman"), label = sprintf("%.3f", display))
p3a <- ggplot(mix_heat, aes(fate, interaction(validation, metric_label, sep = " | "), fill = display)) +
  geom_tile(colour = "white", linewidth = .5) + geom_text(aes(label = label), size = 1.65) +
  scale_fill_gradient2(low = pal[["red"]], mid = "white", high = pal[["blue"]], midpoint = 0) +
  labs(x = NULL, y = NULL, fill = "Performance") + theme(axis.text.x = element_text(angle = 35, hjust = 1), legend.position = "none")

sens <- read_src("figure3", "mixseq_target_sensitivity") %>% filter(metric == "brier") %>%
  select(variant, validation, target, model, mean_value) %>% pivot_wider(names_from = model, values_from = mean_value) %>%
  mutate(improvement = training_mean - baseline_scvi_ridge, fate = clean_fate(target), validation = gsub("_", "-", validation))
sens_summary <- sens %>% group_by(validation, fate) %>% summarise(wins = sum(improvement > 0), settings = n(), .groups = "drop") %>%
  mutate(label = paste0(wins, "/", settings), fraction = wins / settings)
p3b <- ggplot(sens_summary, aes(fate, validation, fill = fraction)) + geom_tile(colour = "white", linewidth = .5) +
  geom_text(aes(label = label), size = 1.8) + scale_fill_gradient(low = "white", high = pal[["blue"]], limits = c(0,1)) +
  labs(x = NULL, y = NULL, fill = "Brier wins\nacross settings") + theme(axis.text.x = element_text(angle = 35, hjust = 1), legend.position = "none")

ablation_plot <- function(label, colour) {
  d <- read_src("figure3", paste0("replogle_", label, "_ablation")) %>%
    filter(metric %in% c("brier", "spearman")) %>% mutate(fate = clean_fate(target), validation = gsub("_", "-", validation), metric = tools::toTitleCase(metric))
  ggplot(d, aes(baseline_state_increment, fate, colour = validation)) +
    geom_vline(xintercept = 0, linetype = 2, colour = pal[["grey"]], linewidth = .3) +
    geom_errorbar(aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = .18, linewidth = .4) + geom_point(size = 1.4) +
    facet_wrap(~metric, scales = "free_x") + scale_colour_manual(values = c("leave-perturbation" = colour, "leave-gem-group" = pal[["red"]])) +
    labs(x = "Baseline-state increment", y = NULL, colour = NULL, title = toupper(label)) + theme(legend.position = "bottom")
}
p3c <- ablation_plot("k562", pal[["blue"]])
p3d <- ablation_plot("rpe1", pal[["teal"]])
p3d <- p3d + guides(colour = "none")

held <- bind_rows(
  read_src("figure3", "replogle_k562_ablation") %>% mutate(cell_line = "K562"),
  read_src("figure3", "replogle_rpe1_ablation") %>% mutate(cell_line = "RPE1")
) %>% filter(validation == "leave_gem_group", metric == "spearman") %>% mutate(fate = clean_fate(target))
p3e <- ggplot(held, aes(fate, baseline_state_increment, fill = cell_line)) + geom_hline(yintercept = 0, linetype = 2, colour = pal[["grey"]]) +
  geom_col(position = position_dodge(width = .72), width = .62) +
  scale_fill_manual(values = c(K562 = pal[["blue2"]], RPE1 = pal[["teal2"]])) +
  labs(x = NULL, y = "Held-GEM correlation increment", fill = NULL) + theme(legend.position = "bottom")

fig3 <- (p3a | p3b) / (p3c | p3d) / p3e + plot_layout(heights = c(.9, 1.05, .82)) +
  plot_annotation(tag_levels = "a")
save_pub(fig3, file.path(main_dir, "Figure3_generalization"), 183, 155)

# Figure 4 -------------------------------------------------------------------
wot <- read_src("figure4", "wot_replicate_metrics") %>% mutate(model_label = clean_model(model))
wot_macro <- wot %>% filter(branch == "macro", metric == "brier")
p4a <- ggplot(wot_macro, aes(reorder(model_label, value, FUN = mean), value, colour = model_label)) +
  geom_point(position = position_jitter(width = .06), size = 1.1, alpha = .7) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 2.3) +
  scale_y_log10(labels = label_scientific()) +
  scale_colour_manual(values = c("baseline latent" = pal[["blue"]], "biological programs" = pal[["teal"]], "training mean" = pal[["grey"]])) +
  labs(x = NULL, y = "WOT macro Brier (log scale)") + theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "none")

cross <- read_src("figure4", "cross_task_dataset_metrics") %>% filter(metric == "spearman", model != "training_mean") %>%
  group_by(validation, target, model) %>% summarise(value = mean(value, na.rm = TRUE), .groups = "drop") %>%
  mutate(target = clean_fate(target), validation = gsub("_", " ", validation), label = ifelse(is.finite(value), sprintf("%.2f", value), "NA"))
p4b <- ggplot(cross, aes(target, validation, fill = value)) + geom_tile(colour = "white", linewidth = .45) + geom_text(aes(label = label), size = 1.45) +
  scale_fill_gradient2(low = pal[["red"]], mid = "white", high = pal[["blue"]], midpoint = 0, na.value = pal[["light"]]) +
  labs(x = NULL, y = NULL, fill = "Spearman") + theme(axis.text.x = element_text(angle = 35, hjust = 1), axis.text.y = element_text(size = 5.2))

axes <- read_src("figure4", "top_stable_biological_axes") %>% filter(target %in% c("p_apoptosis", "p_proliferation", "p_stress")) %>%
  group_by(target) %>% slice_max(abs(mean_coefficient), n = 5, with_ties = FALSE) %>% ungroup() %>%
  mutate(feature = sub("^[^_]+__", "", feature), target = clean_fate(target), feature_order = reorder_within(feature, mean_coefficient, target))
p4c <- ggplot(axes, aes(mean_coefficient, feature_order, fill = mean_coefficient > 0)) + geom_col(width = .66) +
  facet_wrap(~target, scales = "free_y") + scale_y_reordered() + scale_fill_manual(values = c(`TRUE` = pal[["blue"]], `FALSE` = pal[["red"]])) +
  scale_x_continuous(breaks = function(x) pretty(x, n = 3), labels = label_number(accuracy = .005)) +
  labs(x = "Mean standardized conditional coefficient", y = NULL) + theme(legend.position = "none", axis.text.y = element_text(size = 5.2), axis.text.x = element_text(size = 4.8), strip.text = element_text(size = 5.5))

stab <- read_src("figure4", "axis_stability_counts") %>% mutate(fate = clean_fate(target), fraction = stable_axes / total_axes)
p4d <- ggplot(stab, aes(fraction, reorder(fate, fraction), fill = fate)) + geom_col(width = .62) +
  geom_text(aes(label = paste0(stable_axes, "/", total_axes)), hjust = -0.08, size = 1.75) +
  scale_x_continuous(labels = percent, limits = c(0, .62)) + scale_fill_manual(values = c(pal[["blue"]], pal[["teal"]], pal[["violet"]], pal[["orange"]])) +
  labs(x = "Sign-stable axes across five folds", y = NULL) + theme(legend.position = "none")

vel <- read_src("figure4", "velocity_eligibility") %>% mutate(dataset = sub("\\.h5ad$", "", file), eligible = ifelse(rna_velocity_eligible == "True", "eligible", "ineligible"))
p4e <- ggplot(vel, aes(1, reorder(dataset, cells), fill = eligible)) + geom_tile(colour = "white", width = .65) +
  geom_text(aes(label = paste0(format(cells, big.mark = ","), " cells\nno spliced/unspliced")), size = 1.55) +
  scale_fill_manual(values = c(ineligible = pal[["light"]], eligible = pal[["teal"]])) + scale_x_continuous(NULL, breaks = NULL) + labs(y = NULL) + theme(legend.position = "none")

fig4 <- p4a + p4b + p4c + p4d + p4e + plot_layout(design = "AABB\nCCDD\nCCEE") + plot_annotation(tag_levels = "a") &
  theme(plot.tag.position = c(.01, .99))
save_pub(fig4, file.path(main_dir, "Figure4_mechanism_axes"), 183, 155)

# Figure 5 -------------------------------------------------------------------
spcells <- read_src("figure5", "representative_spatial_cells")
p5a <- ggplot(spcells, aes(x, y, colour = intrinsic_resistance_ecosystem)) + geom_point(size = .16, alpha = .9) +
  scale_colour_gradient2(low = pal[["blue2"]], mid = "white", high = pal[["red"]], midpoint = 0, limits = quantile(spcells$intrinsic_resistance_ecosystem, c(.02,.98), na.rm = TRUE), oob = squish) +
  coord_fixed() + labs(x = NULL, y = NULL, colour = "Resistance\necosystem", title = "Representative baseline region") +
  theme_void(base_family = "Helvetica") + theme(plot.title = element_text(size = 6.8, face = "bold"), legend.position = "right")

moran <- read_src("figure5", "spatial_autocorrelation") %>% mutate(feature = clean_fate(sub("^intrinsic_", "", feature)), label = sprintf("%.2f", moran_i))
p5b <- ggplot(moran, aes(feature, sample, fill = moran_i)) + geom_tile(colour = "white", linewidth = .35) + geom_text(aes(label = label), size = 1.35) +
  scale_fill_gradient(low = "white", high = pal[["blue"]], limits = c(0, max(moran$moran_i))) + labs(x = NULL, y = NULL, fill = "Moran's I") +
  theme(axis.text.x = element_text(angle = 35, hjust = 1), axis.text.y = element_text(size = 5.2))

niches <- read_src("figure5", "common_spatial_niches") %>% pivot_longer(c(apoptosis_pressure, proliferation, differentiation_proxy, stress, resistance_ecosystem), names_to = "axis", values_to = "score") %>%
  mutate(axis = clean_fate(axis), niche = paste0("N", spatial_niche), label = sprintf("%.2f", score))
p5c <- ggplot(niches, aes(axis, niche, fill = score)) + geom_tile(colour = "white", linewidth = .4) + geom_text(aes(label = label), size = 1.45) +
  scale_fill_gradient2(low = pal[["blue"]], mid = "white", high = pal[["red"]], midpoint = 0) + labs(x = NULL, y = NULL, fill = "Mean relative\naxis score") +
  theme(axis.text.x = element_text(angle = 35, hjust = 1))

paired <- read_src("figure5", "paired_future_targets") %>% select(patient, starts_with("delta_absolute_")) %>%
  pivot_longer(-patient, names_to = "axis", values_to = "delta") %>% mutate(axis = clean_fate(sub("^delta_absolute_", "", axis)))
p5d <- ggplot(paired, aes(delta, axis, colour = patient)) + geom_vline(xintercept = 0, linetype = 2, colour = pal[["grey"]], linewidth = .3) +
  geom_point(size = 1.7) + scale_colour_manual(values = c(su001 = pal[["blue"]], su002 = pal[["orange"]], su007 = pal[["teal"]])) +
  labs(x = "Post minus baseline absolute score", y = NULL, colour = "Patient") + theme(legend.position = "bottom")

joint <- read_src("figure5", "joint_model_metrics") %>% filter(metric == "mae") %>% mutate(model = clean_model(model))
p5e <- ggplot(joint, aes(reorder(model, value), value, fill = model)) + geom_col(width = .62) + geom_text(aes(label = sprintf("%.1f", value)), hjust = -0.12, size = 1.8) +
  coord_flip() + scale_fill_manual(values = c("intrinsic" = pal[["blue2"]], "joint" = pal[["violet"]], "spatial niche" = pal[["teal2"]], "training mean" = pal[["light"]])) +
  scale_y_continuous(expand = expansion(mult = c(0,.14))) + labs(x = NULL, y = "LOPO MAE (n = 4 patients)") + theme(legend.position = "none")

sqc <- read_src("figure5", "spatial_qc_sensitivity") %>% filter(comparison %in% c("moran_concordance_vs_primary", "patient_absolute_axis_concordance_vs_primary")) %>%
  mutate(comparison = recode(comparison, moran_concordance_vs_primary = "Moran", patient_absolute_axis_concordance_vs_primary = "Patient axes"))
p5f <- ggplot(sqc, aes(label, value, group = comparison, colour = comparison)) + geom_hline(yintercept = 1, colour = pal[["light"]]) + geom_line(linewidth = .55) + geom_point(size = 1.5) +
  scale_colour_manual(values = c(Moran = pal[["blue"]], `Patient axes` = pal[["teal"]])) + coord_cartesian(ylim = c(.95,1.005)) +
  labs(x = "Minimum-transcript QC", y = "Concordance with primary", colour = NULL) + theme(legend.position = "bottom")

fig5 <- p5a + p5b + p5c + p5d + p5e + p5f + plot_layout(design = "AABB\nCCDD\nEEFF") + plot_annotation(tag_levels = "a")
save_pub(fig5, file.path(main_dir, "Figure5_spatial_niches"), 183, 158)

# Figure 6 -------------------------------------------------------------------
emb <- read_src("figure6", "patient_fate_embeddings") %>% mutate(
  stable_subtype = paste0("S", stable_subtype),
  cohort = recode(cohort, ISPY2 = "I-SPY2", BEATAML = "BeatAML")
)
p6a <- ggplot() +
  annotate("rect", xmin = c(.1, 1.4, 2.7), xmax = c(1.0, 2.3, 3.8), ymin = .7, ymax = 1.35,
           fill = c(pal[["teal2"]], pal[["blue2"]], pal[["red2"]]), colour = pal[["ink"]], linewidth = .35) +
  annotate("text", x = c(.55,1.85,3.25), y = 1.02, label = c("Cell fate-axis\nweights", "Patient Fate\nEmbedding", "Cross-fitted response\nand stable subtypes"), size = 1.9) +
  annotate("segment", x = c(1.02,2.32), xend = c(1.37,2.67), y = 1.02, yend = 1.02, arrow = arrow(length = unit(1.4,"mm")), colour = pal[["grey"]]) +
  coord_cartesian(xlim = c(0,4), ylim = c(.55,1.5)) + theme_void()

p6b <- ggplot(emb, aes(PFE_1, PFE_2, colour = stable_subtype)) + geom_point(size = .55, alpha = .65) +
  facet_wrap(~cohort, scales = "free") + scale_colour_manual(values = c(S0 = pal[["blue"]], S1 = pal[["orange"]])) +
  labs(x = "PFE 1", y = "PFE 2", colour = "Stable subtype") + theme(legend.position = "bottom")

sub <- read_src("figure6", "stable_subtype_response") %>% mutate(
  cohort = recode(cohort, ISPY2 = "I-SPY2", BEATAML = "BeatAML"),
  stable_subtype = paste0("S", stable_subtype),
  se = sqrt(response_fraction * (1-response_fraction) / patients), lo = pmax(0, response_fraction - 1.96*se), hi = pmin(1, response_fraction + 1.96*se))
p6c <- ggplot(sub, aes(stable_subtype, response_fraction, fill = stable_subtype)) + geom_col(width = .62) + geom_errorbar(aes(ymin = lo, ymax = hi), width = .14) +
  facet_wrap(~cohort) + scale_y_continuous(labels = percent, limits = c(0,1)) + scale_fill_manual(values = c(S0 = pal[["blue"]], S1 = pal[["orange"]])) +
  labs(x = NULL, y = "Observed response fraction") + theme(legend.position = "none")

cv <- read_src("figure6", "clinical_cross_validation") %>% mutate(
  cohort = recode(cohort, ISPY2 = "I-SPY2", BEATAML = "BeatAML"),
  metric = recode(metric, auroc = "AUROC", average_precision = "AP", balanced_accuracy = "Bal. accuracy")
)
p6d <- ggplot(cv, aes(cohort, value, colour = cohort)) + geom_boxplot(width = .52, outlier.shape = NA, linewidth = .4) + geom_point(position = position_jitter(width = .08), size = .75) +
  facet_wrap(~metric) + scale_colour_manual(values = c(`I-SPY2` = pal[["blue"]], BeatAML = pal[["teal"]])) + labs(x = NULL, y = "Cross-validated metric") + theme(legend.position = "none")

clin <- read_src("figure6", "clinical_validation") %>% filter(cohort == "BEATAML", analysis == "overall_survival_cox") %>%
  mutate(across(c(estimate, ci_low, ci_high, pvalue), ~suppressWarnings(as.numeric(.x)))) %>%
  mutate(term = recode(term, cross_fitted_response_probability = "Cross-fitted response coordinate", stable_subtype = "Stable subtype"))
p6e <- ggplot(clin, aes(estimate, reorder(term, estimate))) + geom_vline(xintercept = 1, linetype = 2, colour = pal[["grey"]]) +
  geom_errorbar(aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = .18, linewidth = .45, colour = pal[["teal"]]) + geom_point(size = 1.7, colour = pal[["teal"]]) +
  scale_x_log10(breaks = c(.6,.8,1,1.2)) + labs(x = "BeatAML overall-survival hazard ratio", y = NULL)

evidence <- data.frame(cohort = c("I-SPY2","I-SPY2","BeatAML","BeatAML"), evidence = c("Subtype response","CV discrimination","Subtype response","Continuous survival"), result = c("positive","positive","negative","positive"))
p6f <- ggplot(evidence, aes(evidence, cohort, fill = result)) + geom_tile(colour = "white", linewidth = .5) + geom_text(aes(label = result), size = 1.7) +
  scale_fill_manual(values = c(positive = pal[["teal2"]], negative = pal[["red2"]])) + labs(x = NULL, y = NULL) + theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "none")

fig6 <- p6a + p6b + p6c + p6d + p6e + p6f + plot_layout(design = "AABB\nCCDD\nEEFF") + plot_annotation(tag_levels = "a")
save_pub(fig6, file.path(main_dir, "Figure6_patient_fate_embedding"), 183, 155)

# Figure 7 -------------------------------------------------------------------
ladder <- read_src("figure7", "evidence_ladder") %>% mutate(
  evidence_tier = gsub(" probability", "", evidence_tier),
  role_short = case_when(
    grepl("cell-line|drug", analysis_role) ~ "drug discovery",
    grepl("genetic perturbation", analysis_role) ~ "genetic stress test",
    grepl("lineage validation", analysis_role) ~ "lineage validation",
    grepl("lineage discovery", analysis_role) ~ "lineage discovery",
    grepl("trajectory", analysis_role) ~ "trajectory",
    grepl("spatial", analysis_role) ~ "spatial niches",
    grepl("tissue", analysis_role) ~ "paired tissue",
    grepl("clinical", analysis_role) ~ "clinical",
    TRUE ~ analysis_role
  ))
p7a <- ggplot(ladder, aes(role_short, reorder(dataset, input_numeric), fill = evidence_tier)) + geom_tile(colour = "white", linewidth = .5) +
  geom_text(aes(label = dataset), size = 1.45) +
  scale_fill_manual(values = c("gold lineage supervision" = pal[["teal"]], "silver transport supervision" = pal[["violet"]], "derived program" = pal[["blue"]],
                               "genetic derived program" = pal[["blue2"]], "spatial exploratory" = pal[["orange"]], "clinical projection" = pal[["red"]])) +
  labs(x = NULL, y = NULL, fill = "Evidence tier") + theme(axis.text.x = element_text(angle = 35, hjust = 1), axis.text.y = element_blank(), legend.position = "bottom")

status <- read_src("figure7", "transfer_success_failure_matrix") %>% mutate(
  label = ifelse(result == "positive", "+", "-"),
  validation_short = recode(validation, `leave-cell-line` = "cell line", `leave-perturbation` = "perturbation", `leave-dataset` = "dataset", `leave-GEM` = "GEM", `leave-patient` = "patient"),
  key = paste(validation_short, fate, sep = " | "))
p7b <- ggplot(status, aes(key, source, fill = result)) + geom_tile(colour = "white", linewidth = .45) + geom_text(aes(label = label), size = 2.2, fontface = "bold") +
  scale_fill_manual(values = c(positive = pal[["teal2"]], negative = pal[["red2"]])) + labs(x = NULL, y = NULL, fill = NULL) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 4.8), legend.position = "bottom")

manifest <- read_src("figure7", "resource_manifest") %>% mutate(extension = sub(".*\\.", "", file)) %>%
  group_by(extension) %>% summarise(files = n(), rows = sum(rows), megabytes = sum(bytes)/1e6, .groups = "drop")
p7c <- ggplot(manifest, aes(rows, reorder(extension, rows), size = megabytes, colour = extension)) + geom_point(alpha = .8) +
  scale_x_log10(labels = label_number(scale_cut = cut_si(""))) + scale_size(range = c(2,7)) + scale_colour_manual(values = c(parquet = pal[["blue"]], tsv = pal[["teal"]], json = pal[["orange"]])) +
  labs(x = "Resource rows (log scale)", y = "File type", size = "MB", colour = NULL) + theme(legend.position = "bottom")

p7d <- ggplot() +
  annotate("rect", xmin = c(.1, 1.4, 2.7), xmax = c(1.0, 2.3, 3.9), ymin = .78, ymax = 1.35,
           fill = c(pal[["blue2"]], pal[["teal2"]], pal[["pale"]]), colour = pal[["ink"]], linewidth = .35) +
  annotate("text", x = c(.55,1.85,3.3), y = 1.06, label = c("Intrinsic baseline\nheterogeneity", "Spatial tissue\norganization", "Future fate\nprobability distribution"), size = 1.9) +
  annotate("segment", x = c(1.02,2.32), xend = c(1.37,2.67), y = 1.06, yend = 1.06, arrow = arrow(length = unit(1.4,"mm")), colour = pal[["grey"]]) +
  annotate("text", x = 1.85, y = .55, label = "incremental niche prediction remains unproven", colour = pal[["red"]], size = 1.7) +
  coord_cartesian(xlim = c(0,4), ylim = c(.4,1.55)) + theme_void()

resource_counts <- data.frame(label = c("Files", "Checksum mismatches", "Evidence tiers", "Negative validations"), value = c(nrow(read_src("figure7","resource_manifest")), 0, 6, sum(status$result == "negative")))
p7e <- ggplot(resource_counts, aes(value, reorder(label, value), fill = label)) + geom_col(width = .62) + geom_text(aes(label = value), hjust = -0.15, size = 1.8) +
  scale_x_continuous(expand = expansion(mult = c(0,.15))) + scale_fill_manual(values = c(pal[["blue"]], pal[["teal"]], pal[["violet"]], pal[["red2"]])) + labs(x = NULL, y = NULL) + theme(legend.position = "none")

fig7 <- (p7a | p7b) / (p7c | p7d) / p7e + plot_layout(heights = c(1.15, .9, .75)) + plot_annotation(tag_levels = "a")
save_pub(fig7, file.path(main_dir, "Figure7_resource_synthesis"), 183, 155)

# Extended Data 1 ------------------------------------------------------------
ed1 <- read_src("extended_data1", "dataset_qc_audit") %>% filter(is.finite(input_numeric))
p_ed1a <- ggplot(ed1, aes(input_numeric, qc_or_target_numeric, colour = evidence_tier, label = dataset)) + geom_abline(slope=1, intercept=0, linetype=2, colour=pal[["grey"]]) +
  geom_point(size=1.8) + geom_text_repel(size=1.5, max.overlaps=Inf) + scale_x_log10(labels=label_number(scale_cut=cut_si(""))) + scale_y_log10(labels=label_number(scale_cut=cut_si(""))) +
  scale_colour_manual(values=c("gold lineage supervision"=pal[["teal"]],"silver transport supervision"=pal[["violet"]],"derived program probability"=pal[["blue"]],"genetic derived program probability"=pal[["blue2"]],"spatial exploratory"=pal[["orange"]],"clinical projection"=pal[["red"]])) +
  labs(x="Input units", y="QC cells or targets", colour="Evidence tier") + theme(legend.position="bottom")
p_ed1b <- ggplot(ed1 %>% filter(is.finite(retained_fraction), retained_fraction <= 1), aes(retained_fraction, reorder(dataset, retained_fraction), fill=evidence_tier)) + geom_col(width=.65) +
  scale_fill_manual(values=c("gold lineage supervision"=pal[["teal"]],"silver transport supervision"=pal[["violet"]],"derived program probability"=pal[["blue"]],"genetic derived program probability"=pal[["blue2"]],"spatial exploratory"=pal[["orange"]],"clinical projection"=pal[["red"]])) +
  scale_x_continuous(labels=percent, limits=c(0,1)) + labs(x="Retained fraction", y=NULL) + theme(legend.position="none")
edfig1 <- p_ed1a + p_ed1b + plot_annotation(tag_levels="a")
save_pub(edfig1, file.path(ext_dir,"ExtendedData1_dataset_qc"), 183, 105)

# Extended Data 2 ------------------------------------------------------------
ed2 <- read_src("extended_data2", "mixseq_complete_sensitivity") %>% filter(metric=="brier") %>%
  select(variant, min_cells, mad_multiplier, validation, target, model, mean_value) %>% pivot_wider(names_from=model, values_from=mean_value) %>%
  mutate(improvement=training_mean-baseline_scvi_ridge, fate=clean_fate(target), setting=paste0("n",min_cells," / ",mad_multiplier," MAD"), validation=gsub("_","-",validation))
p_ed2 <- ggplot(ed2,aes(fate,setting,fill=improvement)) + geom_tile(colour="white",linewidth=.35) + facet_wrap(~validation,nrow=1) +
  scale_fill_gradient2(low=pal[["red"]],mid="white",high=pal[["blue"]],midpoint=0) + labs(x=NULL,y="Target definition",fill="Brier improvement") +
  theme(axis.text.x=element_text(angle=35,hjust=1))
save_pub(p_ed2, file.path(ext_dir,"ExtendedData2_mixseq_sensitivity"), 183, 105)

# Extended Data 3 ------------------------------------------------------------
ed3 <- read_src("extended_data3", "cross_task_dataset_metrics") %>% filter(model!="training_mean") %>% mutate(target=clean_fate(target),validation=gsub("_"," ",validation))
ed3sum <- ed3 %>% group_by(validation,target,model,metric) %>% summarise(value=mean(value,na.rm=TRUE),.groups="drop") %>% filter(metric %in% c("spearman","mse"))
p_ed3 <- ggplot(ed3sum,aes(target,interaction(validation,metric,sep=" | "),fill=value)) + geom_tile(colour="white",linewidth=.35) + geom_text(aes(label=sprintf("%.2f",value)),size=1.35) +
  facet_wrap(~model,nrow=1) + scale_fill_gradient2(low=pal[["red"]],mid="white",high=pal[["blue"]],midpoint=0) + labs(x=NULL,y=NULL,fill="Mean") + theme(axis.text.x=element_text(angle=40,hjust=1),axis.text.y=element_text(size=5))
save_pub(p_ed3, file.path(ext_dir,"ExtendedData3_cross_transfer"), 183, 115)

# Extended Data 4 ------------------------------------------------------------
ed4 <- bind_rows(read_src("extended_data4","replogle_k562_fold_metrics") %>% mutate(cell_line="K562"), read_src("extended_data4","replogle_rpe1_fold_metrics") %>% mutate(cell_line="RPE1")) %>%
  mutate(fate=clean_fate(target),model=clean_model(model),validation=gsub("_","-",validation))
ed4sum <- mean_ci(ed4,c("cell_line","validation","fate","model","metric")) %>% filter(is.finite(mean))
p_ed4 <- ggplot(ed4sum,aes(model,mean,colour=model)) + geom_point(size=1.2) + geom_errorbar(aes(ymin=mean-ci,ymax=mean+ci),width=.15) +
  facet_grid(cell_line+validation~metric+fate,scales="free_y") + scale_colour_manual(values=c("baseline + perturbation"=pal[["blue"]],"perturbation descriptor"=pal[["teal"]],"training mean"=pal[["light"]])) +
  labs(x=NULL,y="Fold mean ± 95% CI",colour=NULL) + theme(axis.text.x=element_blank(),axis.ticks.x=element_blank(),legend.position="bottom",strip.text=element_text(size=5))
save_pub(p_ed4, file.path(ext_dir,"ExtendedData4_replogle_full"), 183, 145)

# Extended Data 5 ------------------------------------------------------------
cov <- read_src("extended_data5","panel_module_coverage") %>% distinct(module_type,module,genes_specified,genes_present) %>% mutate(fraction=genes_present/genes_specified,module=clean_fate(module))
p_ed5a <- ggplot(cov,aes(fraction,reorder(module,fraction),fill=module_type))+geom_col(width=.65)+scale_x_continuous(labels=percent,limits=c(0,1))+scale_fill_manual(values=c(cell_type=pal[["blue2"]],fate=pal[["teal2"]]))+labs(x="Targeted-panel marker coverage",y=NULL,fill=NULL)+theme(legend.position="bottom")
sq <- read_src("extended_data5","sample_qc") %>% mutate(retained=cells_qc/cells_input)
p_ed5b <- ggplot(sq,aes(retained,reorder(sample,retained),fill=patient))+geom_col(width=.65)+scale_fill_manual(values=c(su001=pal[["blue"]],su002=pal[["orange"]],su006=pal[["violet"]],su007=pal[["teal"]]))+scale_x_continuous(labels=percent,limits=c(0,1))+labs(x="Cell retention",y=NULL,fill="Patient")+theme(legend.position="bottom")
sens5 <- read_src("extended_data5","spatial_qc_sensitivity") %>% filter(comparison=="retained_cells") %>% mutate(label=factor(label,levels=c("min5","min10","min20")))
p_ed5c <- ggplot(sens5,aes(label,value,group=1))+geom_line(colour=pal[["blue"]],linewidth=.5)+geom_point(colour=pal[["blue"]],size=1.4)+labs(x="Minimum transcript threshold",y="Retained cells")
edfig5 <- p_ed5a+p_ed5b+p_ed5c+plot_layout(widths=c(1.3,1,1))+plot_annotation(tag_levels="a")
save_pub(edfig5,file.path(ext_dir,"ExtendedData5_spatial_audit"),183,105)

# Extended Data 6 ------------------------------------------------------------
cv6 <- read_src("extended_data6","clinical_cross_validation") %>% mutate(metric=recode(metric,auroc="AUROC",average_precision="Average precision",balanced_accuracy="Balanced accuracy"))
p_ed6a <- ggplot(cv6,aes(factor(fold),value,group=cohort,colour=cohort))+geom_line(linewidth=.45)+geom_point(size=1.2)+facet_wrap(~metric)+scale_colour_manual(values=c(ISPY2=pal[["blue"]],BEATAML=pal[["teal"]]))+labs(x="Outer fold",y="Metric",colour=NULL)+theme(legend.position="bottom")
val6 <- read_src("extended_data6","clinical_validation") %>% mutate(across(c(estimate,ci_low,ci_high,pvalue),~suppressWarnings(as.numeric(.x)))) %>% filter(is.finite(estimate)) %>% mutate(label=paste(cohort,analysis,term,sep=" | "))
p_ed6b <- ggplot(val6,aes(estimate,reorder(label,estimate),colour=cohort))+geom_vline(xintercept=1,linetype=2,colour=pal[["grey"]])+geom_errorbar(aes(xmin=ci_low,xmax=ci_high),orientation="y",width=.16,na.rm=TRUE)+geom_point(size=1.3)+scale_colour_manual(values=c(ISPY2=pal[["blue"]],BEATAML=pal[["teal"]]))+labs(x="Effect estimate",y=NULL,colour=NULL)+theme(legend.position="bottom",axis.text.y=element_text(size=5))
edfig6 <- p_ed6a+p_ed6b+plot_layout(widths=c(1.25,1))+plot_annotation(tag_levels="a")
save_pub(edfig6,file.path(ext_dir,"ExtendedData6_clinical_diagnostics"),183,110)

# Extended Data 7 ------------------------------------------------------------
v7 <- read_src("extended_data7","velocity_eligibility") %>% mutate(dataset=sub("\\.h5ad$","",file))
p_ed7a <- ggplot(v7,aes(1,reorder(dataset,cells),fill=rna_velocity_eligible))+geom_tile(colour="white")+geom_text(aes(label=paste0(format(cells,big.mark=",")," cells")),size=1.6)+scale_fill_manual(values=c(`False`=pal[["light"]],`True`=pal[["teal"]]))+scale_x_continuous(NULL,breaks=NULL)+labs(y=NULL,fill="Velocity eligible")+theme(legend.position="bottom")
m7 <- read_src("extended_data7","resource_manifest") %>% mutate(extension=sub(".*\\.","",file))
p_ed7b <- ggplot(m7,aes(rows,reorder(file,rows),colour=extension,size=bytes))+geom_point(alpha=.75)+scale_x_log10(labels=label_number(scale_cut=cut_si("")))+scale_colour_manual(values=c(parquet=pal[["red2"]],tsv=pal[["teal2"]],json=pal[["orange"]]))+scale_size(range=c(.8,5),guide="none")+labs(x="Rows (log scale)",y=NULL,colour="Type")+theme(axis.text.y=element_text(size=4.2),legend.position="bottom")
edfig7 <- p_ed7a+p_ed7b+plot_layout(widths=c(.8,1.6))+plot_annotation(tag_levels="a")
save_pub(edfig7,file.path(ext_dir,"ExtendedData7_resource_audit"),183,145)

cat("All R figures exported.\n")
