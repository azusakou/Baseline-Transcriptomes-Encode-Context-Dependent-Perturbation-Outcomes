#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = FALSE)
script_file <- sub("^--file=", "", args[grep("^--file=", args)][1])
root <- normalizePath(file.path(dirname(script_file), "..", ".."), mustWork = TRUE)
fig_root <- file.path(root, "figures")

expected <- c(
  file.path("main", c("Figure1_study_design", "Figure2_lineage_prediction", "Figure3_generalization", "Figure4_mechanism_axes", "Figure5_spatial_niches", "Figure6_patient_fate_embedding", "Figure7_resource_synthesis")),
  file.path("extended", c("ExtendedData1_dataset_qc", "ExtendedData2_mixseq_sensitivity", "ExtendedData3_cross_transfer", "ExtendedData4_replogle_full", "ExtendedData5_spatial_audit", "ExtendedData6_clinical_diagnostics", "ExtendedData7_resource_audit"))
)
extensions <- c("svg", "pdf", "tiff", "png")
checks <- expand.grid(stem = expected, extension = extensions, stringsAsFactors = FALSE)
checks$file <- file.path(fig_root, paste0(checks$stem, ".", checks$extension))
checks$exists <- file.exists(checks$file)
checks$bytes <- ifelse(checks$exists, file.info(checks$file)$size, NA_real_)

signature_ok <- function(path, ext) {
  if (!file.exists(path) || file.info(path)$size == 0) return(FALSE)
  con <- file(path, "rb"); on.exit(close(con))
  raw <- readBin(con, "raw", n = 16)
  if (ext == "pdf") return(rawToChar(raw[1:4]) == "%PDF")
  if (ext == "png") return(identical(as.integer(raw[1:8]), c(137L,80L,78L,71L,13L,10L,26L,10L)))
  if (ext == "tiff") return(rawToChar(raw[1:2]) %in% c("II", "MM"))
  if (ext == "svg") return(grepl("<svg|<\\?xml", paste(readLines(path, n = 3, warn = FALSE), collapse = "")))
  FALSE
}
checks$signature_ok <- mapply(signature_ok, checks$file, checks$extension)
checks$status <- ifelse(checks$exists & checks$bytes > 0 & checks$signature_ok, "pass", "fail")

source_files <- list.files(file.path(fig_root, "source_data"), pattern = "\\.tsv$", recursive = TRUE, full.names = TRUE)
source_ok <- length(source_files) > 0 && all(file.info(source_files)$size > 0)
dir.create(file.path(root, "reports"), showWarnings = FALSE)
write.table(checks[, c("stem", "extension", "bytes", "signature_ok", "status")], file.path(root, "reports", "figure_export_audit.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

if (any(checks$status != "pass") || !source_ok) stop("Figure export validation failed")
cat(sprintf("PASS: %d figure files across %d figures; %d non-empty source-data tables.\n", nrow(checks), length(expected), length(source_files)))
