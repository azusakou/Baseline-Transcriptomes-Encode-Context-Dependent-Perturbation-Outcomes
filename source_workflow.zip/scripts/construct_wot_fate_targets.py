#!/usr/bin/env python3
"""Propagate terminal fate sets backward through official WOT transport maps."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse


PATTERN = re.compile(r"serum_([0-9.]+)_([0-9.]+)\.h5ad$")


def read_gmt(path: Path) -> dict[str, set[str]]:
    result = {}
    with path.open() as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            result[fields[0]] = set(fields[2:])
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--transport-dir", type=Path, required=True)
    parser.add_argument("--terminal-sets", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    maps = []
    for path in args.transport_dir.glob("serum_*_*.h5ad"):
        match = PATTERN.match(path.name)
        if match:
            maps.append((float(match.group(1)), float(match.group(2)), path))
    maps.sort()
    if not maps:
        raise FileNotFoundError("no serum transport maps")
    for previous, current in zip(maps, maps[1:]):
        if previous[1] != current[0]:
            raise ValueError(f"non-contiguous maps: {previous[:2]} -> {current[:2]}")

    terminal_map = ad.read_h5ad(maps[-1][2], backed="r")
    terminal_ids = pd.Index(terminal_map.var_names.astype(str), name="cell_id")
    terminal_map.file.close()
    sets = read_gmt(args.terminal_sets)
    branches = list(sets)
    membership = np.zeros((len(terminal_ids), len(branches) + 1), dtype=np.float32)
    for index, branch in enumerate(branches):
        membership[:, index] = terminal_ids.isin(sets[branch]).astype(np.float32)
    assigned = membership[:, :-1].sum(axis=1)
    membership[:, -1] = (assigned == 0).astype(np.float32)
    membership /= membership.sum(axis=1, keepdims=True)
    branches.append("Other")
    terminal_prevalence = membership.mean(axis=0)
    rare = [branch for branch, prevalence in zip(branches, terminal_prevalence) if prevalence < 0.10]

    current_ids = terminal_ids
    current = membership
    frames = []
    for source_day, target_day, path in reversed(maps):
        data = ad.read_h5ad(path)
        target_ids = pd.Index(data.var_names.astype(str))
        order = current_ids.get_indexer(target_ids)
        if (order < 0).any():
            raise ValueError(f"{path.name}: {(order < 0).sum()} target cells absent from downstream map")
        downstream = current[order]
        transport = sparse.csr_matrix(data.X, dtype=np.float64)
        row_sum = np.asarray(transport.sum(axis=1)).ravel()
        transition = sparse.diags(np.divide(1.0, row_sum, out=np.zeros_like(row_sum), where=row_sum > 0)) @ transport
        probabilities = np.asarray(transition @ downstream, dtype=np.float32)
        probabilities /= probabilities.sum(axis=1, keepdims=True)
        logp = np.zeros_like(probabilities)
        np.log(probabilities, out=logp, where=probabilities > 0)
        frame = pd.DataFrame({
            "cell_id": data.obs_names.astype(str),
            "day": source_day,
            "next_day": target_day,
            "transition_entropy": -(probabilities * logp).sum(axis=1),
            "normalized_transition_entropy": -(probabilities * logp).sum(axis=1) / np.log(len(branches)),
        })
        for index, branch in enumerate(branches):
            frame[f"p_branch_{branch.lower()}"] = probabilities[:, index]
        rare_index = [branches.index(branch) for branch in rare]
        frame["p_rare_fate"] = probabilities[:, rare_index].sum(axis=1)
        for column in data.obs.columns:
            if str(column).startswith("g"):
                frame[f"growth_{column}"] = data.obs[column].to_numpy()
        frames.append(frame)
        current_ids = pd.Index(data.obs_names.astype(str), name="cell_id")
        current = probabilities
        print(f"propagated day {source_day}: cells={len(frame)}", flush=True)
        del data, transport, transition

    result = pd.concat(list(reversed(frames)), ignore_index=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.suffix == ".parquet":
        result.to_parquet(args.output, index=False)
    else:
        result.to_csv(args.output, sep="\t", index=False)
    print(f"wrote {len(result)} cells; branches={branches}; rare={rare}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
