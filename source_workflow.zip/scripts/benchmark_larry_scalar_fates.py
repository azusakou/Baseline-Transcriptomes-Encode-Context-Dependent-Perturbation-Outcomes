#!/usr/bin/env python3
"""Clone-held-out prediction of LARRY entropy, expansion and rare-fate potential."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold


TARGETS = ["p_differentiation", "transition_entropy", "p_rare_fate", "clone_expansion"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expression", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--assignments", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    targets = pd.read_csv(args.targets, sep="\t").set_index("target_id")
    assignment = pd.read_csv(args.assignments, sep="\t")
    rows = assignment.join(targets[TARGETS], on="target_id")
    cells = pd.Index(rows.cell_id.unique()); source = ad.read_h5ad(args.expression, backed="r")
    positions = source.obs_names.get_indexer(cells); baseline = source[positions].to_memory(); source.file.close()
    cell_position = pd.Series(np.arange(len(cells)), index=cells); row_position = rows.cell_id.map(cell_position).to_numpy()
    units = rows.drop_duplicates("target_id").reset_index(drop=True)
    groups = units.clone_id.to_numpy(); conditions = pd.get_dummies(units.future_condition.astype(str), dtype=float).to_numpy()
    metrics, predictions = [], []
    for fold, (train, test) in enumerate(GroupKFold(5).split(units, groups=groups), 1):
        train_ids = set(units.iloc[train].target_id)
        train_cells = np.unique(row_position[rows.target_id.isin(train_ids)])
        svd = TruncatedSVD(50, random_state=20260713 + fold).fit(baseline.X[train_cells])
        latent = svd.transform(baseline.X)
        latent_rows = pd.DataFrame(latent[row_position]); latent_rows["target_id"] = rows.target_id.to_numpy()
        target_latent = latent_rows.groupby("target_id", observed=True).mean().loc[units.target_id].to_numpy()
        features = np.column_stack([target_latent, conditions])
        for target in TARGETS:
            observed_train = units.iloc[train][target].to_numpy(float); observed_test = units.iloc[test][target].to_numpy(float)
            transform = np.log1p if target == "clone_expansion" else lambda x: x
            inverse = np.expm1 if target == "clone_expansion" else lambda x: x
            model = Ridge(alpha=10).fit(features[train], transform(observed_train))
            prediction = inverse(model.predict(features[test])); baseline_prediction = np.repeat(observed_train.mean(), len(test))
            if target.startswith("p_"): prediction = np.clip(prediction, 0, 1)
            for model_name, value in [("baseline_latent_ridge", prediction), ("training_mean", baseline_prediction)]:
                metrics.extend([
                    {"fold": fold, "target": target, "model": model_name, "metric": "spearman", "value": spearmanr(observed_test, value).statistic if np.std(value) else np.nan},
                    {"fold": fold, "target": target, "model": model_name, "metric": "mae", "value": np.mean(np.abs(observed_test - value))},
                ])
            frame = units.iloc[test][["clone_id", "target_id", "future_condition"]].copy(); frame["fold"] = fold; frame["target"] = target; frame["observed"] = observed_test; frame["predicted"] = prediction; predictions.append(frame)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(metrics).to_csv(args.output_dir / "scalar_fate_metrics.tsv", sep="\t", index=False)
    pd.concat(predictions, ignore_index=True).to_parquet(args.output_dir / "scalar_fate_predictions.parquet", index=False)
    print(pd.DataFrame(metrics).groupby(["target", "model", "metric"]).value.mean().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
