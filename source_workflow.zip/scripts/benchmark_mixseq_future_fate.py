#!/usr/bin/env python3
"""Predict MIX-seq continuous future-fate targets from baseline scVI state."""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.stats import ConstantInputWarning, spearmanr
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


TARGETS = ["p_apoptosis", "p_proliferation", "p_stress", "external_resistance_quantile"]


def aggregate_baseline(path: Path) -> pd.DataFrame:
    source = ad.read_h5ad(path, backed="r")
    latent = np.asarray(source.obsm["X_baseline_scvi"])
    obs = source.obs[["cell_line", "experiment", "time_hours"]].reset_index(drop=True)
    source.file.close()
    keys = ["cell_line", "experiment", "time_hours"]
    frames = []
    # Some captures (notably expt10) have no annotated treatment time.  They are
    # still valid matched contexts, so retain NA as an explicit grouping key.
    for name, index in obs.groupby(keys, observed=True, dropna=False).indices.items():
        values = latent[index]
        row = dict(zip(keys, name, strict=True))
        row["baseline_cells_used"] = len(index)
        for j in range(values.shape[1]):
            row[f"z{j}_mean"] = values[:, j].mean()
            row[f"z{j}_sd"] = values[:, j].std()
            row[f"z{j}_q10"] = np.quantile(values[:, j], 0.1)
            row[f"z{j}_q90"] = np.quantile(values[:, j], 0.9)
        frames.append(row)
    return pd.DataFrame(frames)


def evaluate(rows: pd.DataFrame, mode: str, output: Path) -> None:
    numerical = [column for column in rows if column.startswith("z") or column == "time_hours"]
    categorical = ["perturbation"]
    transformer = ColumnTransformer(
        [
            ("numeric", make_pipeline(SimpleImputer(), StandardScaler()), numerical),
            ("perturbation", OneHotEncoder(handle_unknown="ignore"), categorical),
        ]
    )
    groups = rows.cell_line if mode == "leave_cell_line" else rows.perturbation
    splitter = GroupKFold(n_splits=min(5, groups.nunique())) if mode == "leave_cell_line" else LeaveOneGroupOut()
    metric_rows, prediction_rows = [], []
    for fold, (train, test) in enumerate(splitter.split(rows, groups=groups), 1):
        for target in [name for name in TARGETS if name in rows.columns]:
            train_ok = rows.iloc[train][target].notna().to_numpy()
            test_ok = rows.iloc[test][target].notna().to_numpy()
            train_index, test_index = train[train_ok], test[test_ok]
            if len(train_index) < 20 or len(test_index) == 0:
                continue
            model = make_pipeline(transformer, Ridge(alpha=10.0))
            model.fit(rows.iloc[train_index], rows.iloc[train_index][target])
            prediction = np.clip(model.predict(rows.iloc[test_index]), 0, 1)
            observed = rows.iloc[test_index][target].to_numpy(float)
            baseline = np.repeat(rows.iloc[train_index][target].mean(), len(test_index))
            for model_name, value in [("baseline_scvi_ridge", prediction), ("training_mean", baseline)]:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", ConstantInputWarning)
                    rho = spearmanr(observed, value).statistic if np.std(value) > 0 and np.std(observed) > 0 else np.nan
                metric_rows.extend(
                    [
                        {"validation": mode, "fold": fold, "held_out": ",".join(sorted(groups.iloc[test].unique())), "target": target, "model": model_name, "metric": "brier", "value": np.mean((observed - value) ** 2)},
                        {"validation": mode, "fold": fold, "held_out": ",".join(sorted(groups.iloc[test].unique())), "target": target, "model": model_name, "metric": "mae", "value": np.mean(np.abs(observed - value))},
                        {"validation": mode, "fold": fold, "held_out": ",".join(sorted(groups.iloc[test].unique())), "target": target, "model": model_name, "metric": "spearman", "value": rho},
                    ]
                )
            frame = rows.iloc[test_index][["pair_id", "cell_line", "perturbation", "time_hours"]].copy()
            frame["validation"] = mode
            frame["fold"] = fold
            frame["target"] = target
            frame["observed"] = observed
            frame["predicted"] = prediction
            prediction_rows.append(frame)
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(metric_rows).to_csv(output / f"{mode}_metrics.tsv", sep="\t", index=False)
    pd.concat(prediction_rows, ignore_index=True).to_parquet(output / f"{mode}_predictions.parquet", index=False)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    state = aggregate_baseline(args.baseline)
    targets = pd.read_csv(args.targets, sep="\t")
    rows = targets.merge(state, on=["cell_line", "experiment", "time_hours"], validate="many_to_one")
    if len(rows) != len(targets):
        print(f"matched {len(rows)}/{len(targets)} pairs to the DMSO baseline atlas; non-DMSO genetic controls are excluded from this chemical benchmark")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows.to_parquet(args.output_dir / "modeling_table.parquet", index=False)
    for mode in ["leave_cell_line", "leave_perturbation"]:
        evaluate(rows, mode, args.output_dir)
    metrics = pd.concat(
        [pd.read_csv(args.output_dir / f"{mode}_metrics.tsv", sep="\t") for mode in ["leave_cell_line", "leave_perturbation"]]
    )
    print(metrics.groupby(["validation", "target", "model", "metric"]).value.mean().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
