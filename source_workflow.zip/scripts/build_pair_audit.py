#!/usr/bin/env python3
"""Audit baseline-treatment pseudo-pairs from per-condition single-cell files."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import pandas as pd


CONTROL_NAMES = {"dmso", "untreated", "vehicle", "control", "mock", "ntc"}


def summarize(path: Path, use_final_qc: bool) -> pd.DataFrame:
    data = ad.read_h5ad(path, backed="r")
    obs = data.obs.copy()
    data.file.close()
    if use_final_qc and "passes_qc_final" in obs:
        obs = obs.loc[obs["passes_qc_final"].fillna(False).astype(bool)]
    needed = ["dataset_id", "experiment", "time_hours", "perturbation", "task", "cell_line"]
    missing = set(needed) - set(obs)
    if missing:
        raise ValueError(f"{path}: missing columns {sorted(missing)}")
    keys = needed
    out = obs.groupby(keys, observed=True, dropna=False).size().rename("cells").reset_index()
    out["source_file"] = str(path)
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pattern", default="*.h5ad")
    parser.add_argument("--use-final-qc", action="store_true")
    parser.add_argument("--min-cells-per-arm", type=int, default=10)
    args = parser.parse_args()
    paths = sorted(p for p in args.input_dir.glob(args.pattern) if not p.name.startswith("._"))
    frames = [summarize(p, args.use_final_qc) for p in paths]
    if not frames:
        raise FileNotFoundError(f"no files matched {args.input_dir / args.pattern}")
    groups = pd.concat(frames, ignore_index=True)
    groups["is_control"] = groups["perturbation"].astype(str).str.lower().isin(CONTROL_NAMES)
    controls = groups.loc[groups.is_control].copy()
    treated = groups.loc[~groups.is_control].copy()
    match = ["dataset_id", "experiment", "time_hours", "task", "cell_line"]
    pairs = treated.merge(controls, on=match, suffixes=("_treated", "_baseline"), how="inner")
    pairs = pairs.rename(columns={"perturbation_treated": "treatment", "perturbation_baseline": "baseline"})
    pairs["pair_id"] = (
        pairs[match].astype(str).agg("|".join, axis=1) + "|" +
        pairs["baseline"].astype(str) + "->" + pairs["treatment"].astype(str)
    )
    pairs["eligible"] = (
        (pairs["cells_baseline"] >= args.min_cells_per_arm) &
        (pairs["cells_treated"] >= args.min_cells_per_arm)
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pairs.sort_values(["dataset_id", "experiment", "time_hours", "treatment", "cell_line"]).to_csv(args.output, sep="\t", index=False)
    eligible = pairs.loc[pairs.eligible]
    print(
        f"pairs={len(pairs)} eligible={len(eligible)}; "
        f"baseline_cells={eligible.cells_baseline.sum()} treated_cells={eligible.cells_treated.sum()}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
