#!/usr/bin/env python3
"""Benchmark baseline-context transfer for Replogle genetic perturbations."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


TARGETS = ["p_apoptosis", "p_proliferation", "p_stress"]


def metrics(observed: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    return {
        "brier": float(np.mean(np.square(observed - predicted))),
        "mae": float(np.mean(np.abs(observed - predicted))),
        "spearman": float(spearmanr(observed, predicted).statistic) if np.std(predicted) > 0 else np.nan,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--h5ad", type=Path, required=True)
    parser.add_argument("--cell-scores", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--features", type=int, default=1500)
    parser.add_argument("--components", type=int, default=20)
    args = parser.parse_args(); cells = pd.read_parquet(args.cell_scores)
    adata = ad.read_h5ad(args.h5ad, backed="r"); obs = adata.obs
    if not np.array_equal(cells.cell_id.astype(str).to_numpy(), obs.index.astype(str).to_numpy()):
        raise ValueError("cell score order does not match H5AD")
    control_index = np.flatnonzero(cells.passes_qc_final.to_numpy(bool) & cells.gene.eq("non-targeting").to_numpy())
    ranking = pd.to_numeric(adata.var.fano, errors="coerce").fillna(0).to_numpy()
    feature_index = np.argsort(ranking)[-min(args.features, adata.n_vars):]; feature_index.sort()
    raw = np.asarray(adata.X[control_index, :], dtype=np.float32)
    library = raw.sum(axis=1); normalized = np.log1p(raw / np.maximum(library[:, None], 1) * 1e4)
    latent = PCA(n_components=args.components, svd_solver="randomized", random_state=20260713).fit_transform(normalized[:, feature_index])
    group = cells.iloc[control_index].gem_group.to_numpy()
    latent_frame = pd.DataFrame(latent, columns=[f"baseline_latent_{i + 1}" for i in range(args.components)])
    latent_frame["gem_group"] = group
    baseline = latent_frame.groupby("gem_group", observed=True).mean().reset_index()
    gene_to_index = {gene: index for index, gene in enumerate(adata.var.gene_name.astype(str))}
    targets = pd.read_csv(args.targets, sep="\t")
    target_genes = sorted(set(targets.perturbation) & set(gene_to_index))
    target_position = np.array([gene_to_index[gene] for gene in target_genes])
    expression = pd.DataFrame(normalized[:, target_position], columns=target_genes)
    expression["gem_group"] = group
    by_group = expression.groupby("gem_group", observed=True).mean().stack().rename("target_baseline_expression").rename_axis(["gem_group", "perturbation"]).reset_index()
    overall = expression.drop(columns="gem_group").agg(["mean", "std"]).T.rename(columns={"mean": "target_expression_mean", "std": "target_expression_sd"}).rename_axis("perturbation").reset_index()
    overall["target_expression_cv"] = overall.target_expression_sd / overall.target_expression_mean.clip(lower=1e-8)
    overall["target_expression_fano"] = overall.target_expression_sd.pow(2) / overall.target_expression_mean.clip(lower=1e-8)
    adata.file.close()
    rows = targets.merge(baseline, on="gem_group", validate="many_to_one").merge(by_group, on=["gem_group", "perturbation"], how="inner").merge(overall, on="perturbation", validate="many_to_one")
    latent_features = [column for column in rows if column.startswith("baseline_latent_")]
    # Every perturbation descriptor is computed from non-targeting baseline
    # controls only. Global H5AD var statistics are deliberately excluded because
    # they summarize treated cells and would contaminate leave-perturbation tests.
    descriptor_features = ["target_expression_mean", "target_expression_sd", "target_expression_cv", "target_expression_fano"]
    feature_sets = {
        "perturbation_descriptor": descriptor_features,
        "baseline_plus_perturbation": latent_features + descriptor_features + ["target_baseline_expression"],
    }
    all_metrics = []; predictions = []
    for validation, grouping in [("leave_perturbation", "perturbation"), ("leave_gem_group", "gem_group")]:
        groups = rows[grouping].astype(str).to_numpy(); splitter = GroupKFold(5)
        for fold, (train, test) in enumerate(splitter.split(rows, groups=groups), 1):
            fold_rows = rows.copy()
            encoder_fit_scope = "all_baseline_controls_outcome_free"
            if validation == "leave_gem_group":
                # Strictly inductive encoder audit: the PCA basis is estimated only
                # from baseline controls belonging to training GEM groups. Baseline
                # expression from a held-out GEM is available at inference, but it
                # does not influence representation learning.
                train_gems = set(rows.iloc[train].gem_group.astype(str))
                fit_mask = np.array([str(value) in train_gems for value in group])
                fold_pca = PCA(n_components=args.components, svd_solver="randomized", random_state=20260713 + fold)
                fold_pca.fit(normalized[fit_mask][:, feature_index])
                fold_latent = fold_pca.transform(normalized[:, feature_index])
                fold_frame = pd.DataFrame(fold_latent, columns=latent_features)
                fold_frame["gem_group"] = group
                fold_baseline = fold_frame.groupby("gem_group", observed=True).mean()
                for column in latent_features:
                    fold_rows[column] = fold_rows.gem_group.map(fold_baseline[column])
                encoder_fit_scope = "training_gem_baseline_controls_only"
            for target in TARGETS:
                observed = fold_rows[target].to_numpy(float)
                mean = np.repeat(observed[train].mean(), len(test))
                for model_name, prediction in [("training_mean", mean)]:
                    for metric, value in metrics(observed[test], prediction).items():
                        all_metrics.append({"validation": validation, "fold": fold, "target": target, "model": model_name, "metric": metric, "value": value, "encoder_fit_scope": encoder_fit_scope})
                for model_name, features in feature_sets.items():
                    model = make_pipeline(StandardScaler(), Ridge(alpha=100.0))
                    model.fit(fold_rows.iloc[train][features], observed[train]); prediction = np.clip(model.predict(fold_rows.iloc[test][features]), 0, 1)
                    for index, value in zip(test, prediction, strict=True):
                        predictions.append({"validation": validation, "fold": fold, "row": int(index), "pair_id": fold_rows.iloc[index].pair_id, "target": target, "model": model_name, "observed": observed[index], "predicted": value, "encoder_fit_scope": encoder_fit_scope})
                    for metric, value in metrics(observed[test], prediction).items():
                        all_metrics.append({"validation": validation, "fold": fold, "target": target, "model": model_name, "metric": metric, "value": value, "encoder_fit_scope": encoder_fit_scope})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows.to_parquet(args.output_dir / "modeling_table.parquet", index=False)
    pd.DataFrame(all_metrics).to_csv(args.output_dir / "metrics.tsv", sep="\t", index=False)
    pd.DataFrame(predictions).to_parquet(args.output_dir / "predictions.parquet", index=False)
    print(pd.DataFrame(all_metrics).groupby(["validation", "target", "model", "metric"]).value.mean().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
