#!/usr/bin/env python3
"""Construct patient-level future tissue-state targets from paired Xenium data."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def aggregate(cells: pd.DataFrame, prefix: str, sample_programs: pd.DataFrame | None = None) -> pd.DataFrame:
    # First summarize each physical region, then average regions within a
    # patient. This prevents large regions from dominating paired tissue-state
    # estimates when the number and size of sampled regions differ over time.
    type_counts = cells.groupby(["patient", "sample", "cell_type"], observed=True).size().unstack(fill_value=0)
    types = type_counts.div(type_counts.sum(axis=1), axis=0).groupby(level=0).mean().add_prefix(f"{prefix}fraction__")
    # Within-sample z-scored intrinsic_* values are appropriate for spatial
    # patterning but average to zero by construction. Patient-level pre/post
    # changes therefore use cross-sample-comparable absolute_* module means.
    if sample_programs is None:
        programs = [column for column in cells if column.startswith("absolute_")]
        scores = cells.groupby(["patient", "sample"], observed=True)[programs].mean().groupby(level=0).mean().add_prefix(prefix)
    else:
        programs = [column for column in sample_programs if column.startswith("absolute_")]
        scores = sample_programs.groupby("patient", observed=True)[programs].mean().add_prefix(prefix)
    sample_count = cells.groupby("patient", observed=True).agg(**{f"{prefix}cells": ("cell_id", "size"), f"{prefix}samples": ("sample", "nunique")})
    return sample_count.join(types).join(scores)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pre-cells", type=Path, required=True)
    parser.add_argument("--post-cells", type=Path, required=True)
    parser.add_argument("--pre-spots", type=Path, required=True)
    parser.add_argument("--pre-sample-programs", type=Path)
    parser.add_argument("--post-sample-programs", type=Path)
    parser.add_argument("--patient-output", type=Path, required=True)
    parser.add_argument("--spot-output", type=Path, required=True)
    args = parser.parse_args()
    pre_cells = pd.read_parquet(args.pre_cells); post_cells = pd.read_parquet(args.post_cells)
    pre_programs = pd.read_csv(args.pre_sample_programs, sep="\t") if args.pre_sample_programs else None
    post_programs = pd.read_csv(args.post_sample_programs, sep="\t") if args.post_sample_programs else None
    paired = aggregate(pre_cells, "baseline_", pre_programs).join(aggregate(post_cells, "future_", post_programs), how="inner")
    future_columns = [column for column in paired if column.startswith("future_")]
    for future in future_columns:
        if future in {"future_cells", "future_samples"}:
            continue
        baseline = "baseline_" + future.removeprefix("future_")
        if baseline in paired and pd.api.types.is_numeric_dtype(paired[future]):
            paired["delta_" + future.removeprefix("future_")] = paired[future] - paired[baseline]
    paired.index.name = "patient"; paired = paired.reset_index()
    spots = pd.read_parquet(args.pre_spots).merge(paired, on="patient", validate="many_to_one")
    args.patient_output.parent.mkdir(parents=True, exist_ok=True)
    paired.to_csv(args.patient_output, sep="\t", index=False)
    spots.to_parquet(args.spot_output, index=False)
    print(f"paired patients={len(paired)}, baseline spots={len(spots)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
