#!/usr/bin/env python3
"""Run scDblFinder per Replogle GEM group without loading the full dense H5AD."""

from __future__ import annotations

import argparse
import gzip
import os
import subprocess
import tempfile
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--r-lib", type=Path, required=True)
    parser.add_argument("--features", type=int, default=2000)
    parser.add_argument("--max-groups", type=int)
    parser.add_argument("--r-script", type=Path, default=Path(__file__).with_name("run_scdblfinder.R"))
    args = parser.parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    adata = ad.read_h5ad(args.input, backed="r")
    obs = adata.obs.copy()
    ranking = pd.to_numeric(adata.var.get("fano", 0), errors="coerce").fillna(0).to_numpy()
    feature_index = np.argsort(ranking)[-min(args.features, adata.n_vars):]
    feature_index.sort()
    groups = list(obs.groupby("gem_group", observed=True).indices.items())
    if args.max_groups is not None:
        groups = groups[: args.max_groups]
    env = os.environ.copy(); env["R_LIBS_USER"] = str(args.r_lib)
    summaries = []
    for number, indices in groups:
        output = args.output_dir / f"gem_group_{number}.tsv"
        if output.exists():
            result = pd.read_csv(output, sep="\t")
            summaries.append({"gem_group": number, "cells": len(result), "doublets": result["scDblFinder.class"].eq("doublet").sum()})
            print(f"SKIP gem_group={number}", flush=True)
            continue
        indices = np.sort(np.asarray(indices, dtype=int))
        # h5py permits one fancy axis at a time. Each GEM group is small enough
        # to read once, after which feature restriction sharply reduces R memory.
        matrix = np.asarray(adata.X[indices, :], dtype=np.float32)[:, feature_index]
        counts = sparse.csr_matrix(matrix)
        del matrix
        with tempfile.TemporaryDirectory(prefix=f"replogle_g{number}_", dir=args.output_dir) as temporary:
            tmp = Path(temporary); plain = tmp / "counts.mtx"; compressed = tmp / "counts.mtx.gz"
            mmwrite(plain, counts.transpose().tocoo())
            with plain.open("rb") as source, gzip.open(compressed, "wb", compresslevel=1) as destination:
                while block := source.read(16 * 1024 * 1024):
                    destination.write(block)
            cells = pd.DataFrame({"cell_id": obs.index[indices].astype(str), "batch": str(number)})
            cells_path = tmp / "cells.tsv"; result_path = tmp / "result.tsv"
            cells.to_csv(cells_path, sep="\t", index=False)
            subprocess.run(["Rscript", str(args.r_script), str(compressed), str(cells_path), str(result_path)], check=True, env=env)
            result = pd.read_csv(result_path, sep="\t")
            result["gem_group"] = number
            result.to_csv(output, sep="\t", index=False)
        doublets = int(result["scDblFinder.class"].eq("doublet").sum())
        summaries.append({"gem_group": number, "cells": len(result), "doublets": doublets})
        print(f"DONE gem_group={number} doublets={doublets}/{len(result)}", flush=True)
    adata.file.close()
    summary = pd.DataFrame(summaries)
    summary.to_csv(args.output_dir / "scdblfinder_summary.tsv", sep="\t", index=False)
    parts = [pd.read_csv(path, sep="\t") for path in sorted(args.output_dir.glob("gem_group_*.tsv"))]
    if parts:
        pd.concat(parts, ignore_index=True).to_parquet(args.output_dir / "scdblfinder_calls.parquet", index=False)
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
