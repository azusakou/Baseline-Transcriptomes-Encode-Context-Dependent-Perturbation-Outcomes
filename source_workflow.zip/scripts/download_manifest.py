#!/usr/bin/env python3
"""Resumable manifest downloader with size and MD5 verification."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


def md5sum(path: Path, chunk: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        while block := handle.read(chunk):
            digest.update(block)
    return digest.hexdigest()


def sha256sum(path: Path, chunk: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(chunk):
            digest.update(block)
    return digest.hexdigest()


def append_log(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--priority", action="append", default=["core"])
    parser.add_argument("--dataset", action="append")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    rows = list(csv.DictReader(args.manifest.open(), delimiter="\t"))
    selected = [r for r in rows if r["priority"] in set(args.priority) and (not args.dataset or r["dataset_id"] in set(args.dataset))]
    expected = sum(int(r["bytes"]) for r in selected if r["bytes"].isdigit())
    free = shutil.disk_usage(args.root if args.root.exists() else args.root.parent).free
    if expected and free < expected * 1.15:
        raise SystemExit(f"insufficient free space: need >= {expected * 1.15:.0f}, have {free}")

    print(f"selected={len(selected)} declared_bytes={expected} free_bytes={free}")
    if args.dry_run:
        for r in selected:
            print(r["dataset_id"], r["filename"], r["bytes"] or "unknown")
        return 0

    log = args.root / "provenance" / "downloads.jsonl"
    for index, record in enumerate(selected, 1):
        outdir = args.root / "raw" / record["dataset_id"]
        outdir.mkdir(parents=True, exist_ok=True)
        target = outdir / record["filename"]
        expected_size = int(record["bytes"]) if record["bytes"].isdigit() else None
        expected_md5 = record["md5"].lower()
        expected_sha256 = record.get("sha256", "").lower()
        if target.exists() and (expected_size is None or target.stat().st_size == expected_size):
            md5_ok = not expected_md5 or md5sum(target) == expected_md5
            sha256_ok = not expected_sha256 or sha256sum(target) == expected_sha256
            if md5_ok and sha256_ok:
                print(f"[{index}/{len(selected)}] verified {target.name}")
                continue
        started = time.time()
        command = ["curl", "-L", "--fail", "--retry", "8", "--retry-delay", "5", "-C", "-", "-o", str(target) + ".part", record["url"]]
        print(f"[{index}/{len(selected)}] downloading {record['dataset_id']}/{target.name}", flush=True)
        result = subprocess.run(command)
        if result.returncode:
            append_log(log, {"dataset": record["dataset_id"], "file": target.name, "status": "failed", "returncode": result.returncode, "time": time.time()})
            return result.returncode
        os.replace(str(target) + ".part", target)
        actual_md5 = md5sum(target)
        if expected_size is not None and target.stat().st_size != expected_size:
            raise SystemExit(f"size mismatch for {target}")
        if expected_md5 and actual_md5 != expected_md5:
            raise SystemExit(f"md5 mismatch for {target}: {actual_md5} != {expected_md5}")
        actual_sha256 = sha256sum(target) if expected_sha256 else ""
        if expected_sha256 and actual_sha256 != expected_sha256:
            raise SystemExit(f"sha256 mismatch for {target}: {actual_sha256} != {expected_sha256}")
        append_log(log, {"dataset": record["dataset_id"], "file": target.name, "status": "verified", "bytes": target.stat().st_size, "md5": actual_md5, "sha256": actual_sha256, "seconds": round(time.time() - started, 3), "time": time.time()})
    return 0


if __name__ == "__main__":
    sys.exit(main())
