#!/usr/bin/env python3
"""Cross-task and cross-dataset transfer of relative fate uncertainty/rarity."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def larry_table(axes_path: Path, target_path: Path, assignment_path: Path, dataset: str) -> pd.DataFrame:
    axes = pd.read_parquet(axes_path).set_index("cell_id")
    axes = axes[[column for column in axes if "__" in column]]
    targets = pd.read_csv(target_path, sep="\t").set_index("target_id")
    assignment = pd.read_csv(assignment_path, sep="\t")
    rows = assignment.join(axes, on="cell_id", how="inner").join(
        targets[["transition_entropy", "p_rare_fate", "future_condition"]], on="target_id", rsuffix="_target"
    )
    branches = len([column for column in targets if column.startswith("p_branch_")])
    rows["relative_entropy"] = rows.transition_entropy / np.log(branches)
    rows["relative_rare_fate"] = rows.p_rare_fate
    rows["dataset"] = dataset
    return rows


def wot_table(axes_path: Path, target_path: Path) -> pd.DataFrame:
    axes = pd.read_parquet(axes_path)
    targets = pd.read_parquet(target_path)
    rows = axes.merge(targets.loc[targets.day.eq(0)], on="cell_id", validate="one_to_one")
    rows["relative_entropy"] = rows.normalized_transition_entropy
    rows["relative_rare_fate"] = rows.p_rare_fate
    rows["future_condition"] = "reprogramming"
    rows["dataset"] = "wot_reprogramming"
    return rows


def evaluate(rows: pd.DataFrame, features: list[str], target: str, grouping: str, validation_name: str | None = None) -> list[dict[str, object]]:
    metrics = []
    groups = rows[grouping].astype(str).to_numpy()
    for fold, (train, test) in enumerate(LeaveOneGroupOut().split(rows, groups=groups), 1):
        x_train = rows.iloc[train][features].rank(pct=True).fillna(0.5).to_numpy(float)
        # Rank features within the held-out dataset/task: unsupervised domain alignment.
        x_test = rows.iloc[test][features].rank(pct=True).fillna(0.5).to_numpy(float)
        y_train = rows.iloc[train].groupby("dataset", observed=True)[target].rank(pct=True).to_numpy(float)
        y_test = rows.iloc[test].groupby("dataset", observed=True)[target].rank(pct=True).to_numpy(float)
        model = make_pipeline(StandardScaler(), SelectKBest(f_regression, k=min(50, len(features))), Ridge(alpha=100.0))
        model.fit(x_train, y_train); prediction = np.clip(model.predict(x_test), 0, 1)
        for model_name, value in [("biological_axis_ridge", prediction), ("training_mean", np.repeat(y_train.mean(), len(test)))]:
            rho = spearmanr(y_test, value).statistic if np.std(value) > 0 else np.nan
            metrics.extend([
                {"validation": validation_name or f"leave_{grouping}", "fold": fold, "held_out": groups[test][0], "target": target, "model": model_name, "metric": "spearman", "value": rho},
                {"validation": validation_name or f"leave_{grouping}", "fold": fold, "held_out": groups[test][0], "target": target, "model": model_name, "metric": "mse", "value": np.mean((y_test - value) ** 2)},
            ])
    return metrics


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--larry-in-vitro-axes", type=Path, required=True)
    parser.add_argument("--larry-cytokine-axes", type=Path, required=True)
    parser.add_argument("--wot-axes", type=Path, required=True)
    parser.add_argument("--wot-targets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    tables = [
        larry_table(args.larry_in_vitro_axes, Path("tables/larry_in_vitro_clone_targets.tsv"), Path("tables/larry_in_vitro_baseline_assignments.tsv"), "larry_in_vitro"),
        larry_table(args.larry_cytokine_axes, Path("tables/larry_cytokine_clone_targets.tsv"), Path("tables/larry_cytokine_baseline_assignments.tsv"), "larry_cytokine"),
        wot_table(args.wot_axes, args.wot_targets),
    ]
    common = sorted(set.intersection(*[{column for column in table if "__" in column} for table in tables]))
    rows = pd.concat([table[["cell_id", "dataset", "future_condition", "relative_entropy", "relative_rare_fate", *common]] for table in tables], ignore_index=True)
    metrics = []
    for target in ["relative_entropy", "relative_rare_fate"]:
        metrics += evaluate(rows, common, target, "dataset", "leave_dataset_cross_platform_stress")
        larry = rows.loc[rows.dataset.str.startswith("larry_")].copy()
        metrics += evaluate(larry, common, target, "dataset", "leave_dataset_larry_primary")
        cytokine = rows.loc[rows.dataset.eq("larry_cytokine")].copy()
        # Each future cytokine condition defines a distinct response task.  The
        # held-out task is never used for supervised fitting or feature selection.
        metrics += evaluate(
            cytokine, common, target, "future_condition", "leave_task"
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows[["cell_id", "dataset", "future_condition", "relative_entropy", "relative_rare_fate"]].to_parquet(args.output_dir / "harmonized_targets.parquet", index=False)
    pd.DataFrame(metrics).to_csv(args.output_dir / "generalization_metrics.tsv", sep="\t", index=False)
    print(f"rows={len(rows)}, common_axes={len(common)}")
    print(pd.DataFrame(metrics).groupby(["validation", "target", "model", "metric"]).value.mean().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
