#!/usr/bin/env python3
"""Analyze pretreatment Xenium states, niches and exploratory future response."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import zarr
from scipy import sparse
from scipy.stats import spearmanr
from sklearn.cluster import KMeans
from sklearn.linear_model import Ridge
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler


CELL_MARKERS = {
    "tumor_epithelial": ["EPCAM", "KRT5", "KRT14", "KRT17", "KRT19", "TP63", "SOX9"],
    "cd8_t": ["CD3D", "CD3E", "CD8A", "CD8B", "TRAC", "CCL5", "NKG7"],
    "cd4_t": ["CD3D", "CD3E", "CD4", "IL7R", "LTB", "MALAT1"],
    "b_cell": ["CD79A", "MS4A1", "CD19", "CD37", "CD74", "HLA-DRA", "BANK1"],
    "plasma_cell": ["JCHAIN", "MZB1", "SDC1", "IGHG1", "IGHG3", "IGKC"],
    "myeloid": ["LYZ", "LST1", "FCER1G", "TYROBP", "CD68", "C1QA", "C1QC", "CD163"],
    "fibroblast": ["COL1A1", "COL1A2", "COL3A1", "DCN", "FAP", "PDGFRA", "COL6A1"],
    "endothelial": ["PECAM1", "VWF", "KDR", "AQP1", "EMCN", "RAMP2", "PLVAP"],
    "mast_cell": ["TPSAB1", "TPSB2", "KIT", "CPA3", "MS4A2"],
}

FATE_PROGRAMS = {
    # The targeted panel lacks core caspases; this spatial score is therefore
    # explicitly a cytotoxic/apoptotic pressure axis, not apoptosis probability.
    "apoptosis_pressure": ["GZMB", "PRF1", "GNLY", "IFI27"],
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM5", "UBE2C", "TYMS", "STMN1"],
    "differentiation_proxy": ["KRT1", "KRT10", "IVL", "FLG", "LOR", "KLF4", "NOTCH1"],
    "stress": ["HSPA1A", "HSPA1B", "HSP90AA1", "ATF3", "DDIT3", "JUN", "FOS", "DNAJB1"],
    "resistance_ecosystem": ["TGFB1", "MMP2", "FAP", "COL1A1", "COL1A2", "COL3A1", "CAV1", "BAG3", "APOE"],
}

LIGAND_RECEPTOR = {
    "CXCL9_CXCR3": ("CXCL9", "CXCR3"),
    "CXCL10_CXCR3": ("CXCL10", "CXCR3"),
    "CXCL13_CXCR5": ("CXCL13", "CXCR5"),
    "CCL19_CCR7": ("CCL19", "CCR7"),
    "CCL21_CCR7": ("CCL21", "CCR7"),
    "CCL17_CCR4": ("CCL17", "CCR4"),
    "CCL22_CCR4": ("CCL22", "CCR4"),
    "TGFB1_TGFBR2": ("TGFB1", "TGFBR2"),
    "VEGFA_KDR": ("VEGFA", "KDR"),
    "CD274_PDCD1": ("CD274", "PDCD1"),
    "LGALS9_HAVCR2": ("LGALS9", "HAVCR2"),
    "CD40LG_CD40": ("CD40LG", "CD40"),
    "ICOSLG_ICOS": ("ICOSLG", "ICOS"),
}


def find_table(sample_dir: Path) -> zarr.Group:
    for marker in sample_dir.rglob(".zgroup"):
        root = marker.parent
        if (root / "tables/table/.zgroup").exists():
            return zarr.open_group(str(root), mode="r")["tables/table"]
    raise FileNotFoundError(f"No SpatialData AnnData table under {sample_dir}")


def robust_qc(obs: pd.DataFrame, min_transcripts: float = 5.0) -> tuple[np.ndarray, dict[str, float]]:
    counts = pd.to_numeric(obs.transcript_counts, errors="coerce").fillna(0).to_numpy(float)
    positive = counts[counts > 0]
    log = np.log1p(positive)
    median = np.median(log); mad = np.median(np.abs(log - median)) * 1.4826
    lower = max(min_transcripts, np.expm1(median - 3 * max(mad, 0.1)))
    controls = np.zeros(len(obs), dtype=float)
    for column in ["control_probe_counts", "control_codeword_counts", "unassigned_codeword_counts"]:
        if column in obs:
            controls += pd.to_numeric(obs[column], errors="coerce").fillna(0).to_numpy(float)
    fraction = controls / np.maximum(counts + controls, 1)
    fraction_cap = max(0.2, np.nanquantile(fraction, 0.995))
    keep = (counts >= lower) & (fraction <= fraction_cap)
    return keep, {
        "transcript_count_lower": float(lower),
        "control_fraction_upper": float(fraction_cap),
        "median_transcript_counts": float(np.median(counts)),
    }


def normalized_expression(adata: ad.AnnData, keep: np.ndarray) -> tuple[np.ndarray, list[str], np.ndarray]:
    x = adata.X[keep]
    if sparse.issparse(x):
        x = x.toarray()
    raw = np.asarray(x, dtype=np.float32)
    pseudobulk = raw.sum(axis=0)
    pseudobulk = np.log1p(pseudobulk / max(float(pseudobulk.sum()), 1.0) * 1e6)
    x = np.log1p(raw / np.maximum(raw.sum(axis=1, keepdims=True), 1) * 1e4)
    return x, adata.var_names.astype(str).tolist(), pseudobulk


def score_modules(x: np.ndarray, genes: list[str], modules: dict[str, list[str]]) -> pd.DataFrame:
    index = {gene: position for position, gene in enumerate(genes)}
    gene_mean = x.mean(axis=0); gene_sd = x.std(axis=0)
    z = (x - gene_mean) / np.maximum(gene_sd, 0.2)
    output = {}
    for name, members in modules.items():
        positions = [index[gene] for gene in members if gene in index]
        output[name] = z[:, positions].mean(axis=1) if positions else np.zeros(len(x))
    return pd.DataFrame(output)


def score_modules_absolute(x: np.ndarray, genes: list[str], modules: dict[str, list[str]]) -> pd.DataFrame:
    """Cross-sample comparable log-normalized module means on the fixed panel."""
    index = {gene: position for position, gene in enumerate(genes)}
    output = {}
    for name, members in modules.items():
        positions = [index[gene] for gene in members if gene in index]
        output[name] = x[:, positions].mean(axis=1) if positions else np.zeros(len(x))
    return pd.DataFrame(output)


def moran(values: np.ndarray, neighbor_index: np.ndarray, seed: int, permutations: int = 199) -> tuple[float, float]:
    centered = values - values.mean(); denominator = np.square(centered).sum()
    if denominator == 0:
        return np.nan, np.nan
    observed = len(values) / neighbor_index.size * (centered[:, None] * centered[neighbor_index]).sum() / denominator
    rng = np.random.default_rng(seed); null = np.empty(permutations)
    for iteration in range(permutations):
        shuffled = rng.permutation(centered)
        null[iteration] = len(values) / neighbor_index.size * (shuffled[:, None] * shuffled[neighbor_index]).sum() / denominator
    pvalue = (1 + np.sum(np.abs(null) >= abs(observed))) / (permutations + 1)
    return float(observed), float(pvalue)


def read_outcomes(path: Path) -> pd.DataFrame:
    data = pd.read_csv(path, encoding="utf-8-sig")
    data["patient"] = data.Patient.astype(str)
    data["future_response"] = data.Response.astype(str).str.lower().eq("yes").astype(int)
    change = pd.to_numeric(data["Best % change (initial follow up period to 03/12/19)"], errors="coerce")
    data["future_tumor_shrinkage"] = -change
    return data.set_index("patient")


def ligand_receptor_provenance(path: Path) -> pd.DataFrame:
    network = pd.read_csv(path, sep="\t")
    rows = []
    for name, (ligand, receptor) in LIGAND_RECEPTOR.items():
        match = network.loc[
            network.source_genesymbol.eq(ligand) & network.target_genesymbol.eq(receptor)
        ]
        rows.append({
            "interaction": name, "ligand": ligand, "receptor": receptor,
            "omnipath_supported": not match.empty,
            "sources": match.sources.iloc[0] if not match.empty else np.nan,
            "references": match.references.iloc[0] if not match.empty else np.nan,
        })
    return pd.DataFrame(rows)


def process_sample(sample_dir: Path, patient: str, outcome: pd.DataFrame, k: int, min_transcripts: float) -> tuple[pd.DataFrame, dict]:
    sample = sample_dir.name
    adata = ad.read_zarr(find_table(sample_dir)); keep, qc_thresholds = robust_qc(adata.obs, min_transcripts)
    x, genes, pseudobulk = normalized_expression(adata, keep)
    gene_set = set(genes)
    coverage = []
    for module_type, modules in [("cell_type", CELL_MARKERS), ("fate", FATE_PROGRAMS)]:
        for module, members in modules.items():
            present = [gene for gene in members if gene in gene_set]
            coverage.append({
                "sample": sample, "module_type": module_type, "module": module,
                "genes_specified": len(members), "genes_present": len(present),
                "present_gene_symbols": ";".join(present),
            })
    obs = adata.obs.loc[keep].copy(); coordinates = np.asarray(adata.obsm["spatial"])[keep]
    available_cell_markers = {
        name: members for name, members in CELL_MARKERS.items()
        if any(gene in gene_set for gene in members)
    }
    cell_scores = score_modules(x, genes, available_cell_markers)
    cell_type = cell_scores.idxmax(axis=1).to_numpy()
    fate = score_modules(x, genes, FATE_PROGRAMS).add_prefix("intrinsic_")
    absolute_fate = score_modules_absolute(x, genes, FATE_PROGRAMS).add_prefix("absolute_")
    sample_absolute = score_modules_absolute(pseudobulk[None, :], genes, FATE_PROGRAMS).add_prefix("absolute_").iloc[0].to_dict()
    sample_absolute.update({"sample": sample, "patient": patient, "cells_qc": int(keep.sum())})
    nearest = NearestNeighbors(n_neighbors=min(k + 1, len(obs))).fit(coordinates)
    neighbor_index = nearest.kneighbors(return_distance=False)[:, 1:]
    types = list(available_cell_markers); one_hot = pd.get_dummies(pd.Categorical(cell_type, categories=types)).to_numpy(float)
    neighbor_composition = one_hot[neighbor_index].mean(axis=1)
    rows = pd.DataFrame({
        "cell_id": [f"{sample}:{value}" for value in obs.cell_id.astype(str)],
        "sample": sample,
        "patient": patient,
        "x": coordinates[:, 0], "y": coordinates[:, 1],
        "cell_type": cell_type,
        "transcript_counts": pd.to_numeric(obs.transcript_counts, errors="coerce").to_numpy(),
    })
    rows = pd.concat([rows, fate.reset_index(drop=True), absolute_fate.reset_index(drop=True)], axis=1)
    for position, name in enumerate(types):
        rows[f"neighbor_fraction__{name}"] = neighbor_composition[:, position]
    gene_index = {gene: position for position, gene in enumerate(genes)}
    lr_used = []
    for name, (ligand, receptor) in LIGAND_RECEPTOR.items():
        if ligand in gene_index and receptor in gene_index:
            ligand_value = x[:, gene_index[ligand]]
            receptor_neighbor = x[neighbor_index, gene_index[receptor]].mean(axis=1)
            rows[f"cci__{name}"] = ligand_value * receptor_neighbor
            lr_used.append(name)
    rows["future_response"] = int(outcome.loc[patient, "future_response"])
    rows["future_tumor_shrinkage"] = float(outcome.loc[patient, "future_tumor_shrinkage"])
    spatial = []
    for column in [column for column in rows if column.startswith("intrinsic_")]:
        statistic, pvalue = moran(rows[column].to_numpy(float), neighbor_index, 20260713)
        spatial.append({"sample": sample, "patient": patient, "feature": column, "moran_i": statistic, "permutation_pvalue": pvalue})
    qc = {"sample": sample, "patient": patient, "cells_input": adata.n_obs, "cells_qc": int(keep.sum()), "genes": adata.n_vars, "ligand_receptor_pairs_used": len(lr_used), **qc_thresholds}
    return rows, {"qc": qc, "spatial": spatial, "coverage": coverage, "sample_absolute": sample_absolute}


def pseudospots(cells: pd.DataFrame, grid_size: float) -> pd.DataFrame:
    cells = cells.copy()
    cells["grid_x"] = np.floor(cells.x / grid_size).astype(int)
    cells["grid_y"] = np.floor(cells.y / grid_size).astype(int)
    keys = ["sample", "patient", "grid_x", "grid_y"]
    numeric = [column for column in cells if column.startswith(("intrinsic_", "absolute_", "neighbor_fraction__", "cci__"))]
    spot = cells.groupby(keys, observed=True, dropna=False)[numeric].mean().reset_index()
    counts = cells.groupby(keys, observed=True, dropna=False).size().rename("n_cells").reset_index()
    composition = pd.crosstab([cells[key] for key in keys], cells.cell_type, normalize="index").reset_index()
    spot = spot.merge(counts, on=keys).merge(composition, on=keys)
    labels = cells.groupby(keys, observed=True)[["future_response", "future_tumor_shrinkage"]].first().reset_index()
    spot = spot.merge(labels, on=keys)
    spot = spot.loc[spot.n_cells >= 10].copy()
    spot["spot_id"] = spot[keys].astype(str).agg(":\u200b".join, axis=1)
    return spot


def joint_prediction(spots: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    if spots.patient.nunique() < 4:
        return pd.DataFrame(), pd.DataFrame()
    intrinsic = [column for column in spots if column.startswith(("intrinsic_", "absolute_"))]
    niche = [column for column in spots if column.startswith("neighbor_fraction__") or column in CELL_MARKERS]
    cci = [column for column in spots if column.startswith("cci__")]
    feature_sets = {"intrinsic": intrinsic, "spatial_niche": niche + cci, "joint": intrinsic + niche + cci}
    predictions = []
    for held_out in sorted(spots.patient.unique()):
        train = spots.patient.ne(held_out); test = ~train
        train_patient_outcomes = spots.loc[train, ["patient", "future_tumor_shrinkage"]].drop_duplicates("patient")
        predictions.append({
            "held_out_patient": held_out, "model": "training_patient_mean",
            "observed_tumor_shrinkage": spots.loc[test, "future_tumor_shrinkage"].iloc[0],
            "predicted_tumor_shrinkage": train_patient_outcomes.future_tumor_shrinkage.mean(),
            "n_train_patients": int(train_patient_outcomes.patient.nunique()),
            "n_test_spots": int(test.sum()), "n_features": 0,
        })
        for model_name, features in feature_sets.items():
            if not features:
                continue
            scaler = StandardScaler().fit(spots.loc[train, features])
            model = Ridge(alpha=10.0)
            patient_counts = spots.loc[train].groupby("patient").size()
            weight = spots.loc[train, "patient"].map(lambda value: 1 / patient_counts[value]).to_numpy()
            model.fit(scaler.transform(spots.loc[train, features]), spots.loc[train, "future_tumor_shrinkage"], sample_weight=weight)
            estimate = model.predict(scaler.transform(spots.loc[test, features])).mean()
            predictions.append({"held_out_patient": held_out, "model": model_name, "observed_tumor_shrinkage": spots.loc[test, "future_tumor_shrinkage"].iloc[0], "predicted_tumor_shrinkage": estimate, "n_train_patients": int(spots.loc[train, "patient"].nunique()), "n_test_spots": int(test.sum()), "n_features": len(features)})
    predictions = pd.DataFrame(predictions)
    metrics = []
    for model_name, group in predictions.groupby("model", observed=True):
        metrics.extend([
            {"model": model_name, "metric": "spearman", "value": spearmanr(group.observed_tumor_shrinkage, group.predicted_tumor_shrinkage).statistic, "n_patients": len(group), "scope": "exploratory_four_patient_lopo"},
            {"model": model_name, "metric": "mae", "value": np.mean(np.abs(group.observed_tumor_shrinkage - group.predicted_tumor_shrinkage)), "n_patients": len(group), "scope": "exploratory_four_patient_lopo"},
        ])
    return predictions, pd.DataFrame(metrics)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--staged-dir", type=Path, nargs="+", required=True)
    parser.add_argument("--outcomes", type=Path, default=Path("resource/gse291246_supplement/pnas.2501269122.sd01.csv"))
    parser.add_argument("--sample-metadata", type=Path, default=Path("tables/gse291246_sample_metadata.tsv"))
    parser.add_argument("--omnipath", type=Path, default=Path("resource/networks/omnipath_interactions.tsv"))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--neighbors", type=int, default=20)
    parser.add_argument("--grid-size", type=float, default=200.0)
    parser.add_argument("--min-transcripts", type=float, default=5.0)
    args = parser.parse_args(); outcome = read_outcomes(args.outcomes)
    sample_metadata = pd.read_csv(args.sample_metadata, sep="\t").set_index("geo_accession")
    cell_frames = []; qc = []; spatial = []; coverage = []; sample_absolute = []
    sample_dirs = []
    for staged_dir in args.staged_dir:
        sample_dirs.extend(path for path in staged_dir.iterdir() if path.is_dir())
    seen_samples = set()
    for sample_dir in sorted(sample_dirs, key=lambda path: path.name):
        if sample_dir.name in seen_samples:
            raise ValueError(f"Duplicate staged Xenium sample: {sample_dir.name}")
        seen_samples.add(sample_dir.name)
        if not any(sample_dir.rglob("tables/table/.zgroup")):
            continue
        if sample_dir.name not in sample_metadata.index:
            raise KeyError(f"Missing metadata for {sample_dir.name}")
        patient = str(sample_metadata.loc[sample_dir.name, "sample_title"]).split()[0]
        rows, metadata = process_sample(sample_dir, patient, outcome, args.neighbors, args.min_transcripts)
        cell_frames.append(rows); qc.append(metadata["qc"]); spatial.extend(metadata["spatial"]); coverage.extend(metadata["coverage"]); sample_absolute.append(metadata["sample_absolute"])
    if not cell_frames:
        raise RuntimeError("No extracted Xenium samples found")
    cells = pd.concat(cell_frames, ignore_index=True)
    neighborhood = [column for column in cells if column.startswith("neighbor_fraction__")]
    kmeans = KMeans(n_clusters=min(6, max(2, len(cells) // 1000)), n_init=50, random_state=20260713)
    cells["spatial_niche"] = kmeans.fit_predict(cells[neighborhood])
    niche_summary = cells.groupby("spatial_niche", observed=True).agg(
        cells=("cell_id", "size"), samples=("sample", "nunique"), patients=("patient", "nunique"),
        apoptosis_pressure=("intrinsic_apoptosis_pressure", "mean"), proliferation=("intrinsic_proliferation", "mean"),
        differentiation_proxy=("intrinsic_differentiation_proxy", "mean"), stress=("intrinsic_stress", "mean"),
        resistance_ecosystem=("intrinsic_resistance_ecosystem", "mean"),
    ).reset_index()
    spot = pseudospots(cells, args.grid_size)
    prediction, metrics = joint_prediction(spot)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    cells.to_parquet(args.output_dir / "xenium_cell_states_and_niches.parquet", index=False)
    spot.to_parquet(args.output_dir / "xenium_pseudospot_deconvolution.parquet", index=False)
    pd.DataFrame(qc).to_csv(args.output_dir / "sample_qc.tsv", sep="\t", index=False)
    pd.DataFrame(spatial).to_csv(args.output_dir / "spatial_autocorrelation.tsv", sep="\t", index=False)
    pd.DataFrame(coverage).to_csv(args.output_dir / "targeted_panel_module_coverage.tsv", sep="\t", index=False)
    pd.DataFrame(sample_absolute).to_csv(args.output_dir / "sample_absolute_programs.tsv", sep="\t", index=False)
    niche_summary.to_csv(args.output_dir / "common_spatial_niches.tsv", sep="\t", index=False)
    prediction.to_csv(args.output_dir / "joint_model_lopo_predictions.tsv", sep="\t", index=False)
    metrics.to_csv(args.output_dir / "joint_model_metrics.tsv", sep="\t", index=False)
    ligand_receptor_provenance(args.omnipath).to_csv(
        args.output_dir / "ligand_receptor_provenance.tsv", sep="\t", index=False
    )
    print(pd.DataFrame(qc).to_string(index=False)); print(metrics.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
