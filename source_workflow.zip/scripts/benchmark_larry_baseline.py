#!/usr/bin/env python3
"""Clone-held-out prediction of LARRY lineage branch probabilities from baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold


def normalize(values: np.ndarray) -> np.ndarray:
    result = np.clip(values, 0, 1)
    total = result.sum(axis=1, keepdims=True)
    return np.divide(result, total, out=np.full_like(result, 1 / result.shape[1]), where=total > 0)


def metric_rows(y: np.ndarray, prediction: np.ndarray, branches: list[str]) -> list[dict[str, object]]:
    observed_top = y.argmax(axis=1)
    predicted_top = prediction.argmax(axis=1)
    rows = [
        {"branch": "macro", "metric": "brier", "value": float(np.mean((y - prediction) ** 2))},
        {"branch": "macro", "metric": "top_branch_accuracy", "value": float(np.mean(observed_top == predicted_top))},
    ]
    for index, branch in enumerate(branches):
        rows.append({"branch": branch, "metric": "spearman", "value": float(spearmanr(y[:, index], prediction[:, index]).statistic)})
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expression", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--assignments", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--latent-dim", type=int, default=50)
    parser.add_argument("--folds", type=int, default=5)
    args = parser.parse_args()
    targets = pd.read_csv(args.targets, sep="\t").set_index("target_id")
    assignments = pd.read_csv(args.assignments, sep="\t")
    rows = assignments.merge(targets, left_on="target_id", right_index=True,
                             validate="many_to_one", suffixes=("_assignment", "_target"))
    for column in ["clone_id", "future_condition"]:
        left = rows[f"{column}_assignment"].astype(str)
        right = rows[f"{column}_target"].astype(str)
        if not left.equals(right):
            raise ValueError(f"assignment/target mismatch in {column}")
        rows[column] = rows[f"{column}_assignment"]
    target_columns = [column for column in targets if column.startswith("p_branch_")]
    branches = [column.removeprefix("p_branch_") for column in target_columns]
    cell_ids = pd.Index(rows.cell_id.unique(), name="cell_id")

    source = ad.read_h5ad(args.expression, backed="r")
    positions = source.obs_names.get_indexer(cell_ids)
    if (positions < 0).any():
        raise ValueError(f"{(positions < 0).sum()} assigned cells absent from expression")
    baseline = source[positions].to_memory()
    source.file.close()
    cell_position = pd.Series(np.arange(len(cell_ids)), index=cell_ids)
    row_position = rows.cell_id.map(cell_position).to_numpy()
    units = rows.drop_duplicates("target_id").reset_index(drop=True)
    y = units[target_columns].to_numpy(float)
    groups = units.clone_id.to_numpy()
    conditions = pd.get_dummies(units.future_condition.astype(str), dtype=float).to_numpy()
    splitter = GroupKFold(n_splits=min(args.folds, np.unique(groups).size))
    metrics = []
    prediction_frames = []
    for fold, (train, test) in enumerate(splitter.split(units, groups=groups), 1):
        train_ids = set(units.iloc[train].target_id)
        train_cells = np.unique(row_position[rows.target_id.isin(train_ids)])
        svd = TruncatedSVD(n_components=args.latent_dim, random_state=20260713 + fold)
        svd.fit(baseline.X[train_cells])
        latent_all = svd.transform(baseline.X)
        latent_rows = pd.DataFrame(latent_all[row_position])
        latent_rows["target_id"] = rows.target_id.to_numpy()
        target_latent = latent_rows.groupby("target_id", observed=True).mean().loc[units.target_id].to_numpy()
        features = np.column_stack([target_latent, conditions])
        model = Ridge(alpha=10.0).fit(features[train], y[train])
        prediction = normalize(model.predict(features[test]))
        mean_prediction = np.repeat(y[train].mean(axis=0, keepdims=True), len(test), axis=0)
        for model_name, values in [("baseline_latent_ridge", prediction), ("training_mean", mean_prediction)]:
            for item in metric_rows(y[test], values, branches):
                metrics.append({"fold": fold, "model": model_name, **item})
        frame = pd.DataFrame(prediction, columns=[f"pred_{branch}" for branch in branches])
        frame["target_id"] = units.iloc[test].target_id.to_numpy()
        frame["clone_id"] = units.iloc[test].clone_id.to_numpy()
        frame["future_condition"] = units.iloc[test].future_condition.to_numpy()
        frame["fold"] = fold
        prediction_frames.append(frame)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(metrics).to_csv(args.output_dir / "clone_heldout_metrics.tsv", sep="\t", index=False)
    pd.concat(prediction_frames, ignore_index=True).to_parquet(args.output_dir / "clone_heldout_predictions.parquet", index=False)
    summary = pd.DataFrame(metrics).query("branch == 'macro'").groupby(["model", "metric"]).value.mean()
    print(summary.to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
