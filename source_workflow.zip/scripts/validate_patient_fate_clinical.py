#!/usr/bin/env python3
"""Validate PFE predictions and unsupervised subtypes against clinical outcomes."""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact
from statsmodels.duration.hazard_regression import PHReg


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", choices=["ispy2", "beataml"], required=True)
    parser.add_argument("--embedding", type=Path, required=True)
    parser.add_argument("--metadata-h5ad", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    emb = pd.read_parquet(args.embedding)
    id_column = "cell_id" if "cell_id" in emb else "index"
    emb = emb.set_index(id_column); emb.index.name = "cell_id"
    source = ad.read_h5ad(args.metadata_h5ad, backed="r"); meta = source.obs.copy(); source.file.close()
    rows = emb.join(meta, how="left", rsuffix="_metadata")
    tests = []
    table = pd.crosstab(rows.stable_subtype, rows.outcome)
    if table.shape == (2, 2):
        odds, pvalue = fisher_exact(table)
        tests.append({"analysis": "subtype_response", "term": "stable_subtype", "estimate": odds, "ci_low": np.nan, "ci_high": np.nan, "pvalue": pvalue, "n": len(rows)})
    if args.cohort == "beataml":
        time = pd.to_numeric(rows.OS_MONTHS, errors="coerce")
        event = rows.OS_STATUS.astype(str).str.startswith("1:").astype(int)
        for term in ["cross_fitted_response_probability", "stable_subtype"]:
            value = pd.to_numeric(rows[term], errors="coerce")
            valid = time.gt(0) & value.notna() & event.notna()
            standardized = (value[valid] - value[valid].mean()) / value[valid].std()
            fit = PHReg(time[valid], standardized.to_numpy()[:, None], status=event[valid]).fit(disp=False)
            beta, se, pvalue = float(fit.params[0]), float(fit.bse[0]), float(fit.pvalues[0])
            tests.append({"analysis": "overall_survival_cox", "term": term, "estimate": np.exp(beta), "ci_low": np.exp(beta - 1.96 * se), "ci_high": np.exp(beta + 1.96 * se), "pvalue": pvalue, "n": int(valid.sum())})
        for marker in ["FLT3_ITD", "NPM1", "TP53", "ELN2017", "mutation_count_records", "structural_variant_count"]:
            if marker in rows:
                summary = rows.groupby("stable_subtype", observed=True)[marker].agg(lambda x: x.astype(str).value_counts().index[0] if x.notna().any() else np.nan)
                tests.append({"analysis": "multiomic_subtype_annotation", "term": marker, "estimate": " | ".join(f"S{k}:{v}" for k, v in summary.items()), "ci_low": np.nan, "ci_high": np.nan, "pvalue": np.nan, "n": int(rows[marker].notna().sum())})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(tests).to_csv(args.output_dir / "clinical_validation.tsv", sep="\t", index=False)
    table.to_csv(args.output_dir / "subtype_response_contingency.tsv", sep="\t")
    print(pd.DataFrame(tests).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
